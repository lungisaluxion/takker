package com.hellokoding.java.lang;

public class BookWithoutEquals {
    String title;

    public BookWithoutEquals(String title) {
        this.title = title;
    }
}
