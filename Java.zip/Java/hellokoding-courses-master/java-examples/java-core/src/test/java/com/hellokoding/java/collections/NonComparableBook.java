package com.hellokoding.java.collections;

public class NonComparableBook {
    public String title;

    public NonComparableBook(String title) {
        this.title = title;
    }
}
