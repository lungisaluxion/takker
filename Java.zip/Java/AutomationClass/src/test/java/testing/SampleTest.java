package testing;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import static junit.framework.Assert.assertEquals;

/**
 * Created by ABSMBGL on 2018-03-05.
 */
public class SampleTest {
    private Properties siteProperties;
    public ArrayList<Properties> testResultsHolder = new ArrayList();
    private utilities.GetPropertyFileValues properties = new utilities.GetPropertyFileValues();
    private int startRow;
    private int endRow;

    @Before
    public void setUp() throws IOException {

        siteProperties = properties.getPropValues("TestCase/testreorces.properties");
        startRow = Integer.valueOf(siteProperties.getProperty("fromRow"));
        endRow = Integer.valueOf(siteProperties.getProperty("toRow"));

    }

    @Test
    public void simpleSeleniumTest() throws Exception{
        System.setProperty("webdriver.chrome.driver", "C:\\drivers\\chromedriver.exe");
        WebDriver webDriver;
        ChromeOptions options = new ChromeOptions();
        options.addArguments("test-type");
        options.addArguments("start-maximized");
        options.addArguments("--enable-automation");
        options.addArguments("test-type=browser");
        options.addArguments("disable-infobars");
        webDriver = new ChromeDriver(options);
        HashMap testData = new utilities.HelperMethods().getTestData(siteProperties.getProperty("dataSheet").toString(), "TestData", 1);



        webDriver.get("http://automationpractice.com/index.php?controller=contact");
        WebDriverWait wait=new WebDriverWait(webDriver, 20);
        WebElement homePageSearchBar;
        homePageSearchBar= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath( "//*[@id=\"search_query_top\"]")));
        webDriver.findElement(By.xpath("//*[@id=\"contact-link\"]/a")).click();

        WebElement contactUsPage;
        contactUsPage= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath( "//*[@id=\"center_column\"]/h1")));


        webDriver.findElement(By.xpath("//*[@id=\"id_contact\"]")).click();
        webDriver.findElement(By.xpath("//*[text() = '" + testData.get("Subject Heading").toString() + "']")).click();

        webDriver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys(testData.get("Email address").toString());
        webDriver.findElement(By.xpath("//*[@id=\"id_order\"]")).sendKeys(testData.get("Order reference").toString());
        webDriver.findElement(By.xpath("//*[@id=\"message\"]")).sendKeys(testData.get("Message").toString());
        webDriver.findElement(By.xpath("//*[@id=\"submitMessage\"]/span")).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath( "//*[@id=\"center_column\"]/p")));
        assertEquals(webDriver.findElement(By.xpath("//*[@id=\"center_column\"]/p")).getText(),"Your message has been successfully sent to our team.");
    }
}
