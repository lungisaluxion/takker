package interaction;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;

/**
 * Created by ABSMBGL on 2018-01-26.
 */
public class RESTInteractionService {
    DefaultHttpClient httpClient;
    StringEntity input;
    HttpPost postRequest;
    HttpGet getRequest;
    String contentType;

    public RESTInteractionService(){

    }

    public RESTInteractionService(String uri, String request) throws UnsupportedEncodingException {
        this.httpClient = new DefaultHttpClient();
        this.postRequest =  new HttpPost(uri);
        this.input = new StringEntity(request);
    }
    public RESTInteractionService(String uri) throws UnsupportedEncodingException {
        this.httpClient = new DefaultHttpClient();
        this.getRequest =  new HttpGet(uri);
    }



    /**
     * This method does a POST on a REstfull Service sitting on API Manager
     * that requires an IBM username and password.
     * @return String value of output from server.
     * @throws MalformedURLException
     * @throws IOException
     */
    public String POST() throws IOException {
        postRequest.setEntity(input);
        HttpResponse response = httpClient.execute(postRequest);

        if (response.getStatusLine().getStatusCode() != 200) {
            throw new RuntimeException("Failed : HTTP error code : "
                    + response.getStatusLine().getStatusCode());
        }
        BufferedReader br = new BufferedReader(
                new InputStreamReader((response.getEntity().getContent())));
        StringBuffer responseHolder = new StringBuffer();
        String output;
        System.out.println("Output from Server .... \n");
        while ((output = br.readLine()) != null) {
            System.out.println(output);
            responseHolder.append(output);
        }
        httpClient.getConnectionManager().shutdown();
        return responseHolder.toString();
    }



    /**
     * This method does a GET on a Restfull Service.
     * This is to be used on a Restfull service that doesn't require Credentials to access.
     * @return The  response from the service as a string.
     */
    public String GET() throws IOException {
        HttpResponse response = httpClient.execute(getRequest);
        System.out.println("request" + getRequest.toString());

        BufferedReader br = new BufferedReader(new InputStreamReader((response.getEntity().getContent())));
        StringBuffer responseHolder = new StringBuffer();
        String output;
        System.out.println("Output from Server .... \n");
        while ((output = br.readLine()) != null) {
            System.out.println(output);
            responseHolder.append(output);
        }
        httpClient.getConnectionManager().shutdown();
        if (response.getStatusLine().getStatusCode() != 200) {
            throw new RuntimeException("Failed : HTTP error code : "
                    + response.getStatusLine().getStatusCode());
        }
       /* if(response.getStatusLine().getStatusCode() ==500)
        {
            fail("The Service Is Down.");
        }*/
        return responseHolder.toString();
    }

    public void setContentType(String contentType)
    {
        this.contentType = contentType;
    }

    public String getContentType(){
        return this.contentType;
    }

    /**
     * Adds Headers to the Request Message.
     * @param HeaderName Name of the Header Being Added.
     * @param headerValue String value of the header being added.
     */
    public void setRequestHeadersPost(String HeaderName, String headerValue){
        this.postRequest.addHeader(HeaderName, headerValue);
    }


    public void setRequestHeadersGet(String HeaderName, String headerValue){
        this.getRequest.addHeader(HeaderName, headerValue);
    }

    public void viewGetRequestHeaders(){
        Header[] headers = getRequest.getAllHeaders();
        for(int i =0; i< headers.length; i++){
            System.out.println("Header Name     :" +  headers[i].getName());
            System.out.println("Header Value    :" +  headers[i].getValue());
        }

    }

}
