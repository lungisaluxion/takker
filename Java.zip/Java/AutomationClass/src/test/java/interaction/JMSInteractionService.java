package interaction;

/**
 * Created by ABSMBGL on 2018-01-26.
 */
public class JMSInteractionService {
    //to be implemented.
}
