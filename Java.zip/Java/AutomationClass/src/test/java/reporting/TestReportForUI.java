package reporting;

import org.apache.commons.io.FileUtils;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Properties;


/**
 *  Test Report.
 *  This is a class that generates an HTML test execution report.
 *  @version 1.0
 * @author ABSMBGL
 * @since 2017-10-27.
 */
public class TestReportForUI extends TestReport {

    public TestReportForUI(String desiredReportLocation) {
        super(desiredReportLocation);
    }


    /**
     * This method overrides the Build Report method from the parent TestReport Class.
     * @param results An array list that hold a Test Results Properties.
     * @param Environment Enlivenment The test is run in.
     * @param SCREENSHOTS_PATH Path to the location of UI screenshots on disk.
     * @param SCREENSHOT_NAMES Names of the test screen shots, in an array list where each index contains a string of screenshots separated by a a comma. Example : test_one_login.jpg,test_one_fill_name.jpg,test_one_click.jpg
     * @param durations Array list of test durations.
     * @throws IOException
     */
    public void buildReport(ArrayList<Properties> results, String Environment, ArrayList SCREENSHOTS_PATH, ArrayList SCREENSHOT_NAMES, ArrayList durations) throws IOException {
        int numberOfFaliures=0;
        int numberPassed=0;
        String  testResultTable ="";
        for(int i=0; i< results.size();i++)
        {
            if(results.get(i).getProperty("Result").equals("PASSED"))
            {
                numberPassed+=1;
                String resultReport = buildResultsPage(results.get(i).get("Result").toString(),SCREENSHOTS_PATH.get(i).toString(),SCREENSHOT_NAMES, results.get(i).get("ExpectedResult").toString(), results.get(i).get("ActualResult").toString(), results.get(i).get("Test ID").toString());
                testResultTable+=("<tr class=\"content\"><td>" + results.get(i).get("Test ID").toString() +  "</td><td>"+ results.get(i).get("Test Description").toString() +  "</td><td><a href=\"" + resultReport + "\" class=\"btn-wide  btn-success \">"+ results.get(i).get("Result").toString() + "</a></td></tr>"+ "\n" );
            }
            if(results.get(i).getProperty("Result").equals("FAILED"))
            {
                numberOfFaliures+=1;
                String resultReport = buildResultsPage(results.get(i).get("Result").toString(),SCREENSHOTS_PATH.get(i).toString(), SCREENSHOT_NAMES,results.get(i).get("ExpectedResult").toString(), results.get(i).get("ActualResult").toString(), results.get(i).get("Test ID").toString());
                testResultTable+=("<tr class=\"content\"><td>" + results.get(i).get("Test ID").toString() +  "</td><td>"+ results.get(i).get("Test Description").toString() +  "</td><td><a href=\"" + resultReport + "\" class=\"btn-wide  btn-danger\">"+ results.get(i).get("Result").toString() + "</a></td></tr>" + "\n" );
            }
        }

        InputStream resultsReader =  new FileInputStream("src\\test\\resources\\MaterialReporting\\TestReportMain.html");
        BufferedReader reader = new BufferedReader(new InputStreamReader(resultsReader));
        String line;

        while((line = reader.readLine()) != null)
        {
            if(line.contains("${totalFailed}"))
            {
                String newLine = line.replace("${totalFailed}", String.valueOf(numberOfFaliures));

                reportBuffer.append(newLine + "\n");
            }
            else if(line.contains("${totalPassed}"))
            {
                String newLine = line.replace("${totalPassed}", String.valueOf(numberPassed));

                reportBuffer.append(newLine + "\n");
            }
            else if(line.contains("${results_table_filler}"))
            {
                String newLine = line.replace("${results_table_filler}",testResultTable);
                reportBuffer.append(newLine + "\n");
            }
            else if(line.contains("${runBy}"))
            {
                String newLine = line.replace("${runBy}", System.getProperty("user.name"));
                reportBuffer.append(newLine + "\n");
            }
            else if(line.contains("${date}"))
            {
                String newLine = line.replace("${date}", new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z").format(new java.util.Date()));
                reportBuffer.append(newLine + "\n");
            }
            else if(line.contains("${totalTests}"))
            {
                String newLine = line.replace("${totalTests}", String.valueOf(results.size()));
                reportBuffer.append(newLine + "\n");
            }
            else if(line.contains("${testEnvironment}"))
            {
                String newLine = line.replace("${testEnvironment}", Environment);
                reportBuffer.append(newLine + "\n");
            }
            else{
                reportBuffer.append(line + "\n");
            }
        }
        resultsReader.close();
        reader.close();
        buildGraphs( results, durations);
    }

    /**
     *
     * @param result
     * @param screenshotsFolder
     * @param screenshotNames
     * @param expectedResult
     * @param actualResult
     * @param testId
     * @return
     * @throws IOException
     */
    public String buildResultsPage(String result, String screenshotsFolder, ArrayList <String> screenshotNames,  String expectedResult, String actualResult, String testId) throws IOException
    {
        StringBuilder screenShotsOwlCarousel = new StringBuilder();
        StringBuffer results = new StringBuffer();
        InputStream resultsReader =  new FileInputStream("src\\test\\resources\\MaterialReporting\\screenshots.html");
        BufferedReader reader = new BufferedReader(new InputStreamReader(resultsReader));
        String line;

        String source = screenshotsFolder;
        File srcDir = new File(source);
        File destDir = new File(fullReportPath  + File.separator + "resources/screenshots");
        try{
            FileUtils.copyDirectory(srcDir, destDir);
        }catch (Exception ex){ System.err.println();}

        for(int i=0 ; i<screenshotNames.size();i++)
        {
            for(int j=0; j< screenshotNames.get(i).split(",").length;j++)
            {
                screenShotsOwlCarousel.append("<div class=\"item\"><a href=\"resources/screenshots/" + screenshotNames.get(i).split(",")[j] +  "\"class=\"image-popup\"><img src=\"resources/screenshots/" + screenshotNames.get(i).split(",")[j] +  "\"alt=\"image\" style=\"width: 85%; margin: auto;\" ></a></div> \n");
            }
        }

        while((line = reader.readLine()) != null) {
            if (line.contains("${result}")) {
                if(result.equals("PASSED"))
                {
                    String newLine = line.replace("${result}", "<a class=\" btn-results-ui btn-success \">Passed</a>");
                    results.append(newLine + "\n");
                }else{
                    String newLine = line.replace("${result}", "<a class=\" btn-results-ui btn-danger \">Failed</a>");
                    results.append(newLine + "\n");
                }
            }
            else if(line.contains("${screenshots}"))
            {
                String newLine = line.replace("${screenshots}",screenShotsOwlCarousel.toString());
                results.append(newLine + "\n");
            }

            else if(line.contains("${ExpectedResult}")) {
                String newLine = line.replace("${ExpectedResult}", expectedResult);
                results.append(newLine + "\n");
            }

            else if(line.contains("${ActualResult}")) {
                String newLine = line.replace("${ActualResult}", actualResult);
                results.append(newLine + "\n");
            }
            else {
                results.append(line + "\n");
            }

            File resultReport = new File(fullReportPath + File.separator + "Screenshots For Test Number" + testId + ".html");
            resultReport.createNewFile();
            FileWriter writer = new FileWriter(resultReport);
            writer.write(String.valueOf(results));
            writer.close();

        }
        return "Screenshots For Test Number" + testId + ".html";
    }

    /**
     *
     * @param args
     * @throws IOException
     * @throws InterruptedException
     */
    public static void main(String [] args) throws IOException, InterruptedException {


        long startTime = System.nanoTime();

        ArrayList<Properties> tester =  new ArrayList<Properties>();
        Properties linkTestOutcome =  new Properties();
        linkTestOutcome.setProperty("Test ID", "1") ;
        linkTestOutcome.setProperty("Test Description", "felix-search-by : Dry Food Button") ;
        linkTestOutcome.setProperty("Result", "FAILED") ;
        linkTestOutcome.setProperty("severity", "S0") ;
        linkTestOutcome.setProperty("ExpectedResult", "FAILED") ;
        linkTestOutcome.setProperty("ActualResult", "FAILED") ;
        tester.add(linkTestOutcome);

        Properties linkTestOutcome2 =  new Properties();
        linkTestOutcome2.setProperty("Test ID", "2") ;
        linkTestOutcome2.setProperty("Test Description", "felix-search-by : Dry Food Button") ;
        linkTestOutcome2.setProperty("Result", "PASSED") ;
        linkTestOutcome2.setProperty("severity", "S0") ;
        linkTestOutcome2.setProperty("ExpectedResult", "FAILED") ;
        linkTestOutcome2.setProperty("ActualResult", "FAILED") ;
        tester.add(linkTestOutcome2);

        Properties linkTestOutcome3 =  new Properties();
        linkTestOutcome3.setProperty("Test ID", "3") ;
        linkTestOutcome3.setProperty("Test Description", "felix-" +
                "-by : Dry Food Button") ;
        linkTestOutcome3.setProperty("Result", "FAILED") ;
        linkTestOutcome3.setProperty("severity", "S0") ;
        linkTestOutcome3.setProperty("ExpectedResult", "FAILED") ;
        linkTestOutcome3.setProperty("ActualResult", "FAILED") ;
        tester.add(linkTestOutcome3);

        TestReportForUI TestReportForUI = new TestReportForUI("C:\\Reports");
        ArrayList screenshots  = new ArrayList();
        screenshots.add("C:\\selenium\\2017-08-03 03-19-49 -050\\19.0-Generate Quotation Valid Data CIF Code Present");
        screenshots.add("C:\\selenium\\2017-08-03 03-19-49 -050\\19.0-Generate Quotation Valid Data CIF Code Present");
        screenshots.add("C:\\selenium\\2017-08-03 03-19-49 -050\\19.0-Generate Quotation Valid Data CIF Code Present");
        ArrayList screenshotNames = new ArrayList();
        screenshotNames.add("19.0-Generate Quotation Valid Data CIF Code Present-_4.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_5.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_6.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_7.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_8.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_9.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_10.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_11.jpg");
        screenshotNames.add("19.0-Generate Quotation Valid Data CIF Code Present-_4.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_5.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_6.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_7.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_8.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_9.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_10.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_11.jpg");
        screenshotNames.add("19.0-Generate Quotation Valid Data CIF Code Present-_4.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_5.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_6.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_7.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_8.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_9.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_10.jpg,19.0-Generate Quotation Valid Data CIF Code Present-_11.jpg");

        long endTime = System.nanoTime();
        ArrayList  executionTimes = new ArrayList();
        for(int i =0; i<3; i++)
        {
            startTime = System.nanoTime();
            Thread.sleep(500);
            endTime = System.nanoTime();
            executionTimes.add(endTime - startTime);
        }
        TestReportForUI.createReportFile("Home Loans Redesign", "Merchant Originator Test");
        TestReportForUI.buildReport(tester, "TEST", screenshots, screenshotNames, executionTimes);
        TestReportForUI.writeReportFile();
    }
}

