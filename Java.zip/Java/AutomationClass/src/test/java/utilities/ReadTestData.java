package utilities;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;

/**
 * * Created by MbamboS on 2017-02-03.
 * * Simple Java Program to read and write dates from Excel Data Sheets.
 * * Particularly read Excel Data file in OLE format i.e.
 * * Excel file with extension .xls, also known as XLS files.
 */

public class ReadTestData {
    /**Java method to read data from Excel Data sheet.
     * This method read value from .XLS file, which is an OLE format.
     * @param file
     * @throws IOException
     */
    public HashMap readCurrentTestData(String file,String sheet,  int testCaseNumber) throws IOException{
        HashMap<String,String> rowOfData =new HashMap<String, String>();
        XSSFWorkbook myExcelBook = new XSSFWorkbook(new FileInputStream(file));
        XSSFSheet myExcelSheet = myExcelBook.getSheet(sheet);
        XSSFRow row = myExcelSheet.getRow(testCaseNumber);
        XSSFRow headerRow = myExcelSheet.getRow(0);
        for(int columnNumber=0; columnNumber<headerRow.getPhysicalNumberOfCells(); columnNumber++)
        {
            if(columnNumber==0)
            {
                rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(),String.valueOf(row.getCell(columnNumber).getNumericCellValue()));
            }
            else{
                //try{
                    Cell data = row.getCell(columnNumber);
                    if(data==null)
                    {
                        rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(),"");
                    }
                    else{
                        data.setCellType(Cell.CELL_TYPE_STRING);
                        rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(),data.getStringCellValue());
                    }

                /*}
                catch (Exception e)
                {
                    rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(),"");
                }*/
            }
        }
        myExcelBook.close();
        return rowOfData;
    }

    /**Java method to read data from Excel Data sheet.
     * This method read value from .XLS file, which is an OLE format.
     * @param file
     * @throws IOException
     */
    public HashMap readRandomTestData(String file,String sheet,  int testCaseNumber) throws IOException{
        HashMap<String,String> rowOfData =new HashMap<String, String>();
        XSSFWorkbook myExcelBook = new XSSFWorkbook(new FileInputStream(file));
        XSSFSheet myExcelSheet = myExcelBook.getSheet(sheet);
        XSSFRow row = myExcelSheet.getRow(testCaseNumber);
        XSSFRow headerRow = myExcelSheet.getRow(0);
        for(int columnNumber=0; columnNumber<headerRow.getPhysicalNumberOfCells(); columnNumber++)
        {
            if(columnNumber==0)
            {
                rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(),String.valueOf(row.getCell(columnNumber).getNumericCellValue()));
            }
            else{
                //try{
                Cell data = row.getCell(columnNumber);
                if(data==null)
                {
                    rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(),"");
                }
                else{
                    data.setCellType(Cell.CELL_TYPE_STRING);
                    rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(),data.getStringCellValue());
                }

                /*}
                catch (Exception e)
                {
                    rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(),"");
                }*/
            }
        }
        myExcelBook.close();
        return rowOfData;
    }

}
