package utilities;

import com.sun.deploy.net.proxy.*;

import java.net.*;

/**
 * This class finds the Host and Port used by the proxy, given a particular URL.
 * This class is used for intances where the proxy is automatically set using a ".pac' file, as set up in Internet options.
 * Before you can use this class, you'll have to make modifications in you java Policy File.
 * The instructions for doing that can be found on this link :
 * https://docs.oracle.com/javase/tutorial/security/tour1/wstep1.html
 * Or look up how to edit a java policy file on Google.
 * Created by ABSMBGL on 2018-02-01.
 */
public class ProxyManager {

    private String proxyHost;
    private String proxyPort;

    /**
     *
     * @param httpPacsFileUrl - The URL for the auto config proxy file. Usually found under your IE Proxy settings, and has a .pacs extension.
     * @param webServiceUrl - The URL of the service your'e testing.
     * @return a hash map that contains the proxy host and port, based on the supplied URL as strings.
     */
    public void findProxyForURL(String httpPacsFileUrl, String webServiceUrl, String javaPolicyFileLocation) throws ProxyConfigException, MalformedURLException, ProxyUnavailableException {
        //This informs the Java JDK that you have given the code permission to read the classes used here.
        System.setProperty("java.security.policy" , javaPolicyFileLocation);

        //Info that will be used to acquire the proxy data.
        BrowserProxyInfo b = new BrowserProxyInfo();
        b.setType(ProxyType.AUTO);
        b.setAutoConfigURL(httpPacsFileUrl);
        SunAutoProxyHandler handler = new SunAutoProxyHandler();
        handler.init(b);

        //Iterate through the list of proxy details that are used by the auto config server for the provided URL.
        //Usually only one proxy is returned.
        ProxyInfo[] ps = handler.getProxyInfo(new URL(webServiceUrl));
        for(ProxyInfo p : ps){
            System.out.println(p.toString());
            String [] proxy = p.toString().split(":");
            this.proxyHost = proxy[0].replace(":","");
            this.proxyPort = proxy[1].replace(":","");

        }
    }

    /**
     *
     * @return a proxy object, in line with the system wide proxy settings.
     */
    public Proxy initializeHttpProxy(String httpPacsFileUrl, String webServiceUrl, String javaPolicyFileLocation) throws ProxyUnavailableException, ProxyConfigException, MalformedURLException {
        findProxyForURL(httpPacsFileUrl,  webServiceUrl, javaPolicyFileLocation);
        SocketAddress addr = new InetSocketAddress(this.getProxyHost(), Integer.valueOf(this.getProxyPort()));
        return new Proxy(Proxy.Type.HTTP, addr);
    }

    /**
     * Gets the proxy host.
     * @return
     */
    public String getProxyHost()
    {
        return proxyHost;
    }

    /**
     * Gets the proxy port.
     * @return
     */
    public String getProxyPort()
    {
        return proxyPort;
    }

}
