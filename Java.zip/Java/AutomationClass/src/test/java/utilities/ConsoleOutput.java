package utilities;

/**
 * Created by ABSMBGL on 2017-11-16.
 */
public class ConsoleOutput {
    public void printRunInformation(String testID, String testDescription){
        String runInfo = "          Now Running :  " +  testID + "     " + testDescription;
        int boxLength = runInfo.length();
        for(int height=0; height<3; height++){
            for(int j=boxLength + 10 ; j >0; j--){
                if(j>boxLength-4)
                {
                    System.out.print("*");
                }
               if(height!=1)
               {
                   System.out.print("*");
               }
                if(j<10)
                {
                    System.out.print("*");
                }
            }
            if(height==1)
            {
                System.out.print(runInfo);
            }
            System.out.println();
        }
        System.out.println();
        System.out.println();
    }


    public void printFeedBack(String consoleFeedBack){
        String feedback = "         " + consoleFeedBack;
        int boxLength = feedback.length();
        for(int height=0; height<3; height++){
            for(int j=boxLength + 10 ; j >0; j--){
                if(height!=1)
                {
                    System.out.print("*");
                }
            }
            if(height==1)
            {
                System.out.print(feedback);
                System.out.println();
            }
            System.out.println();
        }
        System.out.println();
        System.out.println();
    }

    public static void main(String [] args) throws InterruptedException {
    ConsoleOutput cons = new ConsoleOutput();
    cons.printRunInformation("1", "Sdumisilejfkgfujfgqiwfpqwodjkiwqdhowhf");
    Thread.sleep(1000);
    cons.printFeedBack("Doing Some Stuff");
    }
}
