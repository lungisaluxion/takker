package utilities;

import java.util.ArrayList;
import java.util.Properties;

/**
 * Created by ABSMBGL on 2018-03-19.
 */
public class TestResultsHolder {
    public static ArrayList <ArrayList<Properties>> results = new ArrayList <ArrayList<Properties>>();
    public static ArrayList <ArrayList> screenShotsCollection = new ArrayList<ArrayList>();
    public static ArrayList <ArrayList> screenShotsFolderCollection = new ArrayList<ArrayList>();
    public static ArrayList <ArrayList> collectionOfDurations = new ArrayList<ArrayList>();
    public static ArrayList<String> TestSuiteNames =  new ArrayList<String>();
}
