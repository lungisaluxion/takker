package utilities;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;


import javax.xml.soap.SOAPMessage;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;

/**
 * Created by MbamboS on 2017-02-03.
 */
public class HelperMethods {

    public HashMap getTestData(String dataSheetPath, String sheet, int testCaseNumber) throws IOException {
       return new dataproviders.ReadTestDataExcel().readCurrentTestData(dataSheetPath,sheet,testCaseNumber);
    }

    public boolean checkFailure(ArrayList<Properties> results)
    {
        boolean anyFailures =false;
        for(int i=0; i< results.size(); i++)
        {
            if(results.get(i).getProperty("Result").equalsIgnoreCase("FAILED")){
                anyFailures = true;
            }
        }
        return anyFailures;
    }

    public int rowsInSheet(String fileName, String sheet) throws IOException
    {
        XSSFWorkbook myExcelBook = new XSSFWorkbook(new FileInputStream(fileName));
        XSSFSheet myExcelSheet = myExcelBook.getSheet(sheet);
        return myExcelSheet.getPhysicalNumberOfRows();
    }

    /**
     * Returns the current date time as specifide by the format string.
     * Used in circumstances usually, when a unique number is needed in a request/test.
     * @param format
     * @return
     */
    public static String getCurrentDateTimeStamp(String format)
    {
        SimpleDateFormat DateFormat = new SimpleDateFormat(format);
        Date now = new Date();

        String sDate = DateFormat.format(now);
        return sDate;
    }


    public static void getScreenShot( String fileName, WebDriver webDriver )
    {
        try
        {
            File screenFile = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(screenFile, new File(fileName));
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public HashMap saveTestFiles(String request, String response, String fileLocation) throws IOException {
        String requestFilePath = fileLocation + "/request_" + String.valueOf(System.currentTimeMillis() + ".xml");
        String responseFilePath = fileLocation + "/response_" + String.valueOf(System.currentTimeMillis() + ".xml");
        FileWriter requestFile = new FileWriter(requestFilePath);
        FileWriter responseFile = new FileWriter(responseFilePath);
        BufferedWriter bw = new BufferedWriter(requestFile);
        BufferedWriter bwResponse = new BufferedWriter(responseFile);
        bw.write(request);
        bwResponse.write(response);
        bw.close();
        bwResponse.close();
        HashMap files = new HashMap();
        files.put("REQUEST_PATH", requestFilePath);
        files.put("RESPONSE_PATH", responseFilePath);
        return files;
    }
    public String soapMessageToString(SOAPMessage message){
        String result = null;
        if (message != null)
        {
            ByteArrayOutputStream baos = null;
            try
            {
                baos = new ByteArrayOutputStream();
                message.writeTo(baos);
                result = baos.toString();
            }
            catch (Exception e)
            {
                System.err.println(" The Following Error Occurred : " + e.toString());
            }
            finally
            {
                if (baos != null)
                {
                    try
                    {
                        baos.close();
                    }
                    catch (IOException ioe)
                    {
                        System.err.println(" The Following Error Occurred : " + ioe.toString());
                    }
                }
            }
        }
        return result;
    }


    public String getTextBetweenTags(String requestString, String tag1, String tag2)
    {
        String [] tempString = requestString.split(tag1);
        return tempString[1].split(tag2)[0];
    }

    /**
     * Convert a JSON string to pretty print version
     * @param jsonString
     * @return
     */
    public String toPrettyFormat(String jsonString)
    {
        JsonParser parser = new JsonParser();
        JsonObject json = parser.parse(jsonString).getAsJsonObject();

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String prettyJson = gson.toJson(json);

        return prettyJson;
    }



}
