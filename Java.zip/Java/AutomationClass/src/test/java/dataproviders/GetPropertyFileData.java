package dataproviders;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Reads the data in the test properties file.
 * Created by mbambos2 on 2017-02-06.
 */
public class GetPropertyFileData {
    private InputStream propertiesInputStream;

    public Properties getPropValues(String propertyFile) throws IOException {
        Properties prop = new Properties();
        try {
            propertiesInputStream = getClass().getClassLoader().getResourceAsStream(propertyFile);
            if (propertiesInputStream != null) {
                prop.load(propertiesInputStream);
            } else {
                throw new FileNotFoundException("property file '" + propertyFile + "' not found.");
            }
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        } finally {
            assert propertiesInputStream != null;
            propertiesInputStream.close();
        }
        return prop;
    }
}
