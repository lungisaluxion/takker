### ESP Performance Test Configs

Command to execute jmeter config:
	* jmeter -n -t path\to\config\fileName.jmx -l path\to\report\fileName.csv
	 
This will run JMeter on terminal(Non GUI).
