package reporting;

import org.apache.commons.io.FileUtils;

import java.io.*;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.logging.Logger;

/**
 *  Test Report.
 *  This is a class that generates an HTML test execution report.
 *  @version 1.0
 * @author ABSMBGL
 * @since 2017-10-27.
 */
public class TestReport {

    private static final Logger LOGGER = Logger.getLogger( TestReport.class.getName());
    //String Buffer that hold the report html in memory.
    public StringBuffer reportBuffer = new StringBuffer("");

    //String buffer that keeps the graphs page html in memory.
    public StringBuffer graphsBuffer = new StringBuffer("");
    public String pathToReportFolder;
    File rootReportFolder;
    String fullReportPath = "";

    /**
     * Constructor.
     * The Constructor to create the report object.
     *
     * @param desiredReportLocation The desired location that the user wants to store the report.
     */
    public TestReport(String desiredReportLocation)
    {
        this.pathToReportFolder = desiredReportLocation;
        rootReportFolder = new File(this.pathToReportFolder);
    }

    /**
     * This method creates the report folder on disk, to be used later when the report
     * is written onto the disk.
     * @param TestSuite - The main test suite the test belongs to. Example 'Home Loans'.
     * @param testName - The name of the test being executed. Example 'Create Application Test'.
     * @throws IOException Throws File not found exception.
     */
    public void createReportFile(String TestSuite, String testName) throws IOException {
        //The hash Map that will hold the location of the report file.
        HashMap<String,File> Files = new HashMap();

        // Create Root Report Folder
        File rootReportFolder = new File( this.pathToReportFolder);

        //check if the folder doesn't already exist on the file system.
        //If the folder already exists, do nothing, else create the folder.
        if (!rootReportFolder.exists()) {
            LOGGER.info("creating directory: " + rootReportFolder);
            try {
                rootReportFolder.mkdir();
            } catch (Exception e) {
                LOGGER.info("Failed to create directory" + rootReportFolder);
            }
        }


        // Root Test Suite Folder [Example : Home Loans.]
        File testFolder = new File( this.pathToReportFolder + File.separator +  TestSuite);
        if (!testFolder.exists()) {
            LOGGER.info("Creating Site directory" + testFolder);

            testFolder.mkdir();
        }


        //Root Test Report Folder  [Example : Search HomeLoans Application Test.]
        File testNameFolder = new File( this.pathToReportFolder + File.separator + TestSuite + File.separator + testName);
        if (!testNameFolder.exists()) {
            LOGGER.info("creating directory: " + testNameFolder);
            testNameFolder.mkdir();
        }

        //HML test report folder
        String reportFolderName = "Automated Test Execution Report_" + new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
        File reportFolder = new File(testNameFolder.getAbsolutePath() + File.separator + reportFolderName);
        LOGGER.info("creating directory: " + reportFolder);
        reportFolder.mkdir();
        fullReportPath = reportFolder.getAbsolutePath();
    }

    /**
     * Write the report folder onto the disk.
     * @throws IOException
     */
    public void writeReportFile() throws IOException{
        File reportFolder = new File(fullReportPath);
        File report = new File(reportFolder.getAbsolutePath() + File.separator + "Automated Test Execution Report.html");
        report.createNewFile();
        FileWriter writer = new FileWriter(report);
        writer.write(String.valueOf(reportBuffer));
        writer.close();

        String source = "src\\test\\resources\\MaterialReporting";
        File srcDir = new File(source);
        File destDir = new File(reportFolder.getAbsolutePath()  + File.separator + "resources");
        try{
            FileUtils.copyDirectory(srcDir, destDir);
        }catch (Exception ex){ System.err.println();}
    }


    /**
     * This method builds the HTML for the report as a string.
     * It reads from a template file found in the resources,
     * and then replaces the place holders with valid .
     * @param results An array list that hold a Test Results Properties.
     * @param Environment Enlivenment The test is run in.
     * @param REQUEST_PATH Path to the request txt.
     * @param RESPONSE_PATH Paths to the responses txt.
     * @param durations Array list of test durations.
     * @throws IOException
     */
    public void buildReport(ArrayList<Properties> results, String Environment,  ArrayList REQUEST_PATH, ArrayList RESPONSE_PATH, ArrayList durations) throws IOException {
        int numberOfFaliures=0;
        int numberPassed=0;
        String  testResultTable ="";
        for(int i=0; i< results.size();i++)
        {
            if(results.get(i).getProperty("Result").equals("PASSED"))
            {
                numberPassed+=1;
                String resultReport = buildResultsPage(results.get(i).get("Result").toString(),REQUEST_PATH.get(i).toString(), RESPONSE_PATH.get(i).toString(), results.get(i).get("ExpectedResult").toString(), results.get(i).get("ActualResult").toString(), results.get(i).get("Test ID").toString());
                testResultTable+=("<tr class=\"content\"><td>" + results.get(i).get("Test ID").toString() +  "</td><td>"+ results.get(i).get("Test Description").toString() +  "</td><td><a href=\"" + resultReport + "\" class=\"btn-wide  btn-success \">"+ results.get(i).get("Result").toString() + "</a></td></tr>"+ "\n" );
            }
            if(results.get(i).getProperty("Result").equals("FAILED"))
            {
                numberOfFaliures+=1;
                String resultReport = buildResultsPage(results.get(i).get("Result").toString(),REQUEST_PATH.get(i).toString(), RESPONSE_PATH.get(i).toString(), results.get(i).get("ExpectedResult").toString(), results.get(i).get("ActualResult").toString(), results.get(i).get("Test ID").toString());
                testResultTable+=("<tr class=\"content\"><td>" + results.get(i).get("Test ID").toString() +  "</td><td>"+ results.get(i).get("Test Description").toString() +  "</td><td><a href=\"" + resultReport + "\" class=\"btn-wide  btn-danger\">"+ results.get(i).get("Result").toString() + "</a></td></tr>" + "\n" );
            }
        }

        InputStream resultsReader =  new FileInputStream("src\\test\\resources\\MaterialReporting\\TestReportMain.html");
        BufferedReader reader = new BufferedReader(new InputStreamReader(resultsReader));
        String line;

        while((line = reader.readLine()) != null)
        {
            if(line.contains("${totalFailed}"))
            {
                String newLine = line.replace("${totalFailed}", String.valueOf(numberOfFaliures));
                reportBuffer.append(newLine + "\n");
            }
            else if(line.contains("${totalPassed}"))
            {
                String newLine = line.replace("${totalPassed}", String.valueOf(numberPassed));
                reportBuffer.append(newLine + "\n");
            }
            else if(line.contains("${results_table_filler}"))
            {
                String newLine = line.replace("${results_table_filler}",testResultTable);
                reportBuffer.append(newLine + "\n");
            }
            else if(line.contains("${runBy}"))
            {
                String newLine = line.replace("${runBy}", System.getProperty("user.name"));
                reportBuffer.append(newLine + "\n");
            }
            else if(line.contains("${date}"))
            {
                String newLine = line.replace("${date}", new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z").format(new java.util.Date()));
                reportBuffer.append(newLine + "\n");
            }
            else if(line.contains("${totalTests}"))
            {
                String newLine = line.replace("${totalTests}", String.valueOf(results.size()));
                reportBuffer.append(newLine + "\n");
            }

            else if(line.contains("${testEnvironment}"))
            {
                String newLine = line.replace("${testEnvironment}", Environment);
                reportBuffer.append(newLine + "\n");
            }
            else{
                reportBuffer.append(line + "\n");
            }
        }
        resultsReader.close();
        reader.close();
        buildGraphs( results, durations);
    }


    /**
     *
     * @param result Test result Pass/Fail.
     * @param requestFolder Folder request txt is sitting on.
     * @param responseFolder  Folder response txr is sitting on.
     * @param expectedResult  Expected Result.
     * @param actualResult Actual Test result.
     * @param testId Test ID/Number.
     * @return void
     * @throws IOException
     */
    public String buildResultsPage(String result, String requestFolder, String responseFolder, String expectedResult, String actualResult, String testId) throws IOException
    {
        StringBuffer results = new StringBuffer();
        InputStream resultsReader =  new FileInputStream("src\\test\\resources\\MaterialReporting\\TestResults.html");
        BufferedReader reader = new BufferedReader(new InputStreamReader(resultsReader));
        String line;

        while((line = reader.readLine()) != null) {
            if (line.contains("${testResultHolder}")) {
                if(result.equals("PASSED"))
                {
                    String newLine = line.replace("${testResultHolder}", "<a class=\" btn-reults btn-success \">Passed</a>");
                    results.append(newLine + "\n");
                }else{
                    String newLine = line.replace("${testResultHolder}", "<a class=\" btn-reults btn-danger \">Failed</a>");
                    results.append(newLine + "\n");
                }
            }
            else if(line.contains("${requestMessage}")) {
                InputStream is = new FileInputStream(requestFolder);
                BufferedReader buf = new BufferedReader(new InputStreamReader(is));
                String requestLine = buf.readLine();
                StringBuilder sb = new StringBuilder();
                while (requestLine != null) {
                    sb.append(requestLine).append("\n");
                    requestLine = buf.readLine();
                }
                String newLine = line.replace("${requestMessage}", sb.toString());
                results.append(newLine + "\n");
            }
            else if(line.contains("${responseMessage}")) {
                InputStream is = new FileInputStream(responseFolder);
                BufferedReader buf = new BufferedReader(new InputStreamReader(is));
                String responseline = buf.readLine();
                StringBuilder sb = new StringBuilder();
                while (responseline != null) {
                    sb.append(responseline).append("\n");
                    responseline = buf.readLine();
                }
                String newLine = line.replace("${responseMessage}", sb.toString());
                results.append(newLine + "\n");
            }
            else if(line.contains("${expectedResult}")) {
                String newLine = line.replace("${expectedResult}", expectedResult);
                results.append(newLine + "\n");
            }

            else if(line.contains("${actualResult}")) {
                String newLine = line.replace("${actualResult}", actualResult);
                results.append(newLine + "\n");
            }
            else {
                results.append(line + "\n");
            }
            File resultReport = new File(fullReportPath + File.separator + "Test Results Test" + testId + ".html");
            resultReport.createNewFile();
            FileWriter writer = new FileWriter(resultReport);
            writer.write(String.valueOf(results));
            writer.close();

        }
        return "Test Results Test" + testId + ".html";
    }

    public void buildGraphs( ArrayList<Properties> results, ArrayList durations) throws IOException {
        int totalCriticalDefects = 0;
        int totalMajorDefects = 0;
        int totalMinorDefects = 0;
        int totalTrivialDefects = 0;

        for(int i=0;i<results.size(); i++)
        {
            if(results.get(i).getProperty("severity").toString().equals("S0"))
            {
                totalCriticalDefects+=1;
            }
            if (results.get(i).getProperty("severity").toString().equals("S1"))
            {
                totalMajorDefects+=1;
            }
            if(results.get(i).getProperty("severity").toString().equals("S2"))
            {
                totalMinorDefects+=1;
            }
            if(results.get(i).getProperty("severity").toString().equals("S3"))
            {
                totalTrivialDefects+=1;
            }

        }
        long sumOfDurations = 0;

        for(int i=0 ; i< durations.size(); i++)
        {
            sumOfDurations= sumOfDurations + Long.valueOf(durations.get(i).toString());
        }

        long averageDurations = sumOfDurations / durations.size();
        final double convertedToSeconds = ((double)averageDurations / 1000000000);

        NumberFormat formatter = new DecimalFormat("#0.00");
        String formattedSeconds = formatter.format(convertedToSeconds);
        InputStream resultsReader =  new FileInputStream("src\\test\\resources\\MaterialReporting\\graphs.html");
        BufferedReader reader = new BufferedReader(new InputStreamReader(resultsReader));
        String line;

        while((line = reader.readLine()) != null) {
            if (line.contains("${critical}")) {
                String newLine = line.replace("${critical}", String.valueOf(totalCriticalDefects));
                graphsBuffer.append(newLine + "\n");
            } else if (line.contains("${major}")) {
                String newLine = line.replace("${major}", String.valueOf(totalMajorDefects));

                graphsBuffer.append(newLine + "\n");
            } else if (line.contains("${minor}")) {
                String newLine = line.replace("${minor}",  String.valueOf(totalMinorDefects));
                graphsBuffer.append(newLine + "\n");
            } else if (line.contains("${trivial}")) {
                String newLine = line.replace("${trivial}",String.valueOf(totalTrivialDefects));
                graphsBuffer.append(newLine + "\n");
            }else if (line.contains("${duration}")) {
                String newLine = line.replace("${duration}",formattedSeconds);
                graphsBuffer.append(newLine + "\n");
            }
            else{
                graphsBuffer.append(line + "\n");
            }
        }

        File resultReport = new File(fullReportPath + File.separator + "graphs.html");
        resultReport.createNewFile();
        FileWriter writer = new FileWriter(resultReport);
        writer.write(String.valueOf(graphsBuffer));
        writer.close();
    }
}
