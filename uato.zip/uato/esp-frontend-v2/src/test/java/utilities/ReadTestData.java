package utilities;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

/**
 * * Created by MbamboS on 2017-02-03.
 * * Simple Java Program to read and write dates from Excel Data Sheets.
 * * Particularly read Excel Data file in OLE format i.e.
 * * Excel file with extension .xls, also known as XLS files.
 */

public class ReadTestData {
    /**Java method to read data from Excel Data sheet.
     * This method read value from .XLS file, which is an OLE format.
     * @param file
     * @throws IOException
     */
    public LinkedHashMap readCurrentTestData(String file,String sheet,  int testCaseNumber) throws IOException{
        LinkedHashMap<String,String> rowOfData =new LinkedHashMap<String, String>();
        XSSFWorkbook myExcelBook = new XSSFWorkbook(new FileInputStream(file));
        XSSFSheet myExcelSheet = myExcelBook.getSheet(sheet);
        XSSFRow row = myExcelSheet.getRow(testCaseNumber);
        XSSFRow headerRow = myExcelSheet.getRow(0);
        for(int columnNumber=0; columnNumber<headerRow.getLastCellNum(); columnNumber++)
        {
            if(columnNumber==0)
            {
                rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(),String.valueOf(row.getCell(columnNumber).getNumericCellValue()));
            }
            else{
                //try{
                    Cell data = row.getCell(columnNumber);
                    if(data==null)
                    {
                        rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(),"");
                    }
                    else{
                        data.setCellType(Cell.CELL_TYPE_STRING);
                        rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(),data.getStringCellValue());
                    }

                /*}
                catch (Exception e)
                {
                    rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(),"");
                }*/
            }
        }
        myExcelBook.close();
        return rowOfData;
    }

    public static Map<String,Map<String, Map<String,String>>> readCurrentTestData_v2(String dataPath, String sheetName,int testId)throws Exception{
        LinkedHashMap<String,Integer> rowOfData = new LinkedHashMap<>();
        LinkedHashMap<String,Map<String, Map<String,String>>> main = new LinkedHashMap<>();


        XSSFWorkbook myExcelBook = new XSSFWorkbook(new FileInputStream(dataPath));
        XSSFSheet myExcelSheet = myExcelBook.getSheet(sheetName);

        XSSFRow headerRow2 = myExcelSheet.getRow(1);
        XSSFRow headerRow3 = myExcelSheet.getRow(2);

        XSSFRow row = myExcelSheet.getRow(testId+2);
        XSSFRow headerRow = myExcelSheet.getRow(0);
        //int count= 0;
        String strHeaderRow1= "";
        String strHeaderRow2 = "";

        System.out.println("Sheet : "+sheetName+"ID : "+testId);
        for (int columnNumber = 2; columnNumber < headerRow.getLastCellNum(); columnNumber++) {
            try {
                //System.out.println(headerRow.getCell(columnNumber).getStringCellValue());
                if(!headerRow.getCell(columnNumber).getStringCellValue().equals("") ){
                    strHeaderRow1 = headerRow.getCell(columnNumber).getStringCellValue();
                    main.put(headerRow.getCell(columnNumber).getStringCellValue(),new LinkedHashMap<>());
                }
                if(!headerRow2.getCell(columnNumber).getStringCellValue().equals("")){
                    strHeaderRow2 = headerRow2.getCell(columnNumber).getStringCellValue();
                    main.get(strHeaderRow1).put(headerRow2.getCell(columnNumber).getStringCellValue(),new LinkedHashMap<>());
                }
                if(!headerRow3.getCell(columnNumber).getStringCellValue().equals("")){
                    Cell data = row.getCell(columnNumber);
                    data.setCellType(Cell.CELL_TYPE_STRING);
                    try {
                        //main.get(strHeaderRow1).get(strHeaderRow2).put(headerRow3.getCell(columnNumber).getStringCellValue(),row.getCell(columnNumber).getStringCellValue());
                        main.get(strHeaderRow1).get(strHeaderRow2).put(headerRow3.getCell(columnNumber).getStringCellValue(),data.getStringCellValue());
                    }catch (IllegalStateException e1){
                        main.get(strHeaderRow1).get(strHeaderRow2).put(headerRow3.getCell(columnNumber).getStringCellValue(),String.valueOf(row.getCell(columnNumber).getNumericCellValue()));
                    }

                }





                //rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(), String.valueOf(row.getCell(columnNumber).getNumericCellValue()));
            }catch (NullPointerException e)
            {
                System.out.println(e.getMessage());
                //rowOfData.put("", String.valueOf(row.getCell(columnNumber).getNumericCellValue()));

            }


        }

        myExcelBook.close();

        return main;


    }
    /**Java method to read data from Excel Data sheet.
     * This method read value from .XLS file, which is an OLE format.
     * @param file
     * @throws IOException
     */
    public LinkedHashMap readRandomTestData(String file,String sheet,  int testCaseNumber) throws IOException{
        LinkedHashMap<String,String> rowOfData =new LinkedHashMap<String, String>();
        XSSFWorkbook myExcelBook = new XSSFWorkbook(new FileInputStream(file));
        XSSFSheet myExcelSheet = myExcelBook.getSheet(sheet);
        XSSFRow row = myExcelSheet.getRow(testCaseNumber);
        XSSFRow headerRow = myExcelSheet.getRow(0);
        for(int columnNumber=0; columnNumber<headerRow.getPhysicalNumberOfCells(); columnNumber++)
        {
            if(columnNumber==0)
            {
                rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(),String.valueOf(row.getCell(columnNumber).getNumericCellValue()));
            }
            else{
                //try{
                Cell data = row.getCell(columnNumber);
                if(data==null)
                {
                    rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(),"");
                }
                else{
                    data.setCellType(Cell.CELL_TYPE_STRING);
                    rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(),data.getStringCellValue());
                }

                /*}
                catch (Exception e)
                {
                    rowOfData.put(headerRow.getCell(columnNumber).getStringCellValue(),"");
                }*/
            }
        }
        myExcelBook.close();
        return rowOfData;
    }

    public ArrayList<Integer> readAddEntityTestData(String file,String sheet,  int testCaseNumber) throws IOException{
        XSSFWorkbook myExcelBook = new XSSFWorkbook(new FileInputStream(file));
        XSSFSheet myExcelSheet = myExcelBook.getSheet(sheet);
        XSSFRow headerRow = myExcelSheet.getRow(0);

        int testIdColumnNumber = 0;
        ArrayList<Integer> rowNumbers = new ArrayList<>();
        for(int columnNumber=0; columnNumber < headerRow.getPhysicalNumberOfCells(); columnNumber++){
            if(myExcelSheet.getRow(0).getCell(columnNumber).toString().equalsIgnoreCase("TestID"))
                testIdColumnNumber = columnNumber;
        }

        for(int rowNumber = 1; rowNumber< myExcelSheet.getPhysicalNumberOfRows(); rowNumber++){
            try {
                double cellData = Double.parseDouble(myExcelSheet.getRow(rowNumber).getCell(testIdColumnNumber).toString());
                int cellDataInt = ((int) cellData);
                if(cellDataInt==testCaseNumber)
                    rowNumbers.add(rowNumber);
            }catch (Exception e){
                System.out.println(e.getMessage());
            }

        }

        myExcelBook.close();
        return rowNumbers;
    }

    public static LinkedHashMap fetchTestData(String path, String sheet, int id) throws IOException {
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
      return new HelperMethods().getTestData(espProperties.getProperty(path).toString(), sheet, id);
    }


}
