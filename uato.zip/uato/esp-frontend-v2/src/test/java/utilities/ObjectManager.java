package utilities;

public class ObjectManager {

    //public static final String WorkbenchMinimizeBtn ="xpath||//*[text()='Work Bench / Select Customer']/../../div[2]/img";
    public static final String WorkbenchMinimizeBtn = "xpath||//*[text()='Work Bench / Select Customer']/following :: div[@class = 'x-tool-tool-el x-tool-img x-tool-collapse-left ']";
    public static final String WorkbenchMaximizeBtn = "//*[text()='Work Bench / Select Customer']/preceding :: img[contains(@class, 'x-tool-img x-tool-expand-right')]";
    public static final String MinimizeIssues = "//*[@id = 'pnlErrors_header']/child :: div//img";
    public static final String MinimizeWorkHistory = "//div[text() = 'Work Bench / Select Customer']/following :: div[@class = 'x-tool-tool-el x-tool-img x-tool-collapse-left ']";
    public static final String OnBoarding ="xpath||//*[text()='On-Boarding']";
    public static final String OnBoardingInstruction ="xpath||//span[text()='On-Boarding']/following::span[contains(text(), 'My Instructions')]";
    public static final String ProductInstruction ="xpath||//span[text()='Product']/following::span[contains(text(), 'Administration')]";

    public static final String CreateInstruction ="xpath||//span[@id='DashboardUserControl_btnCreate-btnEl']";
    public static final String   COB_Screening_ConfirmMsg = "//div//*[text()='Save Successfull']/following :: *[@class = 'x-tool-tool-el x-tool-img x-tool-pin ']";




    public static final String BasicClientInformation = "xpath||//span[text()='Basic Client Information']";
    public static final String LegalEntityType ="xpath||//input[contains(@id, 'cmbLegalEntityType-input')]";
    public static final String lsLegalEnetityType ="//*[@id='ManageBasicControl_InitiationControl_cmbLegalEntityType-trigger-picker']";
    public static final String LegalEntity = "xpath||//input[contains(@id, 'cmbLegalEntity-input')]";
    public static final String lsLegalEnetity ="//*[@id='ManageBasicControl_InitiationControl_cmbLegalEntity-trigger-picker']";
    public static final String lsPrimaryRole ="//*[@id='ManageBasicControl_InitiationControl_cmbPrimaryRole-trigger-picker']";
    public static final String SelectLegalEntity ="xpath||//li[contains(text(),'Close Corporations')]";
    public static final String EntityIDOrRegistrationNumber ="xpath||//input[@id = 'ManageBasicControl_InitiationControl_txtIDRegNo-inputEl']";//ManageBasicControl_InitiationControl_txtName-inputEl
    public static final String searchClientButton = "xpath||//span[contains(@id, 'btnSearch-btnInner')]";

    public static final String ExistingCustomerPopUp = "xpath||//*[@id='ManageBasicControl_InitiationControl_ESPSearchControl_dvResults']/div";
    public static final String ExistingCustomerPopUpCreateBtn = "xpath||";
    public static final String ExistingCustomerPopUpConformBtn = "xpath||";
    public static final String lsInstructionSubType ="//*[@id = 'ManageBasicControl_InitiationControl_ddlInstructionSubType-trigger-picker']";
   // public static final String simplex ="//*[contains(@id, 'ManageBasicControl_InitiationControl_cmbSimplex-bodyEl')]//tbody/tr/td[1]/input/following :: td/div[contains(@class, 'x-trigger-index-0 x-form-trigger x-form-arrow-trigger x-form-trigger-first')]";
    public static final String simplex = "//*[@id = 'ManageBasicControl_InitiationControl_cmbSimplex-trigger-picker']";
    public static final String lsInstructionCreateBtn ="xpath||//*[@id='ManageBasicControl_InitiationControl_btnCreate-btnInnerEl']";


   // public static final String txtSearchAddPartyResult ="//div[@id='ManageBasicControl_RelatedTreeControl_ESPSearchControl_dvResults']/child::div//div[contains(text(),'ID  Reg Number:')]";
    //public static final String txtSearchAddPartyResult ="//div[@id='ManageBasicControl_InitiationControl_ESPSearchControl_dvResults']";
    //public static final String btnSearchAddPartyConfirm ="//*[@id='ManageBasicControl_RelatedTreeControl_ESPSearchControl_btnConfirm-btnInnerEl']";
   // public static final String btnSearchAddPartyConfirm ="xpath||//*[@id='ManageBasicControl_InitiationControl_ESPSearchControl_btnConfirm-btnWrap']";


    public static final String BCI_AddEntityOrIndividual="xpath||//span[contains(text(),'Add...')]";
    public static final String BCI_EditEntityOrIndividual="xpath||//span[contains(text(),'Edit...')]";
    public static final String lsAddParty="//div[@id = 'ManageBasicControl_RelatedTreeControl_cmbLegalEntity-trigger-picker']";
    public static final String II_IDOrRegName = "xpath||//input[contains(@id,'ManageBasicControl_RelatedTreeControl_txtName-input')]";
    public static final String II_IDOrReg = "xpath||//input[@id = 'ManageBasicControl_RelatedTreeControl_txtIDRegNo-inputEl']";

    public static final String btnSearchAddParty="xpath||//span[@id='ManageBasicControl_RelatedTreeControl_btnSearch-btnWrap']";
    public static final String txtSearchAddPartyResult ="//div[@id]/child::div//div[contains(text(),'ID  Reg Number:')]";
    public static final String btnSearchExistingCustomerConfirm ="xpath||//span[contains(@id,'ManageBasicControl_InitiationControl_ESPSearchControl_btnConfirm-btnEl')]";
    public static final String btnSearchAddPartyConfirm ="//*[@id='ManageBasicControl_RelatedTreeControl_ESPSearchControl_btnConfirm-btnInnerEl']";


    public static final String II_ClientType = "//div[table//span[text()='Client type ']]/following-sibling::table//input";
    public static final String txtBoxTrustDeedNumber = "//div[table//span[contains(text(),'Trust / pension / provident / other fund number')]]/following-sibling::table//input";
    public static final String BCI_DateEstablished = "//div[table//span[text()='Date established']]/following-sibling::table//input";
    public static final String lstSolePropCountryOfIncorporation ="//div[table//span[contains(text(),'Country of incorporation')]]/following-sibling::table//table//input";

    public static  final  String BCI_btnSave ="//*[@id='ManageBasicControl_ReqFieldsPrimaryControl_btnSave-btnInnerEl']";
    public static  final  String PI_btnSave = "//*[@id='ManageBasicControl_RelatedTreeControl_ReqFieldsControl_btnSave-btnInnerEl']";

    //**************************************************
    public static final String   Co_OperativeSubType = "//div[table//span[contains(text(),'Co-operative subtype')]]/following-sibling :: table//table//td[2]//div";
    //Co-operative subtype
    public static final String   lstTagertBusinessUnitSegment ="//div[table//span[contains(text(),'Target business unit segment')]]/following-sibling :: table//table//td[2]//div";
    public static final String   lstTagertBusinessDevision ="//div[table//span[contains(text(),'Division')]]/following-sibling::table//table//td[2]//div";

    public static final String   COB_CD_TaxSouthAfrica = "//div[table//span[text()='Registered for Tax in South Africa']]/following-sibling::table//table//td[2]//div";
    public static final String   COB_CD_VatSouthAfrica = "//div[table//span[text()='Registered for VAT in South Africa']]/following-sibling::table//table//td[2]//div";
    public static final String   COB_CD_ForeignTax = "//div[table//span[text()='Registered for Foreign Tax']]/following-sibling::table//table//td[2]//div";
    public static final String   COB_CD_FinancialYearEnd = "//div[table//span[text()='Financial year end']]/following-sibling::table//table//td[2]//div";
    public static final String   COB_CD_SATaxNumberAvailable = "//div[table//span[text()='SA Tax number avaible for capture']]/following-sibling::table//table//td[2]//div";
    public static final String   COB_CD_IncomeTaxRegNumber = "//div[table//span[text()='Income tax registration number']]/following-sibling::table//input";
    public static final String   COB_CD_ReasonSATaxNumberNotGiven = "//div[table//span[text()='Reason SA Tax number not given']]/following-sibling::table//input";
    public static final String   COB_CD_SourceOfIncomePanel = "//*[text() = 'Source Of Income']/../../following::";
    public static final String   COB_CD_ClientCode = "div[table//span[text()='Client code']]/following-sibling::table//input";
    public static final String   COB_CD_AccountType = "div[table//span[text()='Account type']]/following-sibling::table//input";
    public static final String   COB_CD_ExplanationForSourceOfIncome = "//div[table//span[text()='Comments on explanation given for source of income']]/following-sibling::table//textarea";

    public static final String   COB_CD_ClientInvolveInAgric = "//div[table//span[text()='Is the client involved in agriculture, hunting, forestry or fishing']]/following-sibling::table//table//td[2]//div";

    public static final String   COB_CD_SICCode = "//div[table//span[text()='Is the SIC code being changed as part of this work item']]/following-sibling::table//table//td[2]//div";
    public static final String   COB_CD_PracticeNumber = "//div[table//span[text()='Practice number']]/following-sibling::table//input";


    public static final String   COB_CD_ClientUnderCPA = "//div[table//span[text()='Does the client fall under the CPA']]/following-sibling::table//table//td[2]//div";
    public static final String   COB_CD_ClientUnderNCA = "//div[table//span[text()='Does the client fall under the NCA']]/following-sibling::table//table//td[2]//div";

    public static final String   COB_CD_ClientCategory = "//div[table//span[text()='Client category']]/following-sibling::table//table//td[2]//div";

    public static final String   COB_CD_SPV = "//div[table//span[text()='Is the client a Special Purpose Vehicle (SPV)']]/following-sibling::table//table//td[2]//div";

    public static final String   COB_CD_ClientExemptFICA= "//div[table//span[text()='Is the client exempt from FICA']]/following-sibling::table//table//td[2]//div";

    public static final String   COB_CD_MonthlyIcome = "//div[table//span[text()='Monthly income']]/following-sibling::table//table//td[2]//div";
    public static final String   COB_CD_SourceOfIncome = "//div[table//span[text()='Source of income']]/following-sibling::table//table//td[2]//div";
    public static final String   COB_CD_SourceOfIncomeSatisfactory = "//div[table//span[text()='Was the clients explanation of source of income satisfactory']]/following-sibling::table//table//td[2]//div";
    public static final String   COB_CD_FinancialDefineInFAIS = "//div[table//span[text()='Is the client rendering financial services as defined in the FAIS act']]/following-sibling::table//table//td[2]//div";
    public static final String   txtBoxTradingName = "//div[table//span[contains(text(),'Trading name')]]/following-sibling::table//input";


    //*************************************** [Related Party (Party Information)] *******************************//

    public static final String txtBoxPercentage = "//div[table//span[text()='Percentage ownership / control']]/following-sibling::table//input";
    public static final String lstTitle = "//div[table//span[contains(text(),'Title')]]/following-sibling::table//table//td/*[contains(@class,'x-form-trigger')]";
    public static final String txtBoxInitials = "//div[table//span[text()='Initials']]/following-sibling::table//input";
    public static final String txtBoxFirstName = "//div[table//span[text()='First name(s)']]/following-sibling::table//input";
    public static final String txtBoxSurname = "//div[table//span[text()='Surname']]/following-sibling::table//input";
    public static final String txtBoxGender = "//div[table//span[text()='Gender']]/following-sibling::table//table//input";

    public static final String txtBoxIDOrPassportNumber = "//div[table//span[text()='Identification / passport number']]/following-sibling::table//input";
    public static final String txtBoxIDType = "//div[table//span[text()='ID type']]/following-sibling::table//table//input";
    public static final String txtBoxIdentityInformationIDType = "//div[table//span[text()='ID type']]/following-sibling::table//table//input";
    public static final String txtBoxDateOfBirth = "//div[table//span[contains(text(),'Date of birth')]]/following-sibling::table//input";
    public static final String txtBoxDateIdentification = "//div[table//span[contains(text(),'Date identification')]]/following-sibling::table//input";
    public static final String txtBoxExpiryDate = "//div[table//span[contains(text(),'Expiry date')]]/following-sibling::table//input";
    public static final String lstCountryOfBirth = "//div[table//span[contains(text(),'Country of birth')]]/following-sibling::table//table//input";    public static final String lstNationality = "//div[table//span[contains(text(),'Nationality')]]/following-sibling::table//table//td/*[contains(@class,'x-form-trigger')]";
    public static final String multipleNationalities = "//div[table//span[contains(text(),'Does the person have multiple nationalities')]]/following-sibling::table//table//td/*[contains(@class,'x-form-trigger')]";
    public static final String UBOFirstLevel = "//div[table//span[contains(text(),'Does this related party act in any other capacity other than that of a UBO and is a first level shareholder')]]/following-sibling::table//table//td/*[contains(@class,'x-form-trigger')]";
    public static final String Member_Gender = "//div[table//span[contains(text(),'Gender')]]/following-sibling::table//table//td/*[contains(@class,'x-form-trigger')]";


    public static final String PIClientDetailsTab = "//*[text() = 'Party Information']/following :: *[text() = '1. Client Details']";
    public static final String PICD_ClientCode = "(//div[table//span[text()='Client code']])[2]/following-sibling::table//input";
    public static final String PICD_CIF = "//div[table//span[contains(text(),'CIF')]]/following-sibling::table//table//input";
    public static final String PICD_IDandV= "//div[table//span[contains(text(),'ID&V')]]/following-sibling::table//table//input";
    public static final String PICD_FICAct = "//div[table//span[contains(text(),'FIC Act')]]/following-sibling::table//table//input";
    public static final String PICD_RelatedPartyRole = "//div[table//span[contains(text(),'Related party role')]]/following-sibling::table//input";
    public static final String PICD_Capacity = "//div[table//span[contains(text(),'Capacity')]]/following-sibling::table//input";
    public static final String POA_ProofOfAuthority ="//div[table//span[contains(text(),'main resolution OR does')]]/following-sibling::table//div/following-sibling::input";

    public static final String CA_confirmUBORules = "//div[table//span[contains(text(),'UBO calculation')]]/following-sibling::table//div/following-sibling::input";
    public static final String CA_confirmActiveAccount = "//div[table//span[contains(text(),'active account')]]/following-sibling::table//div/following-sibling::input";



    //ADDRESS DETAILS SCREEEN OBJECTS

    public static final String PI_tbAddressDetails="//*[@id='ManageBasicControl_RelatedTreeControl_ReqFieldsControl_tbGroups-targetEl']//span[contains(text(),'Address Details')]";
    public static final String AddressDetailsHeader = "//span[contains(text(), '2. Address Details')]";
    public static final String BusinessAddress_AddressLine1 = "//div[table//span[contains(text(),'Address line 1')]]/following-sibling::table//input";
    public static final String BusinessAddress_AddressLine2 = "//div[table//span[contains(text(),'Address line 2')]]/following-sibling::table//input";
    public static final String BusinessAddress_Suburb = "//div[table//span[contains(text(),'Suburb')]]/following-sibling::table//input";
    public static final String BusinessAddress_Town = "//div[table//span[contains(text(),'Town')]]/following-sibling::table//input";
    public static final String BusinessAddress_PostalCode = "//div[table//span[contains(text(),'Postal code')]]/following-sibling::table//input";
    public static final String BusinessAddress_Country = "(//div[table//span[contains(text(),'Country')]])[2]/following-sibling::table//table//td/*[contains(@class,'x-form-trigger')]";

    public static final String chkBxTrustPostalAddressCopy = "(//td[*[contains(text(),'Client - Postal Address')]]/following-sibling::td)";
    public static final String chkBxTrustHighCourtAddressCopy = "(//td[*[contains(text(),'Client - Master of High Court Address')]]/following-sibling::td)";
    public static final String AddressLine1 = "//div[table//span[contains(text(),'Address line 1')]]/following-sibling::table//input";
    public static final String AddressLine2 = "//div[table//span[contains(text(),'Address line 2')]]/following-sibling::table//input";
    public static final String Suburb = "//div[table//span[contains(text(),'Suburb')]]/following-sibling::table//input";
    public static final String Town = "//div[table//span[contains(text(),'Town')]]/following-sibling::table//input";
    public static final String PostalCode = "//div[table//span[contains(text(),'Postal code')]]/following-sibling::table//input";
    public static final String copyInformation_OkBtn = "//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_PopulateCopyControl_btnAccept-btnInnerEl']/../../..";

    public static final String PostalAddress_AddressLine1 = "(//div[table//span[contains(text(),'Address line 1')]])[2]/following-sibling::table//input";
    public static final String PostalAddress_AddressLine2 = "(//div[table//span[contains(text(),'Address line 2')]])[2]/following-sibling::table//input";
    public static final String PostalAddress_Suburb = "(//div[table//span[contains(text(),'Suburb')]])[2]/following-sibling::table//input";
    public static final String PostalAddress_Town = "(//div[table//span[contains(text(),'Town')]])[2]/following-sibling::table//input";
    public static final String PostalAddress_PostalCode = "(//div[table//span[contains(text(),'Postal code')]])[2]/following-sibling::table//input";
    public static final String PostalAddress_Country = "(//div[table//span[contains(text(),'Country')]])[2]/following-sibling::table//table//td/*[contains(@class,'x-form-trigger')]";
    public static final String BusinessAdress_CopyInformationSelection = "//*[contains(text(),'Copy Information')]/following::div[@class='x-grid-checkheader']";
    public static final String BusinessAddress_CopyInformationOKbtn = "xpath||//*[contains(text(),'Copy Information')]/following::a[@id='ManageBasicControl_RelatedTreeControl_ReqFieldsControl_PopulateCopyControl_btnAccept']";
    public static final String AddressDetailsRelatedParty_SaveBtn = "//*[@id='ManageBasicControl_RelatedTreeControl_ReqFieldsControl_btnSave']";


    //CLIENT CONTACT DEATILS
    public static final String PI_tbContactDetails = "//span[*[text() ='3. Contact Details']]";
    // public static final String ?PI_tbContactDetails="//*[@id='ManageBasicControl_RelatedTreeControl_ReqFieldsControl_tbGroups-targetEl']//span[contains(text(),'Contact Details')]";

    public static final String PICD_Website = "//div[table//span[contains(text(),'Website')]]/following-sibling::table//input";
    public static final String PICD_FullNameAndSurname = "//div[table//span[contains(text(),'Full name and surname')]]/following-sibling::table//input";
    public static final String PICD_Designation = "//div[table//span[contains(text(),'Designation')]]/following-sibling::table//table//td/*[contains(@class,'x-form-trigger')]";
    public static final String PICD_WhichContactToUse = "//div[table//span[contains(text(),'Which contact details')]]/following-sibling::table//table//td/*[contains(@class,'x-form-trigger')]";
    public static final String PICD_FaxNumber =  "//div[table//span[text()='Fax number']]/following-sibling::table//input";

    public static final String PICD_FaxNumberDialingCode =  "//div[table//span[text()='Fax number dialling code']]/following-sibling::table//input";
    public static final String PICD_EmailAddress =  "//div[table//span[text()='Email address']]/following-sibling::table//input";
    public static final String PICD_TelNumber =  "//div[table//span[text()='Telephone number']]/following-sibling::table//input";

    public static final String PICD_TelNumberDialingCode =  "//div[table//span[text()='Telephone number dialling code']]/following-sibling::table//input";
    public static final String PICD_CellNumber =  "//div[table//span[text()='Cell phone number']]/following-sibling::table//input";
    public static final String ContactDetailsRalatedParty_SaveBtn ="//*[@id='ManageBasicControl_RelatedTreeControl_ReqFieldsControl_btnSave-btnIconEl']";

    //Detailed Client Information
    //COD Client Contact Detatils Objects
    public static final String   COB_CD_PreferredLanguage1 = "//div[table//span[text()='Preferred language']]/following-sibling::table//input";
    public static final String   COB_CD_PreferredContactMethod1 = "//div[table//span[text()='Preferred contact method']]/following-sibling::table//input";
    public static final String   COB_CD_CreditWorthinessConsent1 = "//div[table//span[text()='Credit Worthiness Consent']]/following-sibling::table//input";
    public static final String   COB_CD_DeliveryOfLigalNotice1 = "//div[table//span[contains(text(),'delivery of Legal Notices')]]/following-sibling::table//input";
    public static final String   COB_CD_SignDocsElectronically = "//div[table//span[contains(text(),'Does the Client prefer to sign document(s) electronically?')]]/following-sibling::table//input";

    public static final String   COB_CD_FullNameAndSurname = "//div[table//span[text()='Full name and surname']]/following-sibling::table//input";
    public static final String   COB_CD_Designation = "//div[table//span[text()='Designation']]/following-sibling::table//input";
    public static final String   COB_CD_ContactDetailsToSupplying = "//div[table//span[text()='Which contact details will you be supplying']]/following-sibling::table//input";


    public static final String   COB_CD_CellPhoneNumber = "//div[table//span[text()='Cell phone number']]/following-sibling::table//input";
    public static final String   COB_CD_TelephoneNumberDiallingCode = "//div[table//span[text()='Telephone number dialling code']]/following-sibling::table//input";
    public static final String   COB_CD_TelephoneNumber = "//div[table//span[text()='Telephone number']]/following-sibling::table//input";
    public static final String   COB_CD_EmailAddress = "//div[table//span[text()='Email address']]/following-sibling::table//input";
    public static final String   COB_CD_FaxNumberDiallingCode = "//div[table//span[text()='Fax number dialling code']]/following-sibling::table//input";
    public static final String   COB_CD_FaxNumber = "//div[table//span[text()='Fax number']]/following-sibling::table//input";
    public static final String   COB_CD_Website = "//div[table//span[text()='Website']]/following-sibling::table//input";

    public static final String   COB_CD_Telemarketing = "//div[table//span[text()='Telemarketing']]/following-sibling::table//table//input";
    public static final String   COB_CD_MassDistribution = "//div[table//span[text()='Mass Distribution ']]/following-sibling::table//table//input";
    public static final String   COB_CD_ClientListSoldOrDistributed = "//div[table//span[text()='Client list may be sold or distributed']]/following-sibling::table//input";
    public static final String   COB_CD_MarketingConsent = "//div[table//span[text()='Marketing Consent']]/following-sibling::table//table//input";
    public static final String   COB_CD_EmailConsent = "//div[table//span[text()='Email consent']]/following-sibling::table//table//input";
    public static final String   COB_CD_TelephoneConsent = "//div[table//span[text()='Telephone consent']]/following-sibling::table//table//input";

    public static final String   COB_CD_SMSConsent= "//div[table//span[text()='SMS consent']]/following-sibling::table//table//input";
    public static final String   COB_CD_PostConsent = "//div[table//span[text()='Post consent']]/following-sibling::table//table//input";

    //Regulatory ---Turnover generated from the sanctioned person

    public static final String   lstIsClientTempResident= "//div[table//span[contains(text(),'Is the client a temporary resident')]]/following-sibling::table//input";
    public static final String   lstIsClientNonResident= "//div[table//span[contains(text(),'Is the client a non-resident')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_OperatingInOrOutSA= "//div[table//span[contains(text(),'registered outside RSA, and operating inside RSA')]]/following-sibling::table//input";
    public static final String   COB_AreAgentsLicensed = "//div[table//span[contains(text(),'Are agents licensed / regulated in accordance with their legal / regulatory obligation')]]/following-sibling::table//input";
    //Are agents licensed / regulated in accordance with their legal / regulatory obligation


    public static final String   COB_Regulatory_BenefitOfTempOrNonRes = "//div[table//span[contains(text(),' benefit of a temporary or non-resident')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_75PercentVotingPowerTempOrNonRes = "//div[table//span[contains(text(),'voting power controlled by a temporary or non-residen')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_CombinedShareHolder75Percent = "//div[table//span[contains(text(),'non-resident shareholders who combined shareholding is more than 75%')]]/following-sibling::table//input";
    //Sanctions
    public static final String   COB_Regulatory_AgencyOrGovSanctioned= "//div[table//span[contains(text(),'agency or government that is sanctioned')]]/following-sibling::table//input";
    //public static final String   COB_Regulatory_OperatingInOrOutSA= "//div[table//span[contains(text(),'above question')]]/following-sibling::table//input";??
    public static final String   COB_Regulatory_ActivityInvolveUS = "//div[table//span[contains(text(),'activity involve US - Origin goods')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_ClientDealInConflictDiamond= "//div[table//span[contains(text(),'Does the Client deal in conflict diamonds')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_ClientAffiliatedToSacntionPerson= "//div[table//span[contains(text(),'Is the Client affiliated to any sanctioned persons')]]/following-sibling::table//input";

    public static final String   COB_Regulatory_TurnoverFromSanctionedPerson = "//div[table//span[contains(text(),'Turnover generated from the sanctioned person')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_TurnoverFromSanctionedCountry = "//div[table//span[contains(text(),'Turnover generated from the sanctioned country')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_DealInUnlicensedIraqiCulture = "//div[table//span[contains(text(),'Client deal in unlicensed Iraqi cultural property')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_OwnerOperatingSactionedCountries = "//div[table//span[contains(text(),'owners operating in any one of the sanctioned countries')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_MoreThan10PercentAssets = "//div[table//span[contains(text(),'Does more than 10% of assets, sales, turnover')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_MilitaryGoods = "//div[table//span[contains(text(),'military goods or technology or dual use goods')]]/following-sibling::table//table//input";
    public static final String   lstRegulatoryOrganogramPercentage = "//div[table//span[contains(text(),'organogram add up to 100%')]]/following-sibling::table//table//input";
    public static final String   lstRegulatoryReasonOrganogramPercentage = "//div[table//span[contains(text(),'Reasons as to why the percentages on the organogram do not add up to 100%')]]/following-sibling::table//textarea";
    //Risk Indicators
    public static final String   COB_Regulatory_ClientInHighRiskIndustry = "//div[table//span[contains(text(),'client involved in any of these high risk industries')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_IsClientMoneyServiceBusiness= "//div[table//span[contains(text(),'MSB')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_ClientInvolveInGambling = "//div[table//span[contains(text(),'client a casino or involved in gambling activities')]]/following-sibling::table//input";

    public static final String   COB_Regulatory_ClientEngagementInAnySuspiciousActivity = "//div[table//span[contains(text(),'client engagements did you note any suspicious activities')]]/following-sibling::table//input";
    //	public static final String   COB_Regulatory_CommentsOnSuspiciousActivityNoticed = "//div[table//span[contains(text(),'Comments on suspicious activities noticed')]]/following-sibling::table//input"; ??
    public static final String   COB_Regulatory_BankTakeElecOrManualInstructFrom3rdParty = "//div[table//span[contains(text(),'bank take electronic or manual instructions from a 3rd ')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_MannerInWhichClientRelationshipEstablished = "//div[table//span[contains(text(),'Manner in which the client relationship is established')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_DoesTheCustomerHoldATradeFinanceAccount = "//div[table//span[contains(text(),'Does the customer hold  a Trade Finance account')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_ThisClientAShellBank = "//div[table//span[contains(text(),'Is this client a shell bank')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_OwnershipCapturedAddUp100Perc = "//div[table//span[contains(text(),'Do the ownership percentages captured on the organogram add up to 100% on each level')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_AnyRelatedPartiesToThisClientAShellBank = "//div[table//span[contains(text(),'Are any related parties to this client a shell bank')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_SourceOfWealth= "//div[table//span[contains(text(),'Source of wealth')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_capitalisationSatisfactory= "//div[table//span[contains(text(),'capitalisation satisfactory')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_ClientShellBank = "//div[table//span[contains(text(),'Is this client a shell bank')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_RelatedPartiesToShellBank = "//div[table//span[contains(text(),'Are any related parties to this client a shell bank')]]/following-sibling::table//input";

public static final String   COB_Regulatory_PurposeOfAccountRelationship = "//div[table//span[text()='Purpose of account / relationship']]/following-sibling::a";

    public static final String   COB_Regulatory_CalculatorIcon = "//*[text() = 'Purpose of account / relationship']/following :: span[@class='x-btn-button x-btn-button-default-small  x-btn-no-text x-btn-icon x-btn-icon-left x-btn-button-center ']";
    public static final String   COB_Regulatory_ExpectedAccount = "//*[text() = 'Expected account activity']/following :: span[@class='x-btn-button x-btn-button-default-small  x-btn-no-text x-btn-icon x-btn-icon-left x-btn-button-center ']";
    public static final String   COB_Regulatory_CalculatorSaveBtn = "//a[@id='ManageDetailedControl_ReqFieldsPrimaryControl_PopulationCalculator_btnSave']";
    public static final String   COB_Regulatory_CalculatorTypeOfAccountDropdown = "//span[text()='Type of account']/following::input";
public static final String   COB_Regulatory_FC_TypeOfAccount = "//div[table//span[contains(text(),'Type of account')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_FC_TypeOfAccountSaveButton = "//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_PopulationCalculator_btnSave-btnInnerEl']";

    //COB_Regulatory_ExpectedAccountActivity Field Calculator start here
    public static final String   COB_Regulatory_ExpectedAccountActivity = "//div[table//span[text()='Expected account activity']]/following-sibling::a";
    public static final String   COB_Regulatory_ExpectedNumberCreditPerMonth= "//div[table//span[contains(text(),'Expected number of credits per month')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_RandValueCreditPerMonth= "//div[table//span[contains(text(),'Rand value of credits per month')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_CreditReceivedViaEFT= "//div[table//span[contains(text(),'Credits received via (EFT, Cash etc.)')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_WhereCreditComingFrom= "//div[table//span[contains(text(),'Where will the credits be coming from')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_NumberOfStaffMembers= "//div[table//span[contains(text(),'Number of staff members')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_PaymentDateOfStaff= "//div[table//span[contains(text(),'Payment date of staff')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_DebitsPerMonth= "//div[table//span[contains(text(),'Number of debits per month')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_SuppliersPerMonth= "//div[table//span[contains(text(),'Number of supplier payments per month')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_WhereAreTheSuppliersLocated= "//div[table//span[contains(text(),'Where are the suppliers located')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_RandValueOfDebitsPerMonth= "//div[table//span[contains(text(),'Rand value of debits per month')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_ReasonForDebitOrders= "//div[table//span[contains(text(),'Reason for debit orders')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_FC_ExpectedAccountActivitySaveButton = "//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_PopulationCalculator_btnSave-btnInnerEl']";

    //COB_Regulatory_ExpectedAccountActivity Field Calculator end here

    public static final String   COB_Regulatory_ClientOrAnyRelatedPartyAPEP= "//div[table//span[contains(text(),'Is the client or any related party a PEP')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_AdverseMedia= "//div[table//span[contains(text(),'Adverse media')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_IdentifyAccountHolder = "//div[table//span[contains(text(),'Identify the account holder type')]]/following-sibling::table//input/../table/tbody/tr/td[2]";
    public static final String   COB_Regulatory_ProductConsidered = "//div[table//span[contains(text(),'Products considered')]]/following-sibling::table//input";
    public static final String   COB_Regulatory_IdentifyAccountHolderType = "//div[table//span[contains(text(),'Identify the account holder type')]]/following-sibling::table//table//input";

    //5. Branch and Banker
    public static final String   COB_BranchDetails__BranchName = "//div[table//span[text()='Branch name']]/following-sibling::table//tbody/tr/td/input";
    public static final String   COB_BranchDetails__SiteCode = "//div[table//span[text()='Site code']]/following-sibling::table//tbody/tr/td/input";
    public static final String   COB_BranchDetails__Address = "//div[table//span[text()='Address']]/following-sibling::table//tbody/tr/td/input";
    public static final String   COB_BranchDetails__TelephoneNumberDialingCode = "//div[table//span[text()='Telephone number dialling code']]/following-sibling::table//tbody/tr/td/input";
    public static final String   COB_BranchDetails__TelephoneNumber = "//div[table//span[text()='Telephone number']]/following-sibling::table//tbody/tr/td/input";
    public static final String   COB_BranchDetails__FirstNames = "//div[table//span[text()='First name(s)']]/following-sibling::table//tbody/tr/td/input";
    public static final String   COB_BranchDetails__Surname = "//div[table//span[text()='Surname']]/following-sibling::table//tbody/tr/td/input";
    public static final String   COB_BranchDetails__AbsaUserId = "//div[table//span[text()='Absa user id']]/following-sibling::table//tbody/tr/td/input";
    public static final String   COB_BranchDetails__EmployeeNumber = "//div[table//span[text()='Employee number']]/following-sibling::table//tbody/tr/td/input";
    public static final String   COB_BranchDetails__BankerTelephoneNumberDialingCode = "//span[text()='Branch Details']/../../../../../../following::div[table//span[text()='Telephone number dialling code']]/following-sibling::table//tbody/tr/td/input";
    public static final String   COB_BranchDetails__BankerTelephoneNumber = "//span[text()='Branch Details']/../../../../../../following::div[table//span[text()='Telephone number']]/following-sibling::table//tbody/tr/td/input";
    public static final String   COB_BranchDetails__CellPhoneNumber = "//div[table//span[text()='Cell phone number']]/following-sibling::table//tbody/tr/td/input";
    public static final String   COB_BranchDetails__Region = "//div[table//span[text()='Region']]/following-sibling::table//tbody/tr/td/input";
    public static final String   COB_BranchDetails__EmailAddress = "//div[table//span[text()='Email address']]/following-sibling::table//tbody/tr/td/input";
    public static final String   COB_BranchDetails__CMSNumber = "//div[table//span[text()='CMS number']]/following-sibling::table//tbody/tr/td/input";

    public static final String
            COB_DocumentTab_UploadFile = "//a[@id='ManageDocsControl_ReqDocsUploadControl_fuUpload-button']";

    //*************************************************[Detailed Client Information (Document Pre-Population)] ******************************************************


    public static final String   COB_DocumentPrePopulation = "xpath||//span[contains(text(),'Document Pre-Population')]";

    public static final String   COB_DocumentPrePopulation_SignedAt = "//div[table//span[text()='Signed at']]/following-sibling::table//input";
    public static final String   COB_DocumentPrePopulation_SignedOn = "//div[table//span[text()='Signed on']]/following-sibling::table//input";
    public static final String   COB_DocumentPrePopulation_ESPPopulateSTDAbsaResolution = "//div[table//span[text()='Do you require ESP to populate the standard Absa resolution for you']]/following-sibling::table//table//input";
    public static final String   COB_DocumentPrePopulation_ESPPopulateAbsaMandate = "//div[table//span[text()='Do you require ESP to populate the Absa mandate and indemnity']]/following-sibling::table//table//input";
    public static final String   COB_DocumentPrePopulation_ESPPopulateSTDAbsaSite = "//div[table//span[text()='Do you require ESP to populate the standard Absa site visit for you']]/following-sibling::table//table//input";
    public static final String   COB_DocumentPrePopulation_ESPPopulateSTDAbsaPower = "//div[table//span[text()='Do you require ESP to populate the standard Absa power of attorney for you']]/following-sibling::table//table//input";
    public static final String   COB_DocumentPrePopulation_RecordTelEngagement = "//div[table//span[text()='Record of telephonic engagement required']]/following-sibling::table//table//input";
    public static final String   COB_DocumentPrePopulation_PrimaryClientNatural = "//div[table//span[contains(text(),'Are all the related parties (excluding sureties) to the primary client natural persons (used to determine if a shareholder confirmation is required)')]]/following-sibling::table//table//input";
    public static final String   COB_DocumentPrePopulation_NaturalPersonRelatedParty = "//div[table//span[contains(text(),'Is there more than one natural person related party (used to determine if a resolution is required)')]]/following-sibling::table//table//input";
//*************************************************[  PANELS ]******************************************************

    public static final String pnlRelatedFields = "//*[@id='ManageBasicControl_RelatedTreeControl_ReqFieldsControl_pnlFields-innerCt']";
    public static final String pnlPrimaryBasicFields = "//*[@id='ManageBasicControl_ReqFieldsPrimaryControl_pnlFields-outerCt']";
    public static final String pnlPrimaryFields ="//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_pnlFields-innerCt']";
    public static final String  pnlPrimaryAddress = "//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_PopulateCopyControl_wndCopy']";
    public static final String II_FullNameOfClient = "//div[table//span[text()='Full name of client']]/following-sibling::table//input";


//****************************************** [ SCREENING ] **********************************************

    public static final String   COB_ScreeningTab = "//span//span[text() ='Screening']";
    public static final String   COB_Screeing_UserDetailsTab = "//div[text() = 'User Details']";
    public static final String   COB_Screening_CASARelatedPartyControl_btnSubmit = "xpath||//*[@id='ManageCASAControl_CASARelatedPartyControl_btnSubmit-btnInnerEl']";
    public static final String   COB_Screening_Confirm_btnYes = "xpath||//a//span[contains(@id,'button')]/span[text()='Yes']";

    public static final String   COB_Screening_PrimaryPartyTab = "//*[@id= 'ManageCASAControl_pnlPrimary_header']";
    public static final String   COB_Screening_RelatedPartyTab = "//*[@id= 'ManageCASAControl_pnlRelated_header']";
    public static final String   COB_Screening_RiskProfilingTab = "//*[@id= 'ManageCASAControl_pnlProfile_header']";
    public static final String   COB_Screening_DocumentConfirmation = "//div//span[contains(@id, 'ManageCASAControl_pnlDocument_header_hd-textEl')]";

    public static final String   COB_Screening_SiteCode = "//*[@id='ManageCASAControl_CASAUserControl_txtSiteCode-inputEl']";
    public static final String   COB_Screening_TellerCode = "//*[@id='ManageCASAControl_CASAUserControl_txtTeller-inputEl']";
    public static final String   COB_Screening_ABNumber = "//*[@id='ManageCASAControl_CASAUserControl_txtABNumber-inputEl']";
    public static final String   COB_Screening_BusinessUnit = "//*[@id='ManageCASAControl_CASAUserControl_cmbBusinessUnit-inputEl']";

    public static final String   COB_Screening_ScreeningbtnUserDetailsUpdate = "xpath||//*[@id='ManageCASAControl_CASAUserControl_btnSaveUser-btnInnerEl']";

    public static final String   COB_SaveBtn = "xpath||//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_btnSave-btnInnerEl']";
    public static final String   COB_Screening_ClienType = "//*[@id='ManageCASAControl_CASAMainPartyControl_cmbClientType-inputEl']";
    public static final String   COB_Screening_IncomeGroup = "//*[@id='ManageCASAControl_CASAMainPartyControl_cmbIncGroup-inputEl']";

    public static final String   COB_ScreeningClientTypeRP = "//*[@id='ManageCASAControl_CASARelatedPartyControl_cmbClientGroup-inputEl']";
    public static final String   COB_SCreeningClientIDRP = "//*[@id='ManageCASAControl_CASARelatedPartyControl_cmbClientIDType-inputEl']";
    public static final String   COB_ScreeningEntityNameRR = "//*[@id = 'ManageCASAControl_CASARelatedPartyControl_txtClientName-inputEl']";
    public static final String   COB_ScreeningFirstNamePR= "//*[@id = 'ManageCASAControl_CASAMainPartyControl_txtClientFirstName-inputEl']";
    public static final String   COB_ScreeningSurnamePR = "//*[@id = 'ManageCASAControl_CASAMainPartyControl_txtClientName-inputEl']";
    public static final String   COB_ScreeningClientEmploymentStatus = "//*[@id = 'ManageCASAControl_CASAMainPartyControl_cmbEmptStatus-inputEl']";
    public static final String   COB_ScreeningCountryOfResidence = "//*[@id = 'ManageCASAControl_CASAMainPartyControl_cmbCountryRegistered-inputEl']";
    public static final String   COB_ScreeningTownOfResidence = "//*[@id = 'ManageCASAControl_CASAMainPartyControl_txtTownRegistered-inputEl']";
    public static final String   COB_ScreeningDOB = "//*[@id = 'ManageCASAControl_CASARelatedPartyControl_dtfClientDateOfBirth-inputEl']";
    public static final String   COB_ScreeningIDOrRegNoRR = "//*[@id='ManageCASAControl_CASARelatedPartyControl_txtClientIDReg-inputEl']";
    public static final String   COB_ScreeningRegCountryRR = "//*[@id='ManageCASAControl_CASARelatedPartyControl_cmbCountryRegistered-inputEl']";
    public static final String   COB_ScreeningRegCityRR = "//*[@id='ManageCASAControl_CASARelatedPartyControl_txtCityRegistered-inputEl']";
    public static final String   COB_ScreeningRegTownRR = "//*[@id='ManageCASAControl_CASARelatedPartyControl_txtTownRegistered-inputEl']";
    public static final String   COB_ScreeningNationalityRR = "//*[@id='ManageCASAControl_CASARelatedPartyControl_cmbCountryNationality-inputEl']";
    public static final String   COB_ScreeningBusinessSourceRR = "//*[@id='ManageCASAControl_CASARelatedPartyControl_cmbCountryBusiness-inputEl']";
    public static final String   COB_ScreeningHeadOficeCountryRR = "//*[@id='ManageCASAControl_CASARelatedPartyControl_cmbCountryHeadOffice-inputEl']";
    public static final String   COB_ScreeningRelationshipRR = "//*[@id = 'ManageCASAControl_CASARelatedPartyControl_cmbClientRelationship-inputEl']";
    public static final String   COB_ScreeningHeadOfficeTownRR = "//*[@id='ManageCASAControl_CASARelatedPartyControl_txtTownHeadOffice-inputEl']";
    public static final String   COB_ScreeningSavebtnRR = "xpath||//*[@id='ManageCASAControl_CASARelatedPartyControl_btnSave-btnInnerEl']";




    public static final String   COB_Screening_IndustryGroup = "//*[@id='ManageCASAControl_CASAMainPartyControl_cmbIndustry-inputEl']";



    public static final String   COB_Screening_Nationality = "//*[@id='ManageCASAControl_CASAMainPartyControl_cmbCountryNationality-inputEl']";
    public static final String   COB_Screening_ScreeningbtnPrimaryPartyUpdate = "xpath||//*[@id='ManageCASAControl_CASAMainPartyControl_btnSave-btnInnerEl']";

    public static final String   COB_Screening_ABSADebtorFinanceProd = "//td[*[contains(text(),'ABSA DEBTOR FINANCE')]]/following-sibling::td";
    public static final String   COB_Screening_FirstEdit = "(//div[@cmd='Edit'])[1]";
    public static final String   btnScreeningDocConfirmation ="//*[@id='ManageCASAControl_RBBProfileDocsControl_btnSubmit-btnEl']";
    public static final String   COB_Screening_ClientRelationship = "//*[@id='ManageCASAControl_CASARelatedPartyControl_cmbClientRelationship-inputEl']";
    public static final String   COB_Screening_CountryNationality = "//*[@id='ManageCASAControl_CASARelatedPartyControl_cmbCountryNationality-inputEl']";


    public static final String   COB_Screening_SecondEdit = "(//div[@cmd='Edit'])[2]";
    public static final String   COB_Screening_btnProfile ="//*[@id='ManageCASAControl_RBBProfileControl_btnProfile-btnInnerEl']";


    public static final String   COB_Screening_btnConfirm ="//*[@id = 'ManageCASAControl_RBBProfileDocsControl_btnSubmit-btnInnerEl']";
    public static final String   COB_Screening_btnProfilingResults = "//*[@id='ManageCASAControl_CIBProfileControl_btnProfile']";




//*************************************** [Detailed Client Information (Client Details)] *******************************//

    public static final String DCI ="xpath||//span[contains(text(), 'Detailed Client Information')]";



    public static final String   COB_CD_NatureClient = "xpath||//*[text()='Nature of client']/following::a";
    public static final String   COB_CD_MonthlyIncome = "xpath||//*[text()='Monthly income']/following::a";

    public static final String   COB_CD_FC_Industry = "//div[table//span[text()='Industry']]/following-sibling::table//input";
    public static final String   COB_CD_FC_ProductOrServices = "//div[table//span[text()='Products / services offered by the customer']]/following-sibling::table//input";
    public static final String   COB_CD_FC_WholesaleOrRetail = "//div[table//span[text()='Wholesale / Retail']]/following-sibling::table//table//input";
    public static final String   COB_CD_FC_NumberOfOperationLocation = "//div[table//span[text()='Number of operation locations']]/following-sibling::table//input";
    public static final String   COB_CD_FC_LocationOfOperation = "//div[table//span[text()='Location of operations (areas / regions not countries)']]/following-sibling::table//input";
    public static final String   COB_CD_FC_CountryExpotedTo = "//div[table//span[text()='Countries exported to']]/following-sibling::table//input";
    public static final String   COB_CD_FC_CountryExpotedFrom = "//div[table//span[text()='Countries imported from']]/following-sibling::table//input";
    public static final String   COB_CD_FC_NumberOfClientPerCustomer = "//div[table//span[text()='Number of clients the customer has']]/following-sibling::table//input";
    public static final String   COB_CD_FC_LocationOfCustomersClients = "//div[table//span[text()='Location of the customers clients']]/following-sibling::table//input";
    public static final String   COB_CD_FC_DoesCustomersDoAnyExports = "//div[table//span[text()='Does the customer do any exports']]/following-sibling::table//table//input";
    public static final String   COB_CD_FC_DoesCustomersDoAnyImports = "//div[table//span[text()='Does the customer do any imports']]/following-sibling::table//table//input";

    public static final String   COB_CD_FC_SaveButton = "xpath||//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_PopulationCalculator_btnSave-btnInnerEl']";

    public static final String   COB_CD_DoesTheClientFallUnderNCA = "xpath||//span[text()='Does the client fall under the NCA']/following::a";
    public static final String   COB_CD_ApplyingForCreditNO = "xpath||//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_PopulationCalculator_btnReject-btnInnerEl']";     //NO
    public static final String   COB_CD_ApplyingForCreditYES = "xpath||//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_PopulationCalculator_btnConfirm-btnInnerEl']";   //YES




//*************************************************[Detailed Client Information (Office Use)] ******************************************************

    public static final String   COB_OfficeUSeTab= "xpath||//span[contains(text(),'6. Office Use')]";
    public static final String   COB_OfficeUSe_DoesClientHaveNDAWithAbsa = "(//span[text()='Non Disclosure Agreement']/../parent::div/../parent::div/..)/following-sibling::div//div[table//span[text()='Does the Client have an NDA with ABSA?']]/following-sibling::table//table//input";
    public static final String   COB_OfficeUSe_DateIdentified = "(//span[text()='Date Identified And Verified']/../parent::div/../parent::div/..)/following-sibling::div//div[table//span[text()='Date identified']]/following-sibling::table//input";
    public static final String   COB_OfficeUSe_IdentifyByEmplyeeFullName = "(//span[text()='Date Identified And Verified']/../parent::div/../parent::div/..)/following-sibling::div//div[table//span[text()='Identified by employee full names']]/following-sibling::table//input";
    public static final String   COB_OfficeUSe_IdentifyByEmplyeeNumber = "(//span[text()='Date Identified And Verified']/../parent::div/../parent::div/..)/following-sibling::div//div[table//span[text()='Identified by employee number']]/following-sibling::table//input";
    public static final String   COB_OfficeUSe_AccOrRefNumber = "(//span[text()='Date Identified And Verified']/../parent::div/../parent::div/..)/following-sibling::div//div[table//span[text()='Account / reference number']]/following-sibling::table//input";
    public static final String   COB_OfficeUSe_FirstName = "(//span[text()='Identified By']/../parent::div/../parent::div/..)/following-sibling::div//div[table//span[text()='First name(s)']]/following-sibling::table//input";
    public static final String   COB_OfficeUSe_Surname = "(//span[text()='Identified By']/../parent::div/../parent::div/..)/following-sibling::div//div[table//span[text()='Surname']]/following-sibling::table//input";
    public static final String   COB_OfficeUSe_EmployeeNumber = "(//span[text()='Identified By']/../parent::div/../parent::div/..)/following-sibling::div//div[table//span[text()='Employee number']]/following-sibling::table//input";

    public static final String   COB_OfficeUSe_SDSID = "(//span[text()='System Identifier']/../parent::div/../parent::div/..)/following-sibling::div//div[table//span[text()='SDS ID']]/following-sibling::table//input";
    public static final String   COB_OfficeUSe_MidbaseID = "(//span[text()='System Identifier']/../parent::div/../parent::div/..)/following-sibling::div//div[table//span[text()='Midbase ID']]/following-sibling::table//input";
    public static final String   COB_OfficeUSe_WorkItemClassification = "(//span[text()='System Identifier']/../parent::div/../parent::div/..)/following-sibling::div//div[table//span[text()='Work item classification']]/following-sibling::table//input";
    public static final String   COB_OfficeUSe_AgricSubType = "(//span[text()='Agricultural Sub-Type']/../parent::div/../parent::div/..)/following-sibling::div//div[table//span[text()='Agricultural sub-type if applicable']]/following-sibling::table//input";

    public static final String DocumentUploadNOBtn = "xpath||//*[text()='Would you like to download the document directly without uploading it automatically? ']/following::span[text()='No']/../../..";
    public static final String DocumentUploadNPDFBtn = "xpath||//*[text()='File Generation']/following::span[text()='PDF' and @class='x-btn-inner x-btn-inner-center']/../../..";


    public static final String ProductBeingAddedOnboarding = "//div//span[contains(text(),'Product being added as part of this on-boarding')]/following :: div[contains(@id, 'trigger-picker')]";
    public static final String ProductAutomaticallyCreateProducts = "//div//span[contains(text(),'Do you want to automatically create the products on completion')]/following :: div[contains(@id, 'trigger-picker')]";
    //Completiion Page
    public static final String CompletionSaveBtn = "//*[@id='ManageCompletionControl_CompletionControl_btnSubmit-btnWrap']";
    public static final String Issues = "//*[@class='x-panel-body x-panel-body-default x-layout-fit x-panel-body-default x-noborder-trbl']";

    //Middle office
    public static final String UnclaimedSpan = "xpath||//span[text()='Unclaimed']";
    public static final String UnclaimedFilterInput = "xpath||//input[@id='DashboardUserControl_tfInstructionFilter-inputEl']";
    public static final String ClaimConfirmYesBtn ="xpath||//span[text()='Yes']/../../..";
    public static final String CheckListTab="xpath||//span[text()='Checklist']/../../..";
    public static final String CASAManualLingingInput ="xpath||//*[text()='I confirm that I have checked and where multiple CASA reference numbers exist I have manually linked them']/following::input";
    public static final String ChecklistSaveBtn = "xpath||//span[text()='Save']/../../..";
    public static final String ProgressInstruction = "xpath||//span[text()='Progress Instruction']";
    public static final String ProgressInstructionCommentTextarea = "xpath||//*[@id='ActionReasons_txtComments-inputEl']";
    public static final String submitProgressInstructionCommentBtn = "xpath||//*[@id='ActionReasons_btnAccept-btnInnerEl']";
    public static final String ProgressConfirmYesBtn ="xpath||//*[text()='Are you sure you want to Progress this instruction?']/following::a[2]";



}