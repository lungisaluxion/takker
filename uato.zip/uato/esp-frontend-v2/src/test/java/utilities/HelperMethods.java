package utilities;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

import static esp.regression.EspTestDriver.currentFolderName;
import static esp.regression.EspTestDriver.screenshotNames;
import static esp.regression.EspTestDriver.stepNo;

/**
 * Created by MbamboS on 2017-02-03.
 */
public class HelperMethods {

    public static void selectObjectFrom_li_List(WebDriver driver, String elementName, String description, String textToSet, int indexNumber) throws Exception {
        //System.out.println("WebDr.java- setText Invoked");
        try {
            if (textToSet != null) {


                WebDriverWait wait = new WebDriverWait(driver, 60);
                WebElement elmn = driver.findElement(By.xpath(elementName));
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(elementName)));
                WebElement DIVelement;
                elmn.click();  //li[text()='SOUTH AFRICA']

                screenshotNames = screenshotNames + "," + stepNo + ".jpg";
                getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

                try {
                    //((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("Value')]")));

                    DIVelement = driver.findElement(By.xpath("//li[text()='" + textToSet + "']"));

                    JavascriptExecutor jse = (JavascriptExecutor) driver;
                    jse.executeScript("arguments[0].scrollIntoView(true)", DIVelement);
                    driver.findElement(By.xpath("//li[text()='" + textToSet + "']")).click();

                    screenshotNames = screenshotNames + "," + stepNo + ".jpg";
                    getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");
                    //Driver.driver.findElement(By.xpath("//li[text()='"+textToSet+"']")).click();
                    Thread.sleep(2000);
                } catch (Exception e) {

                    DIVelement = driver.findElements(By.xpath("//li[text()='" + textToSet + "']")).get(indexNumber);//[" + indexNumber + "]"));

                    JavascriptExecutor jse = (JavascriptExecutor) driver;
                    jse.executeScript("arguments[0].scrollIntoView(true)", DIVelement);

                    screenshotNames = screenshotNames + "," + stepNo + ".jpg";
                    getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

                    DIVelement.click();
                    //driver.findElement(By.xpath("(//li[text()='" + textToSet + "'])[" + indexNumber + "]")).click();

                    screenshotNames = screenshotNames + "," + stepNo + ".jpg";
                    getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

                    //Driver.driver.findElement(By.xpath("(//li[text()='"+ textToSet+"'])["+indexNumber+"]")).click();
                    Thread.sleep(2000);
                }
                /*JavascriptExecutor js = ((JavascriptExecutor) driver);
				js.executeScript("arguments[0].click()", elmn);
				Thread.sleep(2000);
				WebElement liSelect = driver.findElement(By.xpath("//li[contains(text(),'"+textToSet+"')]"));
				js.executeScript("arguments[0].click()", liSelect);
				Thread.sleep(2000);*/
                //HtmlReporter.WriteStep(description, "Select Text "+textToSet, "Text selected - " + textToSet, true );
            }
        }catch (ElementNotVisibleException e1){
            selectObjectFrom_li_List(driver, elementName, description, textToSet, indexNumber+1);
        }

        catch (Exception e) {
            System.out.println("Exeption in WebDr.ControlKeyStroke - " + e);
            //HtmlReporter.WriteStep("Object not visible - " + description, "Select Text- " + textToSet, "Not Selected - " + textToSet , false );
            throw new Exception("Failed");
        }

    }

    public static void selectObjectFrom_span_List(WebDriver driver, String elementName, String description, String textToSet, int indexNumber) throws Exception {
        //System.out.println("WebDr.java- setText Invoked");
        try {
            if (textToSet != null) {


                WebDriverWait wait = new WebDriverWait(driver, 60);
                WebElement elmn = driver.findElement(By.xpath(elementName));
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(elementName)));
                WebElement DIVelement;
                elmn.click();  //li[text()='SOUTH AFRICA']

                screenshotNames = screenshotNames + "," + stepNo + ".jpg";
                getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

                if (indexNumber == 1) {
                    //((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("Value')]")));

                    DIVelement = driver.findElement(By.xpath("//span[text()='" + textToSet + "']"));

                    JavascriptExecutor jse = (JavascriptExecutor) driver;
                    jse.executeScript("arguments[0].scrollIntoView(true)", DIVelement);

                    screenshotNames = screenshotNames + "," + stepNo + ".jpg";
                    getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

                    driver.findElement(By.xpath("//span[text()='" + textToSet + "']")).click();

                    screenshotNames = screenshotNames + "," + stepNo + ".jpg";
                    getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

                    Thread.sleep(2000);
                } else {

                    DIVelement = driver.findElement(By.xpath("(//li[text()='" + textToSet + "'])[" + indexNumber + "]"));

                    JavascriptExecutor jse = (JavascriptExecutor) driver;
                    jse.executeScript("arguments[0].scrollIntoView(true)", DIVelement);
                    driver.findElement(By.xpath("(//span[text()='" + textToSet + "'])[" + indexNumber + "]")).click();

                    screenshotNames = screenshotNames + "," + stepNo + ".jpg";
                    getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

                    Thread.sleep(2000);
                }
				/*JavascriptExecutor js = ((JavascriptExecutor) Driver.driver);
				js.executeScript("arguments[0].click()", elmn);
				Thread.sleep(2000);
				WebElement liSelect = Driver.driver.findElement(By.xpath("//li[contains(text(),'"+textToSet+"')]"));
				js.executeScript("arguments[0].click()", liSelect);
				Thread.sleep(2000);*/
                //HtmlReporter.WriteStep(description, "Select Text "+ textToSet, "Text selected - " + textToSet, true );
            }
        } catch (Exception e) {
            System.out.println("Exeption in WebDr.ControlKeyStroke - " + e);
            //HtmlReporter.WriteStep("Object not visible - " + description, "Select Text- " + textToSet, "Not Selected - " + textToSet , false );
            throw new Exception("Failed");
        }

    }

    public static boolean existsElement(WebDriver driver, String txtXpath) {
        try {
            driver.findElement(By.xpath(txtXpath));
        } catch (NoSuchElementException e) {
            System.out.println(txtXpath + " does not exist");
            return false;
        }
        return true;
    }

    public static boolean isElementVisible(WebDriver driver, String txtXpath)
            throws InterruptedException {

        boolean value = false;

        if (driver.findElement(By.xpath(txtXpath)).isDisplayed()) {
            System.out.println(txtXpath +" visible");
            value = true;
        }
        return value;
    }

    public static void clickOverride(WebDriver driver, By overrideLink) {

        try {
            List<WebElement> elements = driver.findElements(overrideLink);
            if(elements.size()>0){
                int i=0;
                while (!elements.get(i).isDisplayed()){i++;}
                    elements.get(i).click();

            }

            //.get(driver.findElements(overrideLink).size() - 1).click();
            screenshotNames = screenshotNames + "," + stepNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

            elements = driver.findElements(By.xpath("//*[text() = 'Comment:' ]/../following-sibling::td/child::input"));
            elements.get(elements.size() - 1).sendKeys("Comment");

            screenshotNames = screenshotNames + "," + stepNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

            elements = driver.findElements(By.xpath("//*[text() = 'Comment:' ]/../following::span[text()='Save']"));
            elements.get(elements.size() - 1).click();

            screenshotNames = screenshotNames + "," + stepNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

        } catch (Exception e) {
            System.out.println(e.getMessage());

        }

    }

    public static void rightClickOnObject(WebDriver driver, String elementName) throws Exception {

        try {
            String wbObject = "//span[contains(text(),'" + elementName + "')]";
            //WebElement wbObject  =driver.findElement(By.xpath("//span[contains(text(),'"+elementName+"')]"));
            WebDriverWait wait = new WebDriverWait(driver, 30); // Wait for 30 seconds.
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(wbObject)));
            WebElement elmn = driver.findElement(By.xpath(wbObject));
            Actions action = new Actions(driver).contextClick(elmn);
            screenshotNames = screenshotNames + "," + stepNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

            action.build().perform();

            screenshotNames = screenshotNames + "," + stepNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

            //HtmlReporter.WriteStep(objectName, "RightClick On object "+objectName, "RightClick on object " +objectName+ " was successfull." , true );
        } catch (Exception e) {
            System.out.println("Exeption in WebDr.click - " + e);
            //HtmlReporter.WriteStep("Object not visible - " + objectName, "Hover On object "+objectName, "Hover on object "+objectName+" was unsuccessfull." , false );
            throw new Exception("Failed");
        }

    }

    public static void getScreenShot(WebDriver driver, String fileName) {
        try {
            File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(scrFile, new File(fileName));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public LinkedHashMap getTestData(String dataSheetPath, String sheet, int testCaseNumber) throws IOException {
        System.out.println("Sheet : "+sheet+"ID : "+testCaseNumber);
        return new ReadTestData().readCurrentTestData(dataSheetPath, sheet, testCaseNumber);
    }

    public boolean checkFailure(ArrayList<Properties> results) {
        boolean anyFaliures = false;
        for (int i = 0; i < results.size(); i++) {
            if (results.get(i).getProperty("Result").equals("FAILED")) {
                anyFaliures = true;
            }
        }
        return anyFaliures;
    }

    public int rowsInSheet(String fileName, String sheet) throws IOException {
        XSSFWorkbook myExcelBook = new XSSFWorkbook(new FileInputStream(fileName));
        XSSFSheet myExcelSheet = myExcelBook.getSheet(sheet);
        return myExcelSheet.getPhysicalNumberOfRows();
    }


}
