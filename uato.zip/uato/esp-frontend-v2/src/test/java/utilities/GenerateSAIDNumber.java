package utilities;

//import com.sun.istack.internal.NotNull;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Random;

public class GenerateSAIDNumber {

    public static String Gender;
    public static String DOB;
    public static String CurrDate;

    public static String generateRegistrationID(){
        Random rn = new Random();
        int ID = rn.nextInt(2017000000-1975000000+1)+1975000000;


        return ""+ID;
    }


    public static String generateID(int age, String gender)
    {
        String dob = generateDateOfBirth(age);
        int iGender = getRandomNumber(5) + (IsMale(gender) ? 5 : 0);

        String random = String.valueOf(getRandomNumber(1000));
        random = padLeft(random, 3, '0');
        String citBit = "0";

        String total = dob + iGender + random + citBit + "8";
        total += generateLuhnDigit(total);
        getDateOfBirthAndGenderFromID(total);
        DOB = DOB;
        System.out.println("DOB: " + DOB);
        Gender = Gender;
        System.out.println("DOB: " + Gender);
        CurrDate = CurrDate;
        System.out.println("Current Date: " + CurrDate);
        return total;
    }
    public static void getDateOfBirthAndGenderFromID(String IDNumber)  {
        // TODO Auto-generated method stub
        String ID = IDNumber;
        String YY;
        String Century = ID.substring(0,2);
        String sMonth= ID.substring(2,4);
        String sDay = ID.substring(4,6);
        String sGenderValue = ID.substring(6,7);
        String sGender;

        if(sDay.substring(0,1).equalsIgnoreCase("0")){ sDay = ID.substring(5,6); }
        //int CC = Integer.parseInt(Century);
        if(Integer.parseInt(Century) < 19){  YY = "20"; }
        else{  YY = "19";}
        System.out.println("Date Of Birth: " + YY+Century+"/"+sMonth+"/"+sDay );

        if(Integer.parseInt(sGenderValue) < 5){ sGender = "FEMALE"; }
        else{sGender = "MALE";}

        System.out.println("Gender :" + sGender );
        Gender = sGender;
        DOB =  YY+Century+"/"+sMonth+"/"+sDay;
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/d");
        java.util.Date date = new java.util.Date();
        CurrDate =dateFormat.format(date);
        System.out.println("Current Date : " + dateFormat.format(date));

    }


    public static String generatePassport()
    {
        StringBuilder sb = new StringBuilder();
        for(int i=0; i < 5; i++)
            sb.append(getRandomNumber(9));

        return getRandomCharacters(3) + padLeft(sb.toString(), 5, '0');
    }


    private static int getRandomNumber(int range)
    {
        Random rnd = new Random();
        return rnd.nextInt(range);
    }


    //@NotNull
    private static String getRandomCharacters(int numberOfCharacters)
    {
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < numberOfCharacters; i++){
            int randomChar = new Random().nextInt((90 - 65) + 1) + 65;
            sb.append((char)randomChar);
        }
//        ((max - min) + 1) + min

        return sb.toString();
    }


    //@NotNull
    private static Boolean IsMale(String gender)
    {
        return gender.toLowerCase().startsWith("m");
    }


    //@NotNull
    private static String generateDateOfBirth(int age)
    {
        LocalDate today = LocalDate.now();

        String year = String.valueOf(today.getYear() - age).substring(2,4);
        String month = padLeft(String.valueOf(today.getMonthValue()), 2, '0');
        String day = padLeft(String.valueOf(today.getDayOfMonth()),2,'0');

        return year + month + day;
    }


    private static String padLeft(String s, int n, char c) {
        char[] chars = new char[n - s.length()];
        Arrays.fill(chars, c);
        s = new String(chars).concat(s);

        return s;
    }


    private static int generateLuhnDigit(String input) {
        int total = 0;
        int count = 0;

        for (int i = 0; i < input.length(); i++) {
            int multiple = (count % 2) + 1;
            count++;

            int temp = multiple * Integer.parseInt(String.valueOf(input.charAt(i)));
            temp = (int) Math.floor(temp / 10) + (temp % 10);
            total += temp;
        }
        return (total * 9) % 10;
    }




}
