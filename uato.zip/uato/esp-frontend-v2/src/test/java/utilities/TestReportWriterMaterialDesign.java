package utilities;

import org.apache.commons.io.FileUtils;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.logging.Logger;

/**
 * Created by ABSMBGL on 2017-10-12.
 */
public class TestReportWriterMaterialDesign {
    private static final Logger LOGGER = Logger.getLogger( TestReportWriterMaterialDesign.class.getName());
    StringBuffer reportBuffer = new StringBuffer("");
    StringBuffer graphsBuffer = new StringBuffer("");
    private GetPropertyFileValues properties = new GetPropertyFileValues();
    Properties ecmProperties = new Properties();

    public HashMap <String,File> createReportFile(String TestSuite, String testName, String filename) throws IOException {
        HashMap<String,File> Files = new HashMap();
        /**Root Report Folder*/
        File rootReportFolder = new File(filename);

        if (!rootReportFolder.exists()) {
            LOGGER.info("creating directory: " + rootReportFolder);
            try {
                rootReportFolder.mkdir();
            } catch (Exception e) {
                LOGGER.info("Failed to create directory" + rootReportFolder);
            }
        }


        /** Root Test Suite Folder [Example : Home Loans] */
        File testFolder = new File("src/test/resources/reports" + TestSuite);
        if (!testFolder.exists()) {
            LOGGER.info("Creating Site directory" + testFolder);

            testFolder.mkdir();
        }


        /** Root Test Report Folder */
        File testNameFolder = new File("src/test/resources/reports" + TestSuite + File.separator + testName);
        if (!testNameFolder.exists()) {
            LOGGER.info("creating directory: " + testNameFolder);
            testNameFolder.mkdir();
        }

        /** HML test report folder */
        String reportFolderName = "Automated Test Execution Report_" + new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
        File reportFolder = new File(testNameFolder.getAbsolutePath() + File.separator + reportFolderName);
        LOGGER.info("creating directory: " + reportFolder);
        reportFolder.mkdir();
        File report = new File(reportFolder.getAbsolutePath() + File.separator + "Automated Test Execution Report.html");
        report.createNewFile();
        Files.put("reportFolder", reportFolder);
        Files.put("report", report);

        return Files;
    }

    public void writeReportFile(File reportFolder , File report) throws IOException{
        FileWriter writer = new FileWriter(report);
        writer.write(String.valueOf(reportBuffer));
        writer.close();

        String source = "src\\test\\resources\\MaterialReporting";
        File srcDir = new File(source);
        File destDir = new File(reportFolder.getAbsolutePath()  + File.separator + "resources");
        try{
            FileUtils.copyDirectory(srcDir, destDir);
        }catch (Exception ex){ System.err.println();}
    }
    public void buildReport(ArrayList<Properties> results, String Environment, File reportFolder, ArrayList REQUEST_PATH, ArrayList RESPONSE_PATH) throws IOException {}
    public void buildReport(ArrayList<Properties> results, String Environment, File reportFolder) throws IOException {
        int numberOfFaliures=0;
        int numberPassed=0;
        String  testResultTable ="";
        ecmProperties = properties.getPropValues("ecmTestData/ecm.properties");

        for(int i=0; i< results.size();i++)
        {
            if(results.get(i).getProperty("Result").equals("PASSED"))
            {
                numberPassed+=1;
                //String resultReport = buildResultsPage(reportFolder,results.get(i).get("Result").toString(),REQUEST_PATH.get(i).toString(), RESPONSE_PATH.get(i).toString(), results.get(i).get("ExpectedResult").toString(), results.get(i).get("ActualResult").toString(), results.get(i).get("Test ID").toString());
                testResultTable+=("<tr class=\"content\"><td>" + results.get(i).get("Test ID").toString() +  "</td><td>"+ results.get(i).get("Test Description").toString() +  "</td><td><a href=\"file:///" + "" + "\" class=\"btn-wide  btn-success \">"+ results.get(i).get("Result").toString() + "</a></td></tr>"+ "\n" );

            }
            if(results.get(i).getProperty("Result").equals("FAILED"))
            {
                numberOfFaliures+=1;
                //String resultReport = buildResultsPage(reportFolder,results.get(i).get("Result").toString(),REQUEST_PATH.get(i).toString(), RESPONSE_PATH.get(i).toString(), results.get(i).get("ExpectedResult").toString(), results.get(i).get("ActualResult").toString(), results.get(i).get("Test ID").toString());
                testResultTable+=("<tr class=\"content\"><td>" + results.get(i).get("Test ID").toString() +  "</td><td>"+ results.get(i).get("Test Description").toString() +  "</td><td><a href=\"file:///" + "" + "\" class=\"btn-wide  btn-danger\">"+ results.get(i).get("Result").toString() + "</a></td></tr>" + "\n" );

            }
        }

        InputStream resultsReader =  new FileInputStream("src\\test\\resources\\MaterialReporting\\TestReportMain.html");
        BufferedReader reader = new BufferedReader(new InputStreamReader(resultsReader));
        String line;

        while((line = reader.readLine()) != null)
        {
            if(line.contains("${totalFailed}"))
            {
                String newLine = line.replace("${totalFailed}", String.valueOf(numberOfFaliures));

                reportBuffer.append(newLine + "\n");
            }
            else if(line.contains("${totalPassed}"))
            {
                String newLine = line.replace("${totalPassed}", String.valueOf(numberPassed));

                reportBuffer.append(newLine + "\n");
            }
            else if(line.contains("${results_table_filler}"))
            {
                String newLine = line.replace("${results_table_filler}",testResultTable);
                reportBuffer.append(newLine + "\n");
            }
            else if(line.contains("${runBy}"))
            {
                String newLine = line.replace("${runBy}", System.getProperty("user.name"));
                reportBuffer.append(newLine + "\n");
            }
            else if(line.contains("${date}"))
            {
                String newLine = line.replace("${date}", new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss Z").format(new java.util.Date()));
                reportBuffer.append(newLine + "\n");
            }
            else if(line.contains("${totalTests}"))
            {
                String newLine = line.replace("${totalTests}", String.valueOf(results.size()));
                reportBuffer.append(newLine + "\n");
            }

            else if(line.contains("${testEnvironment}"))
            {
                String newLine = line.replace("${testEnvironment}", Environment);
                reportBuffer.append(newLine + "\n");
            }
            else{
                reportBuffer.append(line + "\n");
            }
        }
        resultsReader.close();
        reader.close();
        buildGraphs(reportFolder, results);
    }

    public String buildResultsPage(File reportFolder, String result, String requestFolder, String responseFolder, String expectedResult, String actualResult, String testId) throws IOException
    {
        StringBuffer results = new StringBuffer();
        InputStream resultsReader =  new FileInputStream("src\\test\\resources\\MaterialReporting\\TestResults.html");
        BufferedReader reader = new BufferedReader(new InputStreamReader(resultsReader));
        String line;

        while((line = reader.readLine()) != null) {
            if (line.contains("${testResultHolder}")) {
                if(result.equals("PASSED"))
                {
                    String newLine = line.replace("${testResultHolder}", "<a class=\" btn-reults btn-success \">Passed</a>");
                    results.append(newLine + "\n");
                }else{
                    String newLine = line.replace("${testResultHolder}", "<a class=\" btn-reults btn-danger \">Failed</a>");
                    results.append(newLine + "\n");
                }
            }
            else if(line.contains("${requestMessage}")) {
                InputStream is = new FileInputStream(requestFolder);
                BufferedReader buf = new BufferedReader(new InputStreamReader(is));
                String requestline = buf.readLine();
                StringBuilder sb = new StringBuilder();
                while (requestline != null) {
                    sb.append(requestline).append("\n");
                    requestline = buf.readLine();
                }
                String newLine = line.replace("${requestMessage}", sb.toString());
                results.append(newLine + "\n");
            }
            else if(line.contains("${responseMessage}")) {
                InputStream is = new FileInputStream(responseFolder);
                BufferedReader buf = new BufferedReader(new InputStreamReader(is));
                String responseline = buf.readLine();
                StringBuilder sb = new StringBuilder();
                while (responseline != null) {
                    sb.append(responseline).append("\n");
                    responseline = buf.readLine();
                }
                String newLine = line.replace("${responseMessage}", sb.toString());
                results.append(newLine + "\n");
            }
            else if(line.contains("${expectedResult}")) {
                String newLine = line.replace("${expectedResult}", expectedResult);
                results.append(newLine + "\n");
            }

            else if(line.contains("${actualResult}")) {
                String newLine = line.replace("${actualResult}", actualResult);
                results.append(newLine + "\n");
            }
            else {
                results.append(line + "\n");
            }

            File resultReport = new File(reportFolder.getAbsolutePath() + File.separator + "Test Results Test" + testId + ".html");
            resultReport.createNewFile();
            FileWriter writer = new FileWriter(resultReport);
            writer.write(String.valueOf(results));
            writer.close();

        }
        return reportFolder.getAbsolutePath() + File.separator + "Test Results Test" + testId + ".html";
    }

    public void buildGraphs(File reportFolder, ArrayList<Properties> results) throws IOException {
        int totalCriticalDefects = 0;
        int totalMajorDefects = 0;
        int totalMinorDefects = 0;
        int totalTrivialDefects = 0;

        for(int i=0;i<results.size(); i++)
        {
            if(results.get(i).getProperty("severity").toString().equals("S0"))
            {
                totalCriticalDefects+=1;
            }
            if (results.get(i).getProperty("severity").toString().equals("S1"))
            {
                totalMajorDefects+=1;
            }
            if(results.get(i).getProperty("severity").toString().equals("S2"))
            {
                totalMinorDefects+=1;
            }
            if(results.get(i).getProperty("severity").toString().equals("S3"))
            {
                totalTrivialDefects+=1;
            }

        }
        long sumOfDurations = 0;

           /* for(int i=0 ; i< durations.size(); i++)
            {
                sumOfDurations= sumOfDurations + Long.valueOf(durations.get(i).toString());
            }

            long averageDurations = sumOfDurations / durations.size();
            final double convertedToSeconds = ((double)averageDurations / 1000000000);
            //convertedToSeconds = new DecimalFormat("#.##########").format(convertedToSeconds)*/
        InputStream resultsReader =  new FileInputStream("src\\test\\resources\\MaterialReporting\\graphs.html");
        BufferedReader reader = new BufferedReader(new InputStreamReader(resultsReader));
        String line;

        while((line = reader.readLine()) != null) {
            if (line.contains("${critical}")) {
                String newLine = line.replace("${critical}", String.valueOf(totalCriticalDefects));
                graphsBuffer.append(newLine + "\n");
            } else if (line.contains("${major}")) {
                String newLine = line.replace("${major}", String.valueOf(totalMajorDefects));

                graphsBuffer.append(newLine + "\n");
            } else if (line.contains("${minor}")) {
                String newLine = line.replace("${minor}",  String.valueOf(totalMinorDefects));
                graphsBuffer.append(newLine + "\n");
            } else if (line.contains("${trivial}")) {
                String newLine = line.replace("${trivial}",String.valueOf(totalTrivialDefects));
                graphsBuffer.append(newLine + "\n");
            }
            else{
                graphsBuffer.append(line + "\n");
            }
        }

        File resultReport = new File(reportFolder.getAbsolutePath() + File.separator + "graphs.html");
        resultReport.createNewFile();
        FileWriter writer = new FileWriter(resultReport);
        writer.write(String.valueOf(graphsBuffer));
        writer.close();
    }

    public  static void main (String[]args) throws IOException {

        long startTime = System.nanoTime();

        ArrayList<Properties> tester =  new ArrayList<Properties>();
        Properties linkTestOutcome =  new Properties();
        linkTestOutcome.setProperty("Test ID", "1") ;
        linkTestOutcome.setProperty("Test Description", "felix-search-by : Dry Food Button") ;
        linkTestOutcome.setProperty("Result", "FAILED") ;
        linkTestOutcome.setProperty("severity", "S0") ;
        linkTestOutcome.setProperty("ExpectedResult", "FAILED") ;
        linkTestOutcome.setProperty("ActualResult", "FAILED") ;
        tester.add(linkTestOutcome);

        Properties linkTestOutcome2 =  new Properties();
        linkTestOutcome2.setProperty("Test ID", "2") ;
        linkTestOutcome2.setProperty("Test Description", "felix-search-by : Dry Food Button") ;
        linkTestOutcome2.setProperty("Result", "PASSED") ;
        linkTestOutcome2.setProperty("severity", "S0") ;
        linkTestOutcome2.setProperty("ExpectedResult", "FAILED") ;
        linkTestOutcome2.setProperty("ActualResult", "FAILED") ;
        tester.add(linkTestOutcome2);

        Properties linkTestOutcome3 =  new Properties();
        linkTestOutcome3.setProperty("Test ID", "3") ;
        linkTestOutcome3.setProperty("Test Description", "felix-search-by : Dry Food Button") ;
        linkTestOutcome3.setProperty("Result", "FAILED") ;
        linkTestOutcome3.setProperty("severity", "S0") ;
        linkTestOutcome3.setProperty("ExpectedResult", "FAILED") ;
        linkTestOutcome3.setProperty("ActualResult", "FAILED") ;
        tester.add(linkTestOutcome3);

        TestReportWriterMaterialDesign report = new TestReportWriterMaterialDesign();
        ArrayList request = new ArrayList();
        request.add("C:\\messages\\mortgage_origination_request1504873827738.xml");
        request.add("C:\\messages\\mortgage_origination_request1504873827738.xml");
        request.add("C:\\messages\\mortgage_origination_request1504873827738.xml");
        ArrayList response = new ArrayList();
        response.add("C:\\messages\\mortgage_origination_request1504873827738.xml");
        response.add("C:\\messages\\mortgage_origination_request1504873827738.xml");
        response.add("C:\\messages\\mortgage_origination_request1504873827738.xml");

        long endTime = System.nanoTime();
        ArrayList  executionTimes = new ArrayList();
        executionTimes.add(endTime - startTime);
        executionTimes.add(endTime - startTime);
        executionTimes.add(endTime - startTime);
        HashMap<String, File> reportFileLocations = report.createReportFile("ECM ICN ", "Search Navigator Test", "TEST");
        report.buildReport(tester, "TEST",reportFileLocations.get("reportFolder"));
        report.writeReportFile(reportFileLocations.get("reportFolder"),reportFileLocations.get("report"));
    }

}