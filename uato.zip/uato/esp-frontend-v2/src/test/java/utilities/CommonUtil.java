package utilities;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import za.co.absa.functionstechnology.automation.selenium.LocatorUtil;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static esp.regression.EspTestDriver.currentFolderName;
import static esp.regression.EspTestDriver.screenshotNames;
import static esp.regression.EspTestDriver.stepNo;


public class CommonUtil {
    WebDriver driver;

    public CommonUtil(WebDriver driver) {
        this.driver = driver;
    }


    public static String getCurrentTimeStamp(String format) {
        SimpleDateFormat sdfDate = new SimpleDateFormat(format);
        Date now = new Date();
        return sdfDate.format(now);
    }

    public static void createScreenShotFolder(String folderName) {
        try {
            new File(folderName).mkdirs();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void clickOnElement(String element) {
        try {
            By object = LocatorUtil.getLocator(element);
            this.driver.findElement(object).click();
            this.driver.getTitle();
            screenshotNames = screenshotNames + ","+ stepNo+".jpg";
            getScreenShot(this.driver, currentFolderName + "/"+(stepNo++)+".jpg");
        } catch (Exception var3) {
            System.out.println("Unable to catch object " + element);
        }

    }

    public void clickOnElementByText(String element, String value) {
        try {
            if (element.contains("{value}")) {
                element = element.replace("{value}", value);
            }

            By object = LocatorUtil.getLocator(element);
            this.driver.findElement(object).click();
        } catch (Exception var4) {
            System.out.println("Unable to catch object see error" + var4.getMessage());
        }

    }

    public void typeOnElement(String element, String value) {
        try {
            By object = LocatorUtil.getLocator(element);
            this.driver.findElement(object).sendKeys(new CharSequence[]{value});
            screenshotNames = screenshotNames + ","+ stepNo+".jpg";

            getScreenShot(this.driver, currentFolderName + "/"+(stepNo++)+".jpg");
            this.driver.findElement(object).sendKeys(Keys.ENTER);
            //System.out.println("");

        } catch (Exception var4) {
            System.out.println("Unable to catch "+element/*+" see error" + var4.getMessage()*/);
        }

    }

    public boolean isPresent(String element) {
        try {
            By object = LocatorUtil.getLocator(element);
            return true;
        } catch (Exception var3) {
            System.out.println("-------Unable to find object------" + element);
            return false;
        }
    }

    public String getText(String element) {
        try {
            By object = LocatorUtil.getLocator(element);
            return this.driver.findElement(object).getText();
        } catch (Exception var3) {
            System.out.println("Unable to find object");
            return "Unable to find text";
        }
    }

    public boolean isEnabled(String element) {
        try {
            By object = LocatorUtil.getLocator(element);
            return this.driver.findElement(object).isEnabled();
        } catch (Exception var3) {
            System.out.println("Unable to find object");
            return false;
        }
    }

    public boolean isTextVisible(String element, String value) {
        try {
            String text = this.getText(element);
            return text.toUpperCase().contains(value);
        } catch (Exception var4) {
            return false;
        }
    }

    public void clear(String element) {
        try {
            By object = LocatorUtil.getLocator(element);
            this.driver.findElement(object).clear();
            screenshotNames = screenshotNames + "," + stepNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");
        } catch (Exception var3) {
            System.out.println("Unable to find object");
        }

    }

    public void getScreenShot(WebDriver driver,String fileName) {
        try {
            File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(scrFile, new File(fileName));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public  WebElement waitForElement(WebDriver driver, int timeout, String locator) {

        WebElement w = driver.findElement(By.xpath(locator));
        WebDriverWait wait = new WebDriverWait(driver, timeout);

        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
            return w;

        } catch (ElementNotVisibleException e) {
            e.printStackTrace();
        }finally {
            screenshotNames = screenshotNames + ","+ stepNo+".jpg";
            getScreenShot(this.driver, currentFolderName + "/"+(stepNo++)+".jpg");
        }

        return null;
    }

    public void selectFromLi1 (String value, WebDriver driver) throws Exception {
        List<WebElement> li;

        try{
            li = driver.findElements(By.xpath("//li[text() = '"+value.toUpperCase()+"']"));
        }catch (NoSuchElementException ne)
        {
            li = driver.findElements(By.xpath("//li[text() = '"+value+"']"));
        }


        if(li.size()>1)
        {
            li.get(li.size()-1).click();
            screenshotNames = screenshotNames + ","+ stepNo+".jpg";
            getScreenShot(this.driver, currentFolderName + "/"+(stepNo++)+".jpg");
        }else{

            try {
                driver.findElement(By.xpath("//li[text() = '" + value.toUpperCase() + "']")).click();
            }catch (NoSuchElementException ne)
            {
                driver.findElement(By.xpath("//li[text() = '" + value + "']")).click();
            }

            screenshotNames = screenshotNames + ","+ stepNo+".jpg";
            getScreenShot(this.driver, currentFolderName + "/"+(stepNo++)+".jpg");
        }

    }

    public void selectFromLi(String value, WebDriver driver) throws Exception {

        List<WebElement> li = null;
        WebElement h;

   /*try {
        li = driver.findElements(By.xpath("//li[text() = '" + value.toUpperCase() + "']"));
    } catch (NoSuchElementException e){
        li = driver.findElements(By.xpath("//li[text() = '" + value + "']"));
    }*/

        if (!checkElementExists(driver, "//li[text() = '" + value.toUpperCase() + "']")) {
            li = driver.findElements(By.xpath("//li[text() = '" + value.toUpperCase() + "']"));
        } else {
            li = driver.findElements(By.xpath("//li[text() = '" + value + "']"));
        }


        if (li.size() > 1) {
            Thread.sleep(500);

            // ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", li.get(li.size() - 1));
            li.get(li.size() - 1).click();
            screenshotNames = screenshotNames + "," + stepNo + ".jpg";
            getScreenShot(this.driver, currentFolderName + "/" + (stepNo++) + ".jpg");
        } else {
            if (!checkElementExists(driver, "//li[text() = '" + value.toUpperCase() + "']")) {

                h = driver.findElement(By.xpath("//li[text() = '" + value.toUpperCase() + "']"));
                // ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", h);
                driver.findElements(By.xpath("//li[text() = '" + value.toUpperCase() + "']")).get(0).click();
            } else {

                h = driver.findElement(By.xpath("//li[text() = '" + value + "']"));
                // ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", h);
                driver.findElements(By.xpath("//li[text() = '" + value + "']")).get(0).click();
            }

            screenshotNames = screenshotNames + "," + stepNo + ".jpg";
            getScreenShot(this.driver, currentFolderName + "/" + (stepNo++) + ".jpg");
        }

    }

    public static boolean checkElementExists(WebDriver driver, String xpath) {
        Boolean result = null;

        try {
            driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
            driver.findElements(By.xpath(xpath));
            result = true;
        } catch (NoSuchElementException e) {
            result = false;
        } finally {
            driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        }
        return result;
    }


}
