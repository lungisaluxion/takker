package esp.regression;

import esp.formHandlers.EspFormHandler;
import esp.formHandlers.EspMaintenanceFormHandler;
import esp.formHandlers.EspProductFormHandler;
import esp.formHandlers.GeneralFormHandler;
import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import reporting.TestReport;
import reporting.TestReportForUI;
import utilities.GetPropertyFileValues;
import utilities.HelperMethods;
import za.co.absa.functionstechnology.automation.selenium.WebdriverUtil;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;
import java.util.List;
import java.util.logging.Logger;
import java.util.Iterator;
import java.util.Map;

import static junit.framework.TestCase.fail;
import static utilities.CommonUtil.createScreenShotFolder;
import static utilities.CommonUtil.getCurrentTimeStamp;

//@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class EspTestDriver {
    private static final Logger LOGGER = Logger.getLogger(EspTestDriver.class.getName());
    public static Map<String, String> driverSheet = new LinkedHashMap();
    public static ArrayList screenshotFilenameCollection = new ArrayList();
    public static String currentFolderName = "";
    public static int stepNo = 1;
    public static int failNo = 1;
    public static String screenshotNames = "";
    static Long startTime;
    static EspFormHandler espFormHandler;
    static EspMaintenanceFormHandler espMaintenanceFormHandler;
    static EspProductFormHandler espProductFormHandler;
    public ArrayList<Properties> testResultsHolder = new ArrayList();
    WebDriver driver;
    utilities.CommonUtil element;
    Properties espProperties = new Properties();
    HashMap<String, File> reportFileLocations;
    Properties testResult = new Properties();
    GeneralFormHandler generalFormHandler;
    private ArrayList screenshotFoldernameCollection = new ArrayList();
    private ArrayList testDurations = new ArrayList();
    private GetPropertyFileValues properties = new GetPropertyFileValues();
    private int startRow;
    private int endRow;


    @BeforeTest
    public void setUp() throws IOException {
        espFormHandler = new EspFormHandler();
        generalFormHandler = new GeneralFormHandler();
        espMaintenanceFormHandler = new EspMaintenanceFormHandler();
        espProperties = properties.getPropValues("espTestData/esp.properties");
        startRow = Integer.valueOf(espProperties.getProperty("fromRow"));
        endRow = Integer.valueOf(espProperties.getProperty("toRow"));

        System.setProperty("webdriver.chrome.driver", "C:\\drivers\\chromedriver.exe");
       // WebdriverUtil webdriver = new WebdriverUtil(espProperties.getProperty("baseUrl"));
    }

    public void launchBrowser() {

        //System.setProperty("webdriver.edge.driver", "C:\\drivers\\MicrosoftWebDriver.exe");
        //driver = new EdgeDriver();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        switch (espProperties.getProperty("testEnvironment").toLowerCase()){
            case  "dev":
                driver.get(espProperties.getProperty("baseUrl-dev"));
            break;
            case  "sit":
                driver.get(espProperties.getProperty("baseUrl-sit"));
                break;
            case  "uat":
                driver.get(espProperties.getProperty("baseUrl-uat"));
                break;
            case  "trn":
                driver.get(espProperties.getProperty("baseUrl-trn"));
                break;

        }

//        JavascriptExecutor js = (JavascriptExecutor) driver;
//        js.executeScript("document.html.body.zoom='80%'");



        currentFolderName = espProperties.getProperty("imagePath").toString() + getCurrentTimeStamp("yyyy-MM-dd hh-mm-ss -SSS");
        try {
            driver.switchTo().alert();
//Selenium-WebDriver Java Code for entering Username & Password as below:
            driver.findElement(By.id("userID")).sendKeys("d_absa\\ablz098");
            driver.findElement(By.id("password")).sendKeys("");
            driver.switchTo().alert().accept();
            driver.switchTo().defaultContent();
        }catch (Exception e){
            System.out.println(e.getMessage() +"\nNo popup");
        }
    }

    @Test
    public void onboardingTestDriver() throws Exception {
        espProperties = properties.getPropValues("espTestData/esp.properties");
        XSSFWorkbook myExcelBook = new XSSFWorkbook(new FileInputStream(espProperties.getProperty("path_driversheet").toString()));
        XSSFSheet myExcelSheet = myExcelBook.getSheet("OnboardingDriver");

        for (int i = 1; i < myExcelSheet.getPhysicalNumberOfRows(); i++) {
            driverSheet = new HelperMethods().getTestData(espProperties.getProperty("path_driversheet").toString(), "OnboardingDriver", i);
            if (driverSheet.get("ExecutionFlag").toString().equalsIgnoreCase("YES")) {

                launchBrowser();
                //System.out.println(driver.getPageSource());
                try {
                    createScreenShotFolder(currentFolderName);

                    startTime = System.nanoTime();
                    System.out.println("Test ID " + driverSheet.get("TestID").toString() + "========================== Test Description " + driverSheet.get("TestDescription").toString() + "=======================================");

                    if (driverSheet.get("Create/Edit").toString().equalsIgnoreCase("Edit"))
                        espFormHandler.editEntity(driver, Integer.parseInt(driverSheet.get("BasicClientInfo").toString()));
                    else {
                        espFormHandler.createInstruction(driver);
                        espFormHandler.entitySelection(driver, Integer.parseInt(driverSheet.get("BasicClientInfo")));

                    }
                    Iterator<Map.Entry<String, String>> iterator = driverSheet.entrySet().iterator();


                    while (iterator.hasNext()) {
                        Map.Entry<String, String> entry = iterator.next();

                        if (entry.getValue() != null && !entry.getValue().isEmpty()) {

                            System.out.println("Sheet : " + entry.getKey());

                            switch (entry.getKey()) {
                                case "ClientDetailsPrimaryParty":
                                    espFormHandler.clientDetailsPrimary_v1(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "AddRelatedParty":
                                    espFormHandler.addRelatedParties_v2(driver,Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "DetailedClientInfo_CD":
                                    espFormHandler.detailedCIClientDetails_v1(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "DetailedClientAddressPrimary":
                                    espFormHandler.addressDetailsPrimary_v1(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "DetailedClientContactPrimary":
                                    espFormHandler.contactDetailsPrimary_v1(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "DetailedClientRegulatory":
                                    espFormHandler.regulatoryPrimary_v1(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "ControlOfficerLinking":
                                    espFormHandler.controlOfficerLinking(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "BranchAndBankerPrimary":
                                    espFormHandler.branchAndBankerDetailsPrimary_v1(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case " Office Use":
                                    espFormHandler.officeUse_dci_v1(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "Product":
                                    espFormHandler.product(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "Document Pre-Population":
                                    espFormHandler.documentPrepopulation_v1(driver, Integer.parseInt(driverSheet.get(entry.getKey())));

                                    break;
                                case "ScreeningPrimaryParty":
                                    espFormHandler.screening(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "Documents":
                                    espFormHandler.documentSelection_v1(driver);
                                    break;

                            }
                        }
                    }

                    //espFormHandler.completion(driver);


                    testResultsSetProperties(String.valueOf(i), driverSheet.get("TestDescription").toString(), "PASSED", "PASSED", "PASSED", "", "00");
                    testResultsHolder.add(testResult);
                    screenshotFoldernameCollection.add(currentFolderName);
                    screenshotFilenameCollection.add(screenshotNames);
                    Long endTime = System.nanoTime();
                    testDurations.add(endTime - startTime);

                } catch (Exception e) {
                    System.out.println("error : "+e.getMessage());
                    testResultsSetProperties(String.valueOf(i), driverSheet.get("TestDescription").toString(), "FAILED", "PASSED", "FAILED", "", "00");
                    screenshotNames = screenshotNames + ",fail" + failNo + ".jpg";
                    getScreenShot(currentFolderName + "/fail" + (failNo++) + ".jpg");
                    testResultsHolder.add(testResult);
                    screenshotFoldernameCollection.add(currentFolderName);
                    screenshotFilenameCollection.add(screenshotNames);
                    Long endTime = System.nanoTime();
                    testDurations.add(endTime - startTime);
                }


            }
        }

        after();

    }

   //@Test
    public void maintenanceTestDriver() throws Exception {

        espProperties = properties.getPropValues("espTestData/esp.properties");
        XSSFWorkbook myExcelBook = new XSSFWorkbook(new FileInputStream(espProperties.getProperty("path_driversheet").toString()));
        XSSFSheet myExcelSheet = myExcelBook.getSheet("MaintenanceDriver");

        for (int i = 1; i < myExcelSheet.getPhysicalNumberOfRows(); i++) {
            driverSheet = new HelperMethods().getTestData(espProperties.getProperty("path_driversheet").toString(), "MaintenanceDriver", i);
            if (driverSheet.get("ExecutionFlag").toString().equalsIgnoreCase("YES")) {
                launchBrowser();
                try {

                    createScreenShotFolder(currentFolderName);

                    startTime = System.nanoTime();
                    System.out.println("Test ID " + driverSheet.get("TestID").toString() + "========================== Test Description " + driverSheet.get("TestDescription").toString() + "=======================================");

                    //Call methods
                    Iterator<Map.Entry<String, String>> iterator = driverSheet.entrySet().iterator();


                    while (iterator.hasNext()) {
                        Map.Entry<String, String> entry = iterator.next();

                        if (entry.getValue() != null && !entry.getValue().isEmpty()) {

                            System.out.println("Sheet : " + entry.getKey());

                            switch (entry.getKey()) {
                                case "CustomerSearch":
                                    generalFormHandler.searchCustomer("path_MaintenanceData", driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "BasicInfoMaintenance":
                                    espMaintenanceFormHandler.basicInfoMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "BranchAndBankerPrimary":
                                    espMaintenanceFormHandler.branchAndBankerMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "AddressDetails":
                                    espMaintenanceFormHandler.addressDetailsMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "CreditAnalyst":
                                    espMaintenanceFormHandler.creditAnalystMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "GroupLeader":
                                    espMaintenanceFormHandler.groupLeaderMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "Application":
                                    espMaintenanceFormHandler.applicationMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "MainUsers":
                                    espMaintenanceFormHandler.mainUsersMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "InternetBankingDetails":
                                    espMaintenanceFormHandler.internetBankingDetailsMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "FinancialInformation":
                                    espMaintenanceFormHandler.financialInformationMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "3. Account":
                                    espMaintenanceFormHandler.accountMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "4. Product":
                                    espMaintenanceFormHandler.productMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "Pricing":
                                    espMaintenanceFormHandler.pricingMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "Securities":
                                    espMaintenanceFormHandler.securitiesMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "ModelSelection":
                                    espMaintenanceFormHandler.modelSelectionMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "Service":
                                    espMaintenanceFormHandler.serviceMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "ServicesRequired":
                                    espMaintenanceFormHandler.serviceRequiredMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "Limits":
                                    espMaintenanceFormHandler.limitsMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "DocumentPre-Population":
                                    espMaintenanceFormHandler.documentPrePopulationMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "OfficeUse":
                                    espMaintenanceFormHandler.officeUseMaintenance(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                            }

                        }

                    }
                    espMaintenanceFormHandler.documentsMaintenance(driver, 1);
                    testResultsSetProperties(driverSheet.get("TestID").toString(), driverSheet.get("TestDescription").toString(), "PASSED", "PASSED", "PASSED", "", "00");
                    testResultsHolder.add(testResult);
                    screenshotFoldernameCollection.add(currentFolderName);
                    screenshotFilenameCollection.add(screenshotNames);
                    Long endTime = System.nanoTime();
                    testDurations.add(endTime - startTime);

                } catch (Exception e) {
                    System.out.println(e.getMessage());
                    testResultsSetProperties("1", "Description", "FAILED", "PASSED", "FAILED", e.getMessage(), "00");
                    screenshotNames = screenshotNames + ",fail" + failNo + ".jpg";
                    getScreenShot(currentFolderName + "/fail" + (failNo++) + ".jpg");
                    testResultsHolder.add(testResult);
                    screenshotFoldernameCollection.add(currentFolderName);
                    screenshotFilenameCollection.add(screenshotNames);
                    Long endTime = System.nanoTime();
                    testDurations.add(endTime - startTime);
                }

                after();
            }

        }
    }

    //@Test
    public void productOnboardingTest() throws Exception {
        espProperties = properties.getPropValues("espTestData/esp.properties");
        XSSFWorkbook myExcelBook = new XSSFWorkbook(new FileInputStream(espProperties.getProperty("path_driversheet").toString()));
        XSSFSheet myExcelSheet = myExcelBook.getSheet("ProductDriver");


        for (int i = 1; i < myExcelSheet.getPhysicalNumberOfRows(); i++) {
            driverSheet = new HelperMethods().getTestData(espProperties.getProperty("path_driversheet").toString(), "ProductDriver", i);

            if (driverSheet.get("ExecutionFlag").toString().equalsIgnoreCase("YES")) {

                launchBrowser();

                try {
                    createScreenShotFolder(currentFolderName);
                    startTime = System.nanoTime();




                    testResultsSetProperties(String.valueOf(i), driverSheet.get("TestDescription").toString(), "PASSED", "PASSED", "PASSED", "", "");
                    testResultsHolder.add(testResult);
                    screenshotFoldernameCollection.add(currentFolderName);
                    screenshotFilenameCollection.add(screenshotNames);
                    Long endTime = System.nanoTime();
                    testDurations.add(endTime - startTime);

                } catch (Exception e) {

                    testResultsSetProperties(String.valueOf(i), driverSheet.get("TestDescription").toString(), "FAILED", "PASSED", "FAILED", "", "");
                    screenshotNames = screenshotNames + ",fail" + failNo + ".jpg";
                    getScreenShot(currentFolderName + "/fail" + (failNo++) + ".jpg");
                    testResultsHolder.add(testResult);
                    screenshotFoldernameCollection.add(currentFolderName);
                    screenshotFilenameCollection.add(screenshotNames);
                    Long endTime = System.nanoTime();
                    testDurations.add(endTime - startTime);

                }
            }

        }
    }


    @Test
    public void ACSBproductOnboardingTest() throws Exception {
        espProperties = properties.getPropValues("espTestData/esp.properties");
        XSSFWorkbook myExcelBook = new XSSFWorkbook(new FileInputStream(espProperties.getProperty("path_driversheet").toString()));
        XSSFSheet myExcelSheet = myExcelBook.getSheet("ACSB-productOnboardingDriver");


        for (int i = 1; i < myExcelSheet.getPhysicalNumberOfRows(); i++) {
            driverSheet = new HelperMethods().getTestData(espProperties.getProperty("path_driversheet").toString(), "ACSB-productOnboardingDriver", i);

            if (driverSheet.get("ExecutionFlag").toString().equalsIgnoreCase("YES")) {

                launchBrowser();
                espProductFormHandler = new EspProductFormHandler();

                try {
                    createScreenShotFolder(currentFolderName);
                    startTime = System.nanoTime();
                    System.out.println("Test ID " + driverSheet.get("TestID").toString() + "========================== Test Description " + driverSheet.get("TestDescription").toString() + " =======================================");

                    if (driverSheet.get("Create/Edit").toString().equalsIgnoreCase("Edit")) {
                        espProductFormHandler.editEntity(driver, Integer.parseInt(driverSheet.get("InstructionDetails").toString()));
                        espProductFormHandler.basicInfoSecurityDisclaimer(driver);
                    } else {
                        espProductFormHandler.createInstruction(driver);
                        espProductFormHandler.instructionDetails(driver, Integer.parseInt(driverSheet.get("InstructionDetails")));
                        espProductFormHandler.basicInfoSecurityDisclaimer(driver);

                    }
                    Iterator<Map.Entry<String, String>> iterator = driverSheet.entrySet().iterator();

                    while (iterator.hasNext()) {
                        Map.Entry<String, String> entry = iterator.next();

                        if (entry.getValue() != null && !entry.getValue().isEmpty()) {

                            System.out.println("Sheet : " + entry.getKey());

                            switch (entry.getKey()) {
                                case "Detailed Client Details":
                                    espProductFormHandler.clientDetails(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "A-SecurityDisclaimer":
                                    espProductFormHandler.securityDisclaimer(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "B1-Principal-Additional-Details":
                                    espProductFormHandler.principalAdditionalDetails(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "C-FacilitySelection":
                                    espProductFormHandler.facilitySelection(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "DI-ChequeOverdraft":
                                    espProductFormHandler.chequeOverdraft(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "D4-TermLoan":
                                    espProductFormHandler.termLoan(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "Z-Application":
                                    espProductFormHandler.application(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "K-SMS-SecuritiesOffered":
                                    espProductFormHandler.smsSecuritiesOffered(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "P4-spouceCo-habitor":
                                    espProductFormHandler.spouseORCo_habitor(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;
                                case "GeneralQualitativeInformation":
                                    espProductFormHandler.generalQualitativeInformation(driver, Integer.parseInt(driverSheet.get(entry.getKey())));
                                    break;

                                    //

                            }
                        }
                    }

                    espProductFormHandler.completion(driver);



                    testResultsSetProperties(String.valueOf(i), driverSheet.get("TestDescription").toString(), "PASSED", "PASSED", "PASSED", "", "");
                    testResultsHolder.add(testResult);
                    screenshotFoldernameCollection.add(currentFolderName);
                    screenshotFilenameCollection.add(screenshotNames);
                    Long endTime = System.nanoTime();
                    testDurations.add(endTime - startTime);

                } catch (Exception e) {
                    System.out.println(e.getMessage());
                    testResultsSetProperties(String.valueOf(i), driverSheet.get("TestDescription").toString(), "FAILED", "PASSED", "FAILED", "", "");
                    screenshotNames = screenshotNames + ",fail" + failNo + ".jpg";
                    getScreenShot(currentFolderName + "/fail" + (failNo++) + ".jpg");
                    testResultsHolder.add(testResult);
                    screenshotFoldernameCollection.add(currentFolderName);
                    screenshotFilenameCollection.add(screenshotNames);
                    Long endTime = System.nanoTime();
                    testDurations.add(endTime - startTime);

                    new Exception();
                }
            }

        }
    }

    //@Test
    public void sampleTest() throws Exception {

        createScreenShotFolder(currentFolderName);
        startTime = System.nanoTime();

    }

    public void testResultsSetProperties(String testId, String testDescription, String result, String expectedResult, String actualResult, String reason, String severity) {

        testResult = new Properties();

        testResult.setProperty("Test ID", testId);
        testResult.setProperty("Test Description", testDescription);
        testResult.setProperty("Result", result);
        testResult.setProperty("ExpectedResult", expectedResult);
        testResult.setProperty("ActualResult", actualResult);
        testResult.setProperty("Reason", reason);
        testResult.setProperty("severity", severity);
    }


    public void getScreenShot(String fileName) {
        try {
            File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(scrFile, new File(fileName));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //@After
    public void after() throws IOException {
        //check if this is the last test case.
        TestReport report = new TestReportForUI(espProperties.getProperty("reportFolder"));
        report.createReportFile("ESP Onboarding", "Onboard CC");
        report.buildReport(testResultsHolder, espProperties.getProperty("testEnvironment"), screenshotFoldernameCollection, screenshotFilenameCollection, testDurations);
        report.writeReportFile();
        if (new HelperMethods().checkFailure(testResultsHolder)) {
            fail("Run Unsuccessful. One Or More Of The Tests Have Failed." + "\n" + "Please see the report.");
        }

        testResultsHolder.clear();
        testDurations.clear();
        screenshotFilenameCollection.clear();
        screenshotFoldernameCollection.clear();
        driver.close();

    }
}
