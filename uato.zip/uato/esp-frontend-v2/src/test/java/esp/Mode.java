package esp;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.DesiredCapabilities;
import utilities.CommonUtil;

import java.io.FileInputStream;
import java.lang.reflect.Array;
import java.util.*;

import static esp.regression.EspTestDriver.currentFolderName;
import static esp.regression.EspTestDriver.failNo;
import static esp.regression.EspTestDriver.screenshotNames;
import static utilities.ObjectManager.MinimizeWorkHistory;
import static utilities.ObjectManager.OnBoardingInstruction;
import static utilities.ReadTestData.fetchTestData;

public class Mode {
    public static void main(String[] args) throws Exception{
        String idNumber = "890616";

        String dateOfBirth = "";
        Date year = new Date();
        if(Integer.parseInt(idNumber.substring(0,2))<=(year.getYear()-100)){
            dateOfBirth = "20"+idNumber.substring(0,2)+"/"+idNumber.substring(2,4)+"/"+idNumber.substring(4,6);
        }
        else {
            dateOfBirth = "19"+idNumber.substring(0,2)+"/"+idNumber.substring(2,4)+"/"+idNumber.substring(4,6);
        }
        System.out.println(dateOfBirth);
    }

    public static int mode(int[] A)throws Exception{

        int ans = 0;
            return ans;

    }
    @Test
    public void c(){
        for(int i = 0;i < 10; i++){
            for(int j=5;(j>i);j--){
                System.out.print("*");

            }
            System.out.println();
            if(i==5){
                System.out.print("");
            }
        }

    }
    @org.testng.annotations.Test(invocationCount = 20,threadPoolSize = 20)
    public void loadTest(){
        System.setProperty("webdriver.chrome.driver", "C:\\drivers\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        long startTime,endTime;
        startTime = new Date().getTime();
        driver.get("http://espsit.intranet.barcapint.com");
        //System.out.println(driver.getTitle() + "-- Thread ID : "+ Thread.currentThread().getId());
        endTime =  new Date().getTime();
        long homePageLoad = endTime-startTime;

        //edit instruction
        CommonUtil element = new utilities.CommonUtil(driver);

        driver.switchTo().defaultContent();
        long onboardingListing=0;
        try {

            startTime = new Date().getTime();
            driver.findElement(By.xpath("//span[text()='On-Boarding']/following::span[contains(text(), 'My Instructions')]")).click();
            driver.findElement(By.xpath(MinimizeWorkHistory)).click();

            driver.switchTo().frame("pEspDefaultContent_IFrame");
            endTime =  new Date().getTime();
            onboardingListing = endTime-startTime;
            startTime = new Date().getTime();
            String icon = "//td[*[contains(text(),'45863')]]/following-sibling::td//div[@cmd='Edit']";
            WebElement edit = driver.findElement(By.xpath(icon));

            Thread.sleep(1000);

            edit.click();

            try{
               // element.clickOnElement("xpath||//*[text()='The entity CIPC status is not available. Would You like to continue with the instruction?']/following::span[text()='Yes']");
            }catch (Exception e){
                System.out.println("No CIPC popup");
            }

        } catch (Exception e) {
            //System.out.println(e.getMessage());
        }
        endTime =  new Date().getTime();
        long editInstructionLoadTime = endTime-startTime;
        //System.out.println(driver.getTitle()+ "\n Home "+ homePageLoad+"\n Onboarding My Instruction List " + onboardingListing + "\n Edit Instruction "+editInstructionLoadTime);
        System.out.println(homePageLoad+","+onboardingListing+","+editInstructionLoadTime);
        driver.close();
    }

    @Test
    public void fireFox(){
        System.setProperty("webdriver.gecko.driver", "C:\\drivers\\geckodriver.exe");
        ProfilesIni profile = new ProfilesIni();
        FirefoxProfile testprofile = profile.getProfile("Abhi_Selenium");
        DesiredCapabilities dc = DesiredCapabilities.firefox();
        dc.setCapability(FirefoxDriver.PROFILE, testprofile);
        FirefoxOptions opt = new FirefoxOptions();
        opt.addTo(dc);
        WebDriver driver =  new FirefoxDriver(opt);
        driver.get("https://www.google.com");

    }

    @Test
    public void fibb(){
        //1 1 2 3 5 8 13 21 34 ...
        int x=1,y = 1;
        int z=0;
        System.out.print(x +" "+ y);
        do{
            z = x+y;
            System.out.print(" "+z);
            x = y;
            y = z;
        }while (z <21);


    }
}
