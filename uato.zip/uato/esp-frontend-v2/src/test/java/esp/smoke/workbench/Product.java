package esp.smoke.workbench;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import esp.smoke.Generic;

public class Product extends Generic{
	
	public Product(){
		
	}

	public Product(WebDriver driver){
		this.driver = driver;
	}
	
	public void administration() throws InterruptedException{
		WebElement administration = findElementbyId("-record-ext-record-29");
		administration.click();
		System.out.println("Product - Administration Clicked");
		Thread.sleep(5000);
		
		clickCreateButton();
		System.out.println("Product - Administration - Create Button Clicked");
		
	}
	
	public void myInstructions() throws InterruptedException{
		WebElement productOnBoardingInstructions = findElementbyId("-record-ext-record-30");
		productOnBoardingInstructions.click();
		System.out.println("Product - My Instructions Clicked");
		Thread.sleep(8000);
		captureScreenshot("ProductMyInstructions");
		
		clickCreateButton();
		System.out.println("Product - My Instructions - Create Button Clicked");
		captureScreenshot("ProductMyInstructionsCreateButton");
	}
	
	public void acsbInstructions() throws InterruptedException{
		WebElement acsbInstructions = findElementbyId("-record-ext-record-31");
		acsbInstructions.click();
		System.out.println("Product on Boarding ACSB Instructions Clicked");
		Thread.sleep(8000);
		captureScreenshot("ProductAcsbInstructions");
	}
	
	public void externalInsructions() throws InterruptedException{
		WebElement exInstructions = findElementbyId("-record-ext-record-32");
		exInstructions.click();
		System.out.println("Product on Boarding External Instructions Clicked");
		Thread.sleep(8000);
		captureScreenshot("ProductExternalInsructions");
	}
	

}
