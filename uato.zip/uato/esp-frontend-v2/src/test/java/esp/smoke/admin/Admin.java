package esp.smoke.admin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import esp.smoke.Generic;

public class Admin extends Generic{
	
	public Admin(){
	}
	
	public Admin(WebDriver driver){
		this.driver = driver;
	}

	public void userAccess() throws InterruptedException{
		WebElement adminMenu = driver.findElement(By.id("btnMenuCategory4"));
		adminMenu.click();
		System.out.println("Admin Menu - Clicked");
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//span[text()='User Access']")).click();
		System.out.println("Admin Menu - User Access Clicked");
		Thread.sleep(10000);
		captureScreenshot("Admin_UserAccess");
	}
	
	public void userGroupAdmin() throws InterruptedException{
		WebElement adminMenu = driver.findElement(By.id("btnMenuCategory4"));
		adminMenu.click();
		System.out.println("Admin Menu - Clicked");
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//span[text()='User Group Admin']")).click();
		System.out.println("Admin Menu - User Group Admin Clicked");
		Thread.sleep(10000);
		captureScreenshot("Admin_UserGroupAdmin");
	}
	
	public void tRAdmin() throws InterruptedException{
		WebElement adminMenu = driver.findElement(By.id("btnMenuCategory4"));
		adminMenu.click();
		System.out.println("Admin Menu - Clicked");
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//span[text()='TR Admin']")).click();
		System.out.println("Admin Menu - TR Admin Clicked");
		Thread.sleep(10000);
		captureScreenshot("Admin_TRAdmin");
	}
	
	public void manangeCommunication() throws InterruptedException{
		WebElement adminMenu = driver.findElement(By.id("btnMenuCategory4"));
		adminMenu.click();
		System.out.println("Admin Menu - Clicked");
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//span[text()='Manage Communication']")).click();
		System.out.println("Admin Menu - Manage Communication Clicked");
		Thread.sleep(10000);
		captureScreenshot("Admin_manageCommunication");
	}
	
	
	
	
}
