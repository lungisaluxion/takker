package esp.smoke.workbench;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import esp.smoke.Generic;

public class Leads extends Generic{
	
	public Leads(){
	}
		
	public Leads(WebDriver driver){
		this.driver = driver;
	}
	
	public void administration() throws InterruptedException{
		WebElement administration = findElementbyId("-record-ext-record-14");
		//WebElement administration = driver.findElement(By.id("treeview-1241-record-ext-record-14"));
		administration.click();
		System.out.println("Leads Administration Clicked");
		Thread.sleep(8000);
		captureScreenshot("LeadAdministration");
	}
	
	public void team() throws InterruptedException{
		WebElement teamItems = findElementbyId("-record-ext-record-15");
		//WebElement teamItems = driver.findElement(By.id("treeview-1241-record-ext-record-15"));
		teamItems.click();
		System.out.println("Leads Team Items Clicked");
		Thread.sleep(8000);
		captureScreenshot("LeadTeamItems");
	}
	
	public void myItems() throws InterruptedException{
		WebElement myItems = findElementbyId("-record-ext-record-16");
		myItems.click();
		System.out.println("Leads My Items Clicked");
		Thread.sleep(8000);
		captureScreenshot("LeadMyItems");
	}
	
	
}
