package esp.smoke;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class ESP {
	
	 public static WebDriver  driver;
	
	public static WebDriver openChromeBrowser() throws InterruptedException{
		String exePath = "C:\\drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);
		driver = new ChromeDriver();
		return driver;
		
	}
	
	public WebDriver openIEBrowser() throws InterruptedException{
		String exePath = "C:\\Software\\IEDriver\\IEDriverServer_Win32_3.9.0\\IEDriverServer.exe";
		System.setProperty("webdriver.ie.driver", exePath);
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability("ignoreZoomSetting", true);
		InternetExplorerDriver driver = new InternetExplorerDriver(capabilities);
		return driver;
		
	}


}
