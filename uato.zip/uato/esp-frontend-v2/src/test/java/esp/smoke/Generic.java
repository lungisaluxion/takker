package esp.smoke;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;

import java.io.File;
import java.io.IOException;

public class Generic {
	
	public WebDriver driver;
	public String envFindString;
	
	public WebElement findElementbyId(String idSubstring){
		WebElement element = driver.findElement(By.id(getEnvFindString()+ idSubstring));
		return element;
	}
	
	public void clickCreateButton() throws InterruptedException{
		//switch to pEspDefaultContent_IFrame Frame
		driver.switchTo().frame("pEspDefaultContent_IFrame");
		
		WebElement create = driver.findElement(By.id("DashboardUserControl_btnCreate"));
		create.click();
		Thread.sleep(30000);
		
		//switch back Default Content Frame
		driver.switchTo().defaultContent();
	}
	
	public void captureScreenshot(String pageName){
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(scrFile, new File("C:\\Users\\ablz098\\Desktop\\ESP\\SmokeTesting\\"+ pageName + ".png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public String getEnvFindString() {
		return envFindString;
	}

	public void setEnvFindString(String envFindString) {
		WebElement ele = driver.findElement(By.xpath("//tr[contains(@id,'treeview-')]"));

		this.envFindString = ele.getAttribute("data-boundview");// envFindString;
	}

}
