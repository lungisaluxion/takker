package esp.smoke.workbench;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import esp.smoke.Generic;

public class Task extends Generic{

	public Task(){
	}
	
	public Task(WebDriver driver){
		this.driver = driver;
	}
	
	public void myTasks() throws InterruptedException{
		WebElement myTask = findElementbyId("-record-ext-record-32");
		myTask.click();
		System.out.println("Task My Tasks Clicked");
		Thread.sleep(5000);
	}

}
