package esp.smoke.tools;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import esp.smoke.Generic;

public class DocumentUpload extends Generic{
	
	public DocumentUpload(){
	}
	
	public DocumentUpload(WebDriver driver){
		this.driver = driver;
	}
	
	public void docUpload() throws InterruptedException{
		WebElement toolsMenu = driver.findElement(By.id("btnMenuCategory2"));
		toolsMenu.click();
		Thread.sleep(5000);
		System.out.println("Tools Menu - Clicked");
		
		driver.findElement(By.xpath("//span[text()='Document Upload']")).click();
		System.out.println("Tools Menu - Document Upload Clicked");
		Thread.sleep(15000);
		captureScreenshot("ToolsMenu_DocumentUpload");
		
		
		driver.findElement(By.id("btnMenuCategory2")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//span[text()='ESP.tv']")).click();
		System.out.println("Tools Menu - ESP.tv Clicked");
		Thread.sleep(10000);
		captureScreenshot("ToolsMenu_ESPtv");

	}

}
