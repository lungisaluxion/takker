package esp.smoke.reports;

import esp.smoke.Generic;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Reports extends Generic {

	public Reports(){
	}
	
	public Reports(WebDriver driver){
		this.driver = driver;
	}
	
	public void reportCentral() throws InterruptedException{
		WebElement reportMenu = driver.findElement(By.id("btnMenuCategory1"));
		reportMenu.click();
		Thread.sleep(5000);
		System.out.println("Reports Menu - Clicked");
		
		driver.findElement(By.xpath("//span[text()='Report Central']")).click();
		System.out.println("Reports Menu - Report Central Clicked");
		Thread.sleep(10000);
		captureScreenshot("Reports_ReportCentral");
	}
	
	public void offlineReports() throws InterruptedException{
		WebElement reportMenu = driver.findElement(By.id("btnMenuCategory1"));
		reportMenu.click();
		Thread.sleep(5000);
		System.out.println("Reports Menu - Clicked");
		
		driver.findElement(By.xpath("//span[text()='User : Offline Reports']")).click();
		System.out.println("Reports Menu - User : Offline Reports Clicked");
		Thread.sleep(10000);
		captureScreenshot("Reports_Offline");
	}
	
	public void migratedInstructions() throws InterruptedException{
		WebElement reportMenu = driver.findElement(By.id("btnMenuCategory1"));
		reportMenu.click();
		Thread.sleep(5000);
		System.out.println("Reports Menu - Clicked");
		
		driver.findElement(By.xpath("//span[text()='User : Migrated Instructions']")).click();
		System.out.println("Reports Menu - User : Migrated Instructions Clicked");
		Thread.sleep(10000);
		captureScreenshot("Reports_MigratedInstructions");
	}
	
}
