package esp.smoke.workbench;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import esp.smoke.Generic;

public class Maintenance extends Generic{
	
	public Maintenance(){
	}
	
	public Maintenance(WebDriver driver){
		this.driver = driver;
	}
	
	public void administration() throws InterruptedException{
		WebElement administration = findElementbyId("-record-ext-record-21");
		administration.click();
		System.out.println("Maintenance Administration Clicked");
		Thread.sleep(5000);
		captureScreenshot("MaintenanceAdministration");
		
		clickCreateButton();
		System.out.println("Maintenance - Administration - Create Button Clicked");
		captureScreenshot("MaintenanceAdministrationCreateButton");
	}
	
	public void myInstructions() throws InterruptedException{
		WebElement myInstructions = findElementbyId("-record-ext-record-22");
		myInstructions.click();
		System.out.println("Maintenance - My Instructions Clicked");
		Thread.sleep(5000);
		captureScreenshot("MaintenanceMyInstructions");
		
		clickCreateButton();
		System.out.println("Maintenance - My Instructions - Create Button Clicked");
		captureScreenshot("MaintenanceMyInstructionsCreateButton");
	}
	
	
	
}
