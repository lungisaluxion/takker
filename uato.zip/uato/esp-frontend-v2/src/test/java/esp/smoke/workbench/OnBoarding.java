package esp.smoke.workbench;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import esp.smoke.Generic;

public class OnBoarding extends Generic{
	
	public OnBoarding(){
	}
	
	public OnBoarding(WebDriver driver){
		this.driver = driver;
	}
	
	public void myInstructions() throws InterruptedException{
		WebElement onBoardingInstructions = findElementbyId("-record-ext-record-24");
		onBoardingInstructions.click();
		System.out.println("on Boarding - My Instructions Clicked");
		Thread.sleep(8000);
		captureScreenshot("OnBoardingMyInstructions");
		
		clickCreateButton();
		System.out.println("On Boarding - My Instructions - Create Button Clicked");
		captureScreenshot("OnBoardingMyInstructionsCreateButton");
	}
	
	public void administration() throws InterruptedException{
		WebElement administration = findElementbyId("-record-ext-record-23");
		administration.click();
		System.out.println("On Boarding - Administration Clicked");
		Thread.sleep(8000);
		captureScreenshot("OnBoardingAdministration");
		
		clickCreateButton();
		System.out.println("On Boarding - Administration - Create Button Clicked");
		captureScreenshot("OnBoardingAdministrationCreateButton");
		
	}
	
	public void externalInstruction() throws InterruptedException{
		WebElement exInstruction = findElementbyId("-record-ext-record-25");
		exInstruction.click();
		System.out.println("on Boarding External Instructions Clicked");
		Thread.sleep(8000);
		captureScreenshot("OnBoardingExternalInstruction");
		
	}

}
