package esp.smoke.workbench;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import esp.smoke.Generic;

public class PriceReview extends Generic{

	public PriceReview(){
	}
	
	public PriceReview(WebDriver driver){
		this.driver = driver;
	}
	
	public void campaigns() throws InterruptedException{
		WebElement camp = findElementbyId("-record-ext-record-26");
		camp.click();
		System.out.println("Price Review Campaigns Clicked");
		Thread.sleep(5000);
	}
	
	public void myInstructions() throws InterruptedException{
		WebElement myInstructions = findElementbyId("-record-ext-record-27");
		myInstructions.click();
		System.out.println("Price Review My Instructions Clicked");
		Thread.sleep(5000);
	}
	
	public void instructionAdministration() throws InterruptedException{
		WebElement admin = findElementbyId("-record-ext-record-28");
		admin.click();
		System.out.println("Price Review My Instructions Clicked");
		Thread.sleep(5000);
	}
	
}
