package esp.smoke.customer;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import esp.smoke.Generic;

public class CustomerSearch extends Generic{
	
	public CustomerSearch(){
	}
	
	public CustomerSearch(WebDriver driver){
		this.driver = driver;
	}
	
	public void findCustomer() throws InterruptedException{
		WebElement customerSearchHeader = driver.findElement(By.id("pCustomerSearch_header"));
		customerSearchHeader.click();
		Thread.sleep(5000);
		
		//Input Search By -  CIF
		driver.findElement(By.xpath("//*[@id='userSearchFormControl_cmdSearchBy-inputCell']/../td[2]")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//li[text()='CIF']")).click();
		Thread.sleep(2000);
		System.out.println("Customer Search - Search By Selected");
		
		WebElement value = driver.findElement(By.id("userSearchFormControl_txtSearchValue-inputEl"));
		value.sendKeys("PUMMY  002");
		Thread.sleep(8000);
		System.out.println("Customer Search - Value Entered");
		captureScreenshot("CustomerSearch");
		
		driver.findElement(By.id("userSearchFormControl_cmdSearch")).click();
		Thread.sleep(8000);
		
		System.out.println("Customer Search - Search Clicked");
		captureScreenshot("CustomerSearchResult");
		
		//Show Menu Items
		driver.findElement(By.id("gridview-1012-body")).click();
		Thread.sleep(5000);
		
		//360 View Selection
		Actions action= new Actions(driver);
		action.contextClick().sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.RETURN).build().perform();
		Thread.sleep(10000);
		captureScreenshot("CustomerSearchResult-360View");
		System.out.println("Customer Search - Search Item 360 View Clicked");
		
		Thread.sleep(20000);
		
		//360 Report  messagebox-1001  ext-gen1975 tool-1249
		String parent = driver.getWindowHandle();
		driver.findElement(By.id("gridview-1012-body")).click();
		Thread.sleep(5000);
		action.contextClick().sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.RETURN).build().perform();
		Thread.sleep(10000);
		captureScreenshot("CustomerSearchResult-360Report");
		System.out.println("Customer Search - Search Item 360 Report Clicked");
		
	}
	        
}
