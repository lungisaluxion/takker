package esp.smoke;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import esp.smoke.admin.*;
import esp.smoke.customer.*;
import esp.smoke.reports.*;
import esp.smoke.tools.*;
import esp.smoke.workbench.*;

public class LaunchApplication{
 
	public static String env = "SIT";
	
	public static void main(String[] args) {
		
	  try{
		  
		//For Chrome 
		WebDriver driver = ESP.openChromeBrowser();

		if(env.equalsIgnoreCase("SIT")){
			//driver.get("http://espsit.intranet.barcapint.com/(S(detyvvbmfts0lmsaumyogql3))/default.aspx");
			driver.get("http://espsit.intranet.barcapint.com");
		}else if(env.equalsIgnoreCase("UAT")){
			//driver.get("http://espuat.intranet.barcapint.com/(S(e0n3c1wahz14oavuvqajgihv))/default.aspx");
			driver.get("http://espuat.intranet.barcapint.com");
		}
		
		Thread.sleep(5000);
		
		//SIT = treeview-1241 , UAT = treeview-1235

		//########## WORK BENCH ####################
		//Leads Testing
		Leads leads = new Leads(driver);
		leads.setEnvFindString(envFindString());
		leads.administration();
		leads.team();
		leads.myItems();
		
		
		//Testing Remediation
		Remediation remediation = new Remediation(driver);
		remediation.setEnvFindString(envFindString());
		remediation.administration();
		remediation.availableItems();
		remediation.myItems();
		remediation.projectItems();
		
		//Testing Maintenance
		Maintenance maintenance = new Maintenance(driver);
		maintenance.setEnvFindString(envFindString());
		maintenance.administration();
		maintenance.myInstructions();
		
		//Testing on Boarding
		OnBoarding onboarding = new OnBoarding(driver);
		onboarding.setEnvFindString(envFindString());
		onboarding.administration();
		onboarding.myInstructions();
		onboarding.externalInstruction();

		//Testing Price Review
		PriceReview priceReview = new PriceReview(driver);
		priceReview.setEnvFindString(envFindString());
		priceReview.campaigns();
		priceReview.myInstructions();
		priceReview.instructionAdministration();
	
		//Testing Product On Boarding
		Product product = new Product(driver);
		product.setEnvFindString(envFindString());
		product.administration();
		product.myInstructions();
		product.acsbInstructions();
		product.externalInsructions();
		
		Task task = new Task(driver);
		task.setEnvFindString(envFindString());
		task.myTasks();
		
		Workflow workflow = new Workflow(driver);
		workflow.setEnvFindString(envFindString());
		workflow.myItems();
		workflow.administration();
		workflow.remediation();
		workflow.unclaimed();
		
		//########## TOOLS ####################
		DocumentUpload docUpload = new DocumentUpload(driver);
		docUpload.setEnvFindString(envFindString());
		docUpload.docUpload();
		
		//########## Admin ####################
		Admin admin = new Admin(driver);
		admin.setEnvFindString(envFindString());
		admin.userAccess();
		admin.userGroupAdmin();
		admin.tRAdmin();
		admin.manangeCommunication();
		
		//########## Reports Menu ####################
		Reports reports = new Reports(driver);
		reports.reportCentral();
		reports.offlineReports();
		reports.migratedInstructions();
		
		//########## CUSTOMER SEARCH ################
				CustomerSearch customerSearch = new CustomerSearch(driver);
				customerSearch.findCustomer();
		
		System.out.println("Automation Script Finished Successfully");
		
	  }catch(Exception e){
		  System.out.println("###########There is some issue with the flow ############");
		  //Mailer.sendEmail();
		  System.out.println(e.getStackTrace());
	  }

	}
	
	public static String envFindString(){
		if(env.equalsIgnoreCase("SIT")){
			return "treeview-1241";
		}else if(env.equalsIgnoreCase("UAT")){
			return "treeview-1235";
		}
		return null;
	}
	
	@Test
	public void test() throws Exception{
		String exePath = "C:\\Software\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://espsit.intranet.barcapint.com/(S(detyvvbmfts0lmsaumyogql3))/default.aspx");
		Thread.sleep(5000);
		
		driver.findElement(By.id("pCustomerSearch_header")).click();
		
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id='userSearchFormControl_cmdSearchBy-inputCell']/../td[2]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//li[text()='CIF']")).click();

	}
	

}
