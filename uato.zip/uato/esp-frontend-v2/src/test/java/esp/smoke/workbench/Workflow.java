package esp.smoke.workbench;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import esp.smoke.Generic;

public class Workflow extends Generic{
	
	public Workflow(){
	}
	
	public Workflow(WebDriver driver){
		this.driver = driver;
	}
	
	public void myItems() throws InterruptedException{
		WebElement myItems = findElementbyId("-record-ext-record-33");
		myItems.click();
		System.out.println("Workflow - My Items Clicked");
		Thread.sleep(5000);
	}
	
	public void administration() throws InterruptedException{
		WebElement administration = findElementbyId("-record-ext-record-34");
		administration.click();
		System.out.println("Workflow - Administration Clicked");
		Thread.sleep(5000);
	}
	
	public void remediation() throws InterruptedException{
		WebElement remediation = findElementbyId("-record-ext-record-35");
		remediation.click();
		System.out.println("Workflow - Remediation Clicked");
		Thread.sleep(5000);
	}
	
	public void unclaimed() throws InterruptedException{
		WebElement unclaimed = findElementbyId("-record-ext-record-36");
		unclaimed.click();
		System.out.println("Workflow - Unclaimed Clicked");
		Thread.sleep(5000);
	}
}
