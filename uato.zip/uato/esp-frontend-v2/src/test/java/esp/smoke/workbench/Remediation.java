package esp.smoke.workbench;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import esp.smoke.Generic;

public class Remediation extends Generic{
	
	public Remediation(){
	}
	
	public Remediation(WebDriver driver){
		this.driver = driver;
	}
	
	public void administration() throws InterruptedException{
		WebElement administration = findElementbyId("-record-ext-record-17");
		administration.click();
		System.out.println("Remediation Administration Clicked");
		Thread.sleep(5000);
		captureScreenshot("RemediationAdministration");
	}
	
	public void availableItems() throws InterruptedException{
		WebElement avItems= findElementbyId("-record-ext-record-18");
		avItems.click();
		System.out.println("Remediation Available Items Clicked");
		Thread.sleep(5000);
		captureScreenshot("RemediationAvailableItems");
	}
	
	public void myItems() throws InterruptedException{
		WebElement myItems= findElementbyId("-record-ext-record-19");
		myItems.click();
		System.out.println("Remediation My Items Clicked");
		Thread.sleep(5000);
		captureScreenshot("RemediationMyItems");
	}
	
	public void projectItems() throws InterruptedException{
		WebElement projectItems= findElementbyId("-record-ext-record-20");
		projectItems.click();
		System.out.println("Remediation Project Items Clicked");
		Thread.sleep(5000);
	}
}
