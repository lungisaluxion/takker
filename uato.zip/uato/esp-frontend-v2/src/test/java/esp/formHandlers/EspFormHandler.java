package esp.formHandlers;

import org.apache.commons.io.FileUtils;

import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilities.*;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static esp.regression.EspTestDriver.*;
import static esp.regression.EspTestDriver.currentFolderName;
import static esp.regression.EspTestDriver.screenshotNames;
import static esp.regression.EspTestDriver.stepNo;
import static utilities.GenerateSAIDNumber.*;
import static utilities.HelperMethods.*;
import static utilities.HelperMethods.getScreenShot;
import static utilities.ReadTestData.fetchTestData;


public class EspFormHandler extends ObjectManager {
    LinkedHashMap testData;
    CommonUtil element;
    String reg_ID_Number;

    public static String getCurrentTimeStamp(String format) {
        SimpleDateFormat sdfDate = new SimpleDateFormat(format);
        Date now = new Date();
        return sdfDate.format(now);
    }

    public static void UploadDocument(WebDriver driver, String elementName, String description, String filePathAndToUpload) throws Exception {
        try {


            //WebDriverWait wait = new WebDriverWait(driver, 30); // Wait for 30 seconds.
            //wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(elementName)));
            WebElement elmn = driver.findElements(By.xpath(elementName)).get(0);
            elmn.sendKeys(filePathAndToUpload);
            // HtmlReporter.WriteStep(description, "Upload Document", "Document uploaded." , true );
        } catch (Exception e) {
            System.out.println("Exeption in WebDr.click - " + e);
            //HtmlReporter.WriteStep("Object not visible - " + description, "Upload Document", "Document uploaded." , false );
            throw new Exception("Failed");
        }

    }

    public void createInstruction(WebDriver driver) {
        element = new CommonUtil(driver);
        driver.switchTo().defaultContent();

        try {

            element.clickOnElement(OnBoardingInstruction);
            element.clickOnElement(WorkbenchMinimizeBtn);

            driver.switchTo().frame("pEspDefaultContent_IFrame");
            Thread.sleep(500);
            //element.clickOnElement(CreateInstruction);
            element.clickOnElement("xpath||//*[@id=\"DashboardUserControl_btnInstructions-btnInnerEl\"]");
            element.clickOnElement("xpath||//*[@id=\"DashboardUserControl_mnuCreate-textEl\"]");


        } catch (Exception e) {
            System.out.println(e.getMessage());
            screenshotNames = screenshotNames + ",fail" + failNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/fail" + (failNo++) + ".jpg");
        }

    }

    public void entitySelection(WebDriver driver, int id) throws Exception {

        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData","BasicClientInfo", id);


        if (testData.get("LegalEntityType").toString() != null && !testData.get("LegalEntityType").toString().isEmpty()) {
            Thread.sleep(100);
            element.waitForElement(driver, 15, lsLegalEnetityType).click();
            element.selectFromLi(testData.get("LegalEntityType").toString(), driver);
        }

        if (testData.get("LegalEntity").toString() != null && !testData.get("LegalEntity").toString().isEmpty()) {
            Thread.sleep(100);
            element.waitForElement(driver, 15, lsLegalEnetity).click();
            element.selectFromLi(testData.get("LegalEntity").toString(), driver);
        }
//CIB
//        if (testData.get("Primary Role").toString() != null && !testData.get("Primary Role").toString().isEmpty()) {
//            Thread.sleep(100);
//            element.waitForElement(driver, 15, lsPrimaryRole).click();
//            element.selectFromLi(testData.get("Primary Role").toString(), driver);
//        }


        reg_ID_Number = generateRegistrationID();
        String name = "";
        switch (testData.get("LegalEntity").toString()){
            case "Close Corporations":
                reg_ID_Number += "23";
                //reg_ID_Number = "199706008023";
                break;
            case "Co-Operatives":
                reg_ID_Number += "24";
                break;
            case "External Companies":
                reg_ID_Number += "10";
                break;
            case "South African Listed Companies":
                reg_ID_Number += "10";
                //reg_ID_Number = "196801571706";
                break;
            case "South African Companies":
                reg_ID_Number += "07";
                break;
            case "Trusts":
                name = "Automated"+reg_ID_Number+" Trust";
                break;
            case "Foreign Companies":
                name = "Foreign"+reg_ID_Number+" (PTY) LTD";
                break;
            case "Informal Bodies / Non-Profit Organisations (Not Registered With CIPC)":
                name = "NPO "+reg_ID_Number;
                break;
            case "Foreign Listed Companies":
                name = "Foreign"+reg_ID_Number+" LTD";
                break;


        }

        if (!testData.get("IDRegistrationNumber").toString().isEmpty() && testData.get("IDRegistrationNumber").toString() != null) {
            //reg_ID_Number = testData.get("IDRegistrationNumber").toString();
            element.typeOnElement(EntityIDOrRegistrationNumber, reg_ID_Number);
        }

        if (!testData.get("Name").toString().isEmpty() && testData.get("Name").toString() != null) {
            if(name.equals(""))
                name = testData.get("Name").toString();
            element.typeOnElement("xpath||//*[@id = 'ManageBasicControl_InitiationControl_txtName-inputEl']", name);

        }


        element.clickOnElement(searchClientButton);


        Thread.sleep(1000);
        if (existsElement(driver, txtSearchAddPartyResult)) {
            if (isElementVisible(driver, txtSearchAddPartyResult)) {
                element.clickOnElement("xpath||" + txtSearchAddPartyResult);
                element.clickOnElement(btnSearchExistingCustomerConfirm);
            }
        }
        element.clickOnElement("xpath||//*[text()='Session Expired. Please refresh your page to continue']/following::a");

     /* Thread.sleep(1000);
        selectObjectFrom_span_List(driver, lsInstructionSubType, "", testData.get("InstructionSubType").toString(), 1);
        Thread.sleep(1000);
        selectObjectFrom_li_List(driver, simplex, "", testData.get("Simplex").toString(), 1);*/

        if (testData.get("InstructionSubType").toString() != null && !testData.get("InstructionSubType").toString().isEmpty()) {
            Thread.sleep(100);
            element.waitForElement(driver, 15, lsInstructionSubType).click();
            driver.findElement(By.xpath("//span[text() = '" + testData.get("InstructionSubType") + "']")).click();
        }

        if (testData.get("Simplex").toString() != null && !testData.get("Simplex").toString().isEmpty()) {
            Thread.sleep(100);
            element.waitForElement(driver, 15, simplex).click();
            driver.findElement(By.xpath("//li[text() = '" + testData.get("Simplex") + "']")).click();
        }


        element.clickOnElement(lsInstructionCreateBtn);
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        element.clickOnElement("xpath||" + MinimizeWorkHistory);
        driver.switchTo().frame("pEspDefaultContent_IFrame");

        System.out.println();


    }

    public void entitySelection_v1(WebDriver driver, int id) throws Exception {

        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData","BasicClientInfo", id);

        selectObjectFrom_li_List(driver, lsLegalEnetityType, "", testData.get("LegalEntityType").toString(), 1);
        selectObjectFrom_li_List(driver, lsLegalEnetity, "", testData.get("LegalEntity").toString(), 1);

        /*if (testData.get("LegalEntity").toString().equalsIgnoreCase("Close Corporations"))
            reg_ID_Number = generateRegistrationID() + "23";*/

        reg_ID_Number = testData.get("IDRegistrationNumber").toString();
        element.typeOnElement(EntityIDOrRegistrationNumber, reg_ID_Number);

        element.clickOnElement(searchClientButton);

        Thread.sleep(1000);
        if (existsElement(driver, txtSearchAddPartyResult)) {
            if (isElementVisible(driver, txtSearchAddPartyResult)) {
                element.clickOnElement("xpath||" + txtSearchAddPartyResult);
                element.clickOnElement(btnSearchExistingCustomerConfirm);
            }
        }

        Thread.sleep(1000);
        selectObjectFrom_span_List(driver, lsInstructionSubType, "", testData.get("InstructionSubType").toString(), 1);
        Thread.sleep(1000);
        //element.typeOnElement(simplex,testData.get("Simplex").toString());
        selectObjectFrom_li_List(driver, simplex, "", testData.get("Simplex").toString(), 1);


        element.clickOnElement(lsInstructionCreateBtn);
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        element.clickOnElement("xpath||" + MinimizeWorkHistory);
        driver.switchTo().frame("pEspDefaultContent_IFrame");

        System.out.println();


    }

    public void editEntity(WebDriver driver, int id) throws Exception {

        element = new utilities.CommonUtil(driver);
        testData = fetchTestData("path_onboardingData","BasicClientInfo", id);

        driver.switchTo().defaultContent();
        try {

            element.clickOnElement(OnBoardingInstruction);
            element.clickOnElement("xpath||" + MinimizeWorkHistory);

            driver.switchTo().frame("pEspDefaultContent_IFrame");

            String icon = "//td[*[contains(text(),'" + testData.get("Instruction ID").toString() + "')]]/following-sibling::td//div[@cmd='Edit']";
            WebElement edit = driver.findElement(By.xpath(icon));

            Thread.sleep(500);

           /* try {
                element.clickOnElement("xpath//*[text() = 'Work History']/following :: div[contains(@class, 'x-tool-tool-el x-tool-img x-tool-collapse-right ')]");
            }catch (NoSuchElementException e)
            {
                e.printStackTrace();
            }*/

            //((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", edit);
            edit.click();

            driver.switchTo().defaultContent();
            Thread.sleep(1000);
            element.clickOnElement("xpath||" + MinimizeWorkHistory);
            driver.switchTo().frame("pEspDefaultContent_IFrame");
            try{
                element.clickOnElement("xpath||//*[text()='The entity CIPC status is not available. Would You like to continue with the instruction?']/following::span[text()='Yes']");
            }catch (Exception e){
                System.out.println("No CIPC popup");
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            screenshotNames = screenshotNames + ",fail" + failNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/fail" + (failNo++) + ".jpg");
        }
    }


    public void addRelatedParties(WebDriver driver) throws Exception {
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        String dataRowsAddEntity[] = driverSheet.get("AddRelatedParty").toString().split(",");

        String dataRowsClientDetailsRelated[] = driverSheet.get("ClientDetailsRelatedParty").toString().split(",");
        String dataRowsAddressDetailsRelatedParty[] = driverSheet.get("AddressDetailsRelatedParty").toString().split(",");
        String dataRowsContactDetailsRelatedParty[] = driverSheet.get("ContactDetailsRelatedParty").toString().split(",");

        int clientDetailsRelatedIterator = 0;

        element.clickOnElement("xpath||//span[text()='Strawman (Related)']");

        //Review popUp
        //if(existsElement(driver,"//*[@id='ManageBasicControl_RelatedTreeControl_btnRelatedPopUp-btnEl']")){
        //    element.clickOnElement("xpath||//*[@id='ManageBasicControl_RelatedTreeControl_btnRelatedPopUp-btnEl']");
        //}

        try {
            clickOverride(driver, By.xpath("//a[text() = 'Override Mandatory Services for Branch STP ( Click To Override)']"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        for (int i = 0; i < dataRowsAddEntity.length; i++) {
            testData = new HelperMethods().getTestData(espProperties.getProperty("path_onboardingData").toString(), "AddRelatedParty", Integer.parseInt(dataRowsAddEntity[i]));
            // rightClickOnObject(driver, testData.get("RelatedParty").toString());

            Actions actions = new Actions(driver);
            actions.contextClick(driver.findElement(By.xpath("//span[text() = '" + testData.get("RelatedParty").toString() + "']"))).build().perform();
            element.clickOnElement(BCI_AddEntityOrIndividual);

            Thread.sleep(700);
            //selectObjectFrom_li_List(driver, lsAddParty, "Legal Entity", testData.get("LegalEntity").toString(), 0);
            WebDriverWait wait = new WebDriverWait(driver, 60);
            WebElement elmn = driver.findElement(By.xpath(lsAddParty));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(lsAddParty)));
            WebElement DIVelement;
            elmn.click();

            screenshotNames = screenshotNames + "," + stepNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

            DIVelement = driver.findElement(By.xpath("//*[@id='ManageBasicControl_RelatedTreeControl_cmbLegalEntity-picker']/div/ul/li[text()='" + testData.get("LegalEntity").toString() + "']"));

            JavascriptExecutor jse = (JavascriptExecutor) driver;
            jse.executeScript("arguments[0].scrollIntoView(true)", DIVelement);
            driver.findElement(By.xpath("//*[@id='ManageBasicControl_RelatedTreeControl_cmbLegalEntity-picker']/div/ul/li[text()='" + testData.get("LegalEntity").toString() + "']")).click();
            screenshotNames = screenshotNames + "," + stepNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

            WebElement from = driver.findElement(By.xpath("//*[@id=\"ManageBasicControl_RelatedTreeControl_wndAddParty_header-title\"]"));

            actions.clickAndHold(from).build().perform();
            Thread.sleep(800);
            actions.release().build().perform();


            if (testData.get("IDRegNumber").toString() != null && !testData.get("IDRegNumber").toString().isEmpty()) {
                element.typeOnElement(II_IDOrReg, testData.get("IDRegNumber").toString());
            }

            if (testData.get("Name").toString() != null && !testData.get("Name").toString().isEmpty()) {
                element.typeOnElement(II_IDOrRegName, testData.get("Name").toString());
            }

            element.clickOnElement(btnSearchAddParty);

            if (existsElement(driver, txtSearchAddPartyResult)) {
                WebElement element = driver.findElements(By.xpath(txtSearchAddPartyResult)).get(driver.findElements(By.xpath(txtSearchAddPartyResult)).size() - 1);
                if (element.isDisplayed()) {
                    element.click();
                    element = driver.findElements(By.xpath(btnSearchAddPartyConfirm)).get(driver.findElements(By.xpath(btnSearchAddPartyConfirm)).size() - 1);
                    element.click();
                }
            }

            try{
                int clientDetailsID = Integer.parseInt(dataRowsClientDetailsRelated[clientDetailsRelatedIterator]);
                int addressDetailsID = Integer.parseInt(dataRowsAddressDetailsRelatedParty[clientDetailsRelatedIterator]);
                int contactDetailsID = Integer.parseInt(dataRowsContactDetailsRelatedParty[clientDetailsRelatedIterator++]);

                if(testData.get("RelatedParty").toString().equalsIgnoreCase("Shareholders / Controllers") &&( testData.get("LegalEntity").toString().equalsIgnoreCase("South African Companies")||testData.get("LegalEntity").toString().equalsIgnoreCase("Trusts"))){

                    element.clear("xpath||" + pnlRelatedFields + "//*[text()='Percentage ownership / control']/following :: input");
                    element.typeOnElement("xpath||" + pnlRelatedFields + "//*[text()='Percentage ownership / control']/following :: input", "100");
                    element.clickOnElement("xpath||" + ContactDetailsRalatedParty_SaveBtn);


                    if(testData.get("LegalEntity").toString().equalsIgnoreCase("South African Companies")){
                        rightClickOnObject(driver, "("+testData.get("IDRegNumber").toString()+")");
                    }
                    else {
                        rightClickOnObject(driver, ") "+testData.get("Name").toString()+" (");
                    }
                    element.clickOnElement(BCI_EditEntityOrIndividual);

                    Thread.sleep(500);
                    clientDetailsRelated_v1(driver, clientDetailsID);
                    addressDetailsRelatedParty_v1(driver, addressDetailsID);
                    contactDetailsRelatedParty(driver, contactDetailsID);

                }
                else if (testData.get("RelatedParty").toString().equalsIgnoreCase("Members / Controlers") || testData.get("RelatedParty").toString().equalsIgnoreCase("Shareholders / Controllers") || testData.get("RelatedParty").toString().equalsIgnoreCase("Sureties")) {
                    clientDetailsRelated_v1(driver, clientDetailsID);
                    addressDetailsRelatedParty_v1(driver, addressDetailsID);
                } else {
                    clientDetailsRelated_v1(driver, clientDetailsID);
                    addressDetailsRelatedParty_v1(driver, addressDetailsID);
                    contactDetailsRelatedParty(driver, contactDetailsID);
                }
            }catch (Exception e){
                System.out.println("No Data captured !!!");
            }finally {
                element.clickOnElement("xpath||" + ContactDetailsRalatedParty_SaveBtn);
                Thread.sleep(500);
            }


        }


//        if (isElementVisible(driver, COB_Screening_ConfirmMsg)) {
//            element.clickOnElement("xpath||" + COB_Screening_ConfirmMsg);
//        }
    }

    public void addRelatedParties_v2(WebDriver driver, int id)throws Exception{
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        testData = new HelperMethods().getTestData(espProperties.getProperty("path_onboardingData").toString(), "AddRelatedParty", id);
        element.clickOnElement("xpath||//span[text()='Strawman (Related)']");

        //Magic
        List<WebElement> entityTypes = driver.findElements(By.xpath("//div[@class=' x-tree-icon x-tree-icon-custom x-tree-icon-parent icon-bulletred']/../span"));

        if(entityTypes.size()<1)
            return;
        Actions actions = new Actions(driver);
        actions.contextClick(driver.findElement(By.xpath("//span[text() = '" + entityTypes.get(0).getText() + "']"))).build().perform();
        element.clickOnElement(BCI_AddEntityOrIndividual);

        Thread.sleep(700);
        //selectObjectFrom_li_List(driver, lsAddParty, "Legal Entity", testData.get("LegalEntity").toString(), 0);
        WebDriverWait wait = new WebDriverWait(driver, 60);
        WebElement elmn = driver.findElement(By.xpath(lsAddParty));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(lsAddParty)));
        WebElement DIVelement;
        elmn.click();

        screenshotNames = screenshotNames + "," + stepNo + ".jpg";
        getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

        DIVelement = driver.findElement(By.xpath("//*[@id='ManageBasicControl_RelatedTreeControl_cmbLegalEntity-picker']/div/ul/li[text()='" + testData.get("LegalEntity").toString() + "']"));

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("arguments[0].scrollIntoView(true)", DIVelement);
        driver.findElement(By.xpath("//*[@id='ManageBasicControl_RelatedTreeControl_cmbLegalEntity-picker']/div/ul/li[text()='" + testData.get("LegalEntity").toString() + "']")).click();
        screenshotNames = screenshotNames + "," + stepNo + ".jpg";
        getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

        WebElement from = driver.findElement(By.xpath("//*[@id=\"ManageBasicControl_RelatedTreeControl_wndAddParty_header-title\"]"));

        actions.clickAndHold(from).build().perform();
        Thread.sleep(800);
        actions.release().build().perform();
        for (int i=1;i<entityTypes.size();i++){
            element.clickOnElement("xpath||//div[text()='"+entityTypes.get(i).getText()+"']/../../td[1]");
        }

        if (testData.get("IDRegNumber").toString() != null && !testData.get("IDRegNumber").toString().isEmpty()) {
            element.typeOnElement(II_IDOrReg, testData.get("IDRegNumber").toString());
        }

        if (testData.get("Name").toString() != null && !testData.get("Name").toString().isEmpty()) {
            element.typeOnElement(II_IDOrRegName, testData.get("Name").toString());
        }

        element.clickOnElement(btnSearchAddParty);

        if (existsElement(driver, txtSearchAddPartyResult)) {
            WebElement element = driver.findElements(By.xpath(txtSearchAddPartyResult)).get(driver.findElements(By.xpath(txtSearchAddPartyResult)).size() - 1);
            if (element.isDisplayed()) {
                element.click();
                element = driver.findElements(By.xpath(btnSearchAddPartyConfirm)).get(driver.findElements(By.xpath(btnSearchAddPartyConfirm)).size() - 1);
                element.click();
            }
        }

        if(element.getText("xpath||//*[text()='Related party role']/../../../../../../div[3]/div/div/div/input").isEmpty()){
            element.typeOnElement("xpath||//*[text()='Related party role']/../../../../../../div[3]/div/div/div/input","DIRECTOR");
        }
        if(element.getText("xpath||//*[text()='Capacity']/../../../../../../div[3]/div/div/div/input").isEmpty()){
            element.typeOnElement("xpath||//*[text()='Capacity']/../../../../../../div[3]/div/div/div/input","DIRECTOR");
        }
        if(element.getText("xpath||//*[text()='Is this related party covered under the main resolution OR does this related party not need to be included in the main resolution']/../../../../../../div[3]/div/div/div/input").isEmpty()){
            element.typeOnElement("xpath||//*[text()='Is this related party covered under the main resolution OR does this related party not need to be included in the main resolution']/../../../../../../div[3]/div/div/div/input","NO");
        }



        element.clickOnElement("xpath||//*[@id='ManageBasicControl_RelatedTreeControl_ReqFieldsControl_btnSave']");

    }

    public void clientDetailsPrimary(WebDriver driver, int id) throws Exception {

        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData","ClientDetailsPrimaryParty", id);

        element.clickOnElement(BasicClientInformation);


        try {
            clickOverride(driver, By.xpath("//*[text()='Kofax OCR']"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (testData.get("Full name of client").toString() != null && !testData.get("Full name of client").toString().isEmpty()) {
            element.clear("xpath||" + II_FullNameOfClient);
            element.typeOnElement("xpath||" + II_FullNameOfClient, testData.get("Full name of client").toString());
        }

        if (testData.get("Client type").toString() != null && !testData.get("Client type").toString().isEmpty()) {
            List<WebElement> w = driver.findElements(By.xpath(II_ClientType));
            w.get(0).clear();
            w.get(0).sendKeys(testData.get("Client type").toString());
            w.get(0).sendKeys(Keys.ENTER);
        }

        if (testData.get("Trust / pension / provident / other fund number").toString() != null && !testData.get("Trust / pension / provident / other fund number").toString().isEmpty()) {
            element.clear("xpath||" + txtBoxTrustDeedNumber);
            element.typeOnElement("xpath||" + txtBoxTrustDeedNumber, testData.get("Trust / pension / provident / other fund number").toString());
        }

        if (testData.get("Date established").toString() != null && !testData.get("Date established").toString().isEmpty()) {
            element.clear("xpath||" + BCI_DateEstablished);
            element.typeOnElement("xpath||" + BCI_DateEstablished, testData.get("Date established").toString());
        }

        if (testData.get("Country of incorporation").toString() != null && !testData.get("Country of incorporation").toString().isEmpty()) {
            element.clear("xpath||" + lstSolePropCountryOfIncorporation);
            element.typeOnElement("xpath||" + lstSolePropCountryOfIncorporation, testData.get("Country of incorporation").toString());
        }

        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        element.clickOnElement("xpath||" + BCI_btnSave);

        Thread.sleep(1000);
        try {
            element.clickOnElement("xpath||" + MinimizeIssues);
            element.clickOnElement("xpath||" + MinimizeWorkHistory);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
//            if (isElementVisible(driver, COB_Screening_ConfirmMsg)) {
//                element.clickOnElement("xpath||" + COB_Screening_ConfirmMsg);
//            }

    }

    public void clientDetailsRelated(WebDriver driver, int id) throws Exception {

        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData","ClientDetailsRelatedParty", id);

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        driver.findElement(By.xpath(PIClientDetailsTab)).click();

        try {
            clickOverride(driver, By.xpath("//*[contains(text(), 'CPB / E4')]"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        try {
            clickOverride(driver, By.xpath("//*[contains(text(), 'Kofax OCR')]"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        try {
            clickOverride(driver, By.xpath("//*[contains(text(), 'Hanis')]"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }


        if (testData.get("Percentage ownership / control").toString() != null && !testData.get("Percentage ownership / control").toString().isEmpty()) {
            element.clear("xpath||" + txtBoxPercentage);
            element.typeOnElement("xpath||" + txtBoxPercentage, testData.get("Percentage ownership / control").toString());
        }

        if (testData.get("Title").toString() != null && !testData.get("Title").toString().isEmpty()) {
            element.clear("xpath||" + lstTitle);
            element.clickOnElement("xpath||" + lstTitle);
            driver.findElement(By.xpath("//li[(text() ='" + testData.get("Title").toString() + "')]")).click();
        }

        if (testData.get("First name(s)").toString() != null && !testData.get("First name(s)").toString().isEmpty()) {
            element.clear("xpath||" + txtBoxFirstName);
            element.clickOnElement("xpath||" + txtBoxFirstName);
            element.typeOnElement("xpath||" + txtBoxFirstName, testData.get("First name(s)").toString());
        }

        if (testData.get("Initials").toString() != null && !testData.get("Initials").toString().isEmpty()) {
            element.clear("xpath||" + txtBoxInitials);
            element.clickOnElement("xpath||" + txtBoxInitials);
            element.typeOnElement("xpath||" + txtBoxInitials, testData.get("Initials").toString().substring(0, 1));
        }

        if (testData.get("Surname").toString() != null && !testData.get("Surname").toString().isEmpty()) {
            element.clear("xpath||" + txtBoxSurname);
            element.clickOnElement("xpath||" + txtBoxSurname);
            element.typeOnElement("xpath||" + txtBoxSurname, testData.get("Surname").toString());
        }

        if (testData.get("Identification / passport number").toString() != null && !testData.get("Identification / passport number").toString().isEmpty()) {
            element.clear("xpath||" + txtBoxIDOrPassportNumber);
            element.clickOnElement("xpath||" + txtBoxIDOrPassportNumber);
            element.typeOnElement("xpath||" + txtBoxIDOrPassportNumber, testData.get("Identification / passport number").toString());
        }

        if (testData.get("ID type").toString() != null && !testData.get("ID type").toString().isEmpty()) {
            element.clear("xpath||" + pnlRelatedFields + txtBoxIDType);
            element.clickOnElement("xpath||" + pnlRelatedFields + txtBoxIDType);
            element.typeOnElement("xpath||" + pnlRelatedFields + txtBoxIDType, testData.get("ID type").toString());
        }

        if (testData.get("Date of birth").toString() != null && !testData.get("Date of birth").toString().isEmpty()) {
            element.clear("xpath||" + txtBoxDateOfBirth);
            element.clickOnElement("xpath||" + txtBoxDateOfBirth);
            element.typeOnElement("xpath||" + txtBoxDateOfBirth, testData.get("Date of birth").toString());
        }

        if (testData.get("Country of birth").toString() != null && !testData.get("Country of birth").toString().isEmpty()) {
            element.clear("xpath||" + lstCountryOfBirth);
            element.typeOnElement("xpath||" + lstCountryOfBirth, testData.get("Country of birth").toString());

        }


        if (testData.get("Nationality").toString() != null && !testData.get("Nationality").toString().isEmpty()) {
            element.waitForElement(driver, 15, lstNationality).click();
            element.selectFromLi(testData.get("Nationality").toString(), driver);
        }

        if (testData.get("Does the person have multiple nationalities").toString() != null && !testData.get("Does the person have multiple nationalities").toString().isEmpty()) {
            element.waitForElement(driver, 15, multipleNationalities).click();
            element.selectFromLi(testData.get("Does the person have multiple nationalities").toString(), driver);
        }


        if (testData.get("Gender").toString() != null && !testData.get("Gender").toString().isEmpty()) {
            element.waitForElement(driver, 15, Member_Gender).click();
            driver.findElement(By.xpath("//li[(text() ='" + testData.get("Gender").toString() + "')]")).click();
        }


        if (testData.get("Does this related party act in any other capacity other than that of a UBO and is a first level shareholder").toString() != null && !testData.get("Does this related party act in any other capacity other than that of a UBO and is a first level shareholder").toString().isEmpty()) {
            element.waitForElement(driver, 15, UBOFirstLevel).click();
            element.selectFromLi(testData.get("Does this related party act in any other capacity other than that of a UBO and is a first level shareholder").toString(), driver);
        }

        if (testData.get("Full name of client").toString() != null && !testData.get("Full name of client").toString().isEmpty()) {
            element.clear("xpath||" + pnlRelatedFields + II_FullNameOfClient);
            element.typeOnElement("xpath||" + pnlRelatedFields + II_FullNameOfClient, testData.get("Full name of client").toString());
        }

        if (testData.get("Client type").toString() != null && !testData.get("Client type").toString().isEmpty()) {
            List<WebElement> w = driver.findElements(By.xpath(pnlRelatedFields + II_ClientType));
            w.get(0).clear();
            w.get(0).sendKeys(testData.get("Client type").toString());
            w.get(0).sendKeys(Keys.ENTER);
        }

        if (testData.get("Trust / pension / provident / other fund number").toString() != null && !testData.get("Trust / pension / provident / other fund number").toString().isEmpty()) {
            element.clear("xpath||" + pnlRelatedFields + txtBoxTrustDeedNumber);
            element.typeOnElement("xpath||" + pnlRelatedFields + txtBoxTrustDeedNumber, testData.get("Trust / pension / provident / other fund number").toString());
        }

        if (testData.get("Date established").toString() != null && !testData.get("Date established").toString().isEmpty()) {
            element.clear("xpath||" + pnlRelatedFields + BCI_DateEstablished);
            element.typeOnElement("xpath||" + pnlRelatedFields + BCI_DateEstablished, testData.get("Date established").toString());
        }

        if (testData.get("Country of incorporation").toString() != null && !testData.get("Country of incorporation").toString().isEmpty()) {
            element.clear("xpath||" + pnlRelatedFields + lstSolePropCountryOfIncorporation);
            element.typeOnElement("xpath||" + pnlRelatedFields + lstSolePropCountryOfIncorporation, testData.get("Country of incorporation").toString());

            driver.findElement(By.xpath(pnlRelatedFields + lstSolePropCountryOfIncorporation)).sendKeys(Keys.ENTER);
        }

        if (testData.get("Compliance Attestation").toString().equalsIgnoreCase("YES")) {

            if (testData.get("Related party role").toString() != null && !testData.get("Related party role").toString().isEmpty()) {
                element.clear("xpath||" + pnlRelatedFields + PICD_RelatedPartyRole);
                element.typeOnElement("xpath||" + pnlRelatedFields + PICD_RelatedPartyRole, testData.get("Related party role").toString());
            }

            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

            if (testData.get("Capacity").toString() != null && !testData.get("Capacity").toString().isEmpty()) {
                element.clear("xpath||" + pnlRelatedFields + PICD_Capacity);
                element.typeOnElement("xpath||" + pnlRelatedFields + PICD_Capacity, testData.get("Capacity").toString());
            }
            if (testData.get("I can confirm that I have checked with the client and all of the trigger fields as recorded on the clients CIF are correct").toString() != null &&
                    !testData.get("I can confirm that I have checked with the client and all of the trigger fields as recorded on the clients CIF are correct").toString().isEmpty()) {
                element.clear("xpath||" + PICD_CIF);

                element.typeOnElement("xpath||" + PICD_CIF, testData.get("I can confirm that I have checked with the client and all of the trigger fields as recorded on the clients CIF are correct").toString());

                driver.findElement(By.xpath(PICD_CIF)).sendKeys(Keys.ENTER);
            }

            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

            if (testData.get("I can confirm that the current ID&V dates are later than the 29th of August 2009").toString() != null &&
                    !testData.get("I can confirm that the current ID&V dates are later than the 29th of August 2009").toString().isEmpty()) {
                element.clear("xpath||" + PICD_IDandV);

                element.typeOnElement("xpath||" + PICD_IDandV, testData.get("I can confirm that the current ID&V dates are later than the 29th of August 2009").toString());

                driver.findElement(By.xpath(PICD_IDandV)).sendKeys(Keys.ENTER);
            }

            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

            if (testData.get("can confirm that the client is not currently reported on the FIC Act control listing and that I have physically viewed (in 360) the documentation on file and it is compliant").toString() != null &&
                    !testData.get("can confirm that the client is not currently reported on the FIC Act control listing and that I have physically viewed (in 360) the documentation on file and it is compliant").toString().isEmpty()) {
                element.clear("xpath||" + PICD_FICAct);

                element.typeOnElement("xpath||" + PICD_FICAct, testData.get("can confirm that the client is not currently reported on the FIC Act control listing and that I have physically viewed (in 360) the documentation on file and it is compliant").toString());

                driver.findElement(By.xpath(PICD_FICAct)).sendKeys(Keys.ENTER);
            }

            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

            if (testData.get("Based on the latest UBO calculation rules, this related party and the other related parties to the primary client have been captured correctly").toString() != null &&
                    !testData.get("Based on the latest UBO calculation rules, this related party and the other related parties to the primary client have been captured correctly").toString().isEmpty()) {
                element.clear("xpath||" + CA_confirmUBORules);

                element.typeOnElement("xpath||" + CA_confirmUBORules, testData.get("Based on the latest UBO calculation rules, this related party and the other related parties to the primary client have been captured correctly").toString());

                driver.findElement(By.xpath(CA_confirmUBORules)).sendKeys(Keys.ENTER);
            }

            if (testData.get("I can confirm that the client has active accounts with us").toString() != null &&
                    !testData.get("I can confirm that the client has active accounts with us").toString().isEmpty()) {
                element.clear("xpath||" + CA_confirmActiveAccount);

                element.typeOnElement("xpath||" + CA_confirmActiveAccount, testData.get("I can confirm that the client has active accounts with us").toString());

                driver.findElement(By.xpath(CA_confirmActiveAccount)).sendKeys(Keys.ENTER);
            }

            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

            if (testData.get("Is this related party covered under the main resolution OR does this related party not need to be included in the main resolution").toString() != null &&
                    !testData.get("Is this related party covered under the main resolution OR does this related party not need to be included in the main resolution").toString().isEmpty()) {
                element.clear("xpath||" + POA_ProofOfAuthority);

                element.typeOnElement("xpath||" + POA_ProofOfAuthority, testData.get("Is this related party covered under the main resolution OR does this related party not need to be included in the main resolution").toString());

                driver.findElement(By.xpath(POA_ProofOfAuthority)).sendKeys(Keys.ENTER);
            }
        }

        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

    }

    public void addressDetailsRelatedParty(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData","AddressDetailsRelatedParty", id);

        driver.findElement(By.xpath(AddressDetailsHeader)).click();


        try {
            //Business Address
            element.clear("xpath||" + BusinessAddress_AddressLine1);
            element.typeOnElement("xpath||" + BusinessAddress_AddressLine1, testData.get("Business Address line 1").toString());
            element.clear("xpath||" + BusinessAddress_AddressLine2);
            element.typeOnElement("xpath||" + BusinessAddress_AddressLine2, testData.get("Business Address line 2").toString());
            element.clear("xpath||" + BusinessAddress_Suburb);
            element.typeOnElement("xpath||" + BusinessAddress_Suburb, testData.get("Business Suburb").toString());
            element.clear("xpath||" + BusinessAddress_Town);
            element.typeOnElement("xpath||" + BusinessAddress_Town, testData.get("Business Town").toString());
            element.clear("xpath||" + BusinessAddress_PostalCode);
            element.typeOnElement("xpath||" + BusinessAddress_PostalCode, testData.get("Business Postal code").toString());
            if (testData.get("Copy Address").toString().equalsIgnoreCase("Yes")) {
                int i = 0;
                while (!driver.findElements(By.xpath("//*[contains(text(),' Address')]/following::span[@class='x-btn-inner x-btn-inner-center']/../..")).get(i).isDisplayed())
                    i++;
                driver.findElements(By.xpath("//*[contains(text(),' Address')]/following::span[@class='x-btn-inner x-btn-inner-center']/../..")).get(i).click();

                int size = driver.findElements(By.xpath(BusinessAdress_CopyInformationSelection)).size();

                for (int j = 0; j < size; j++) {
                    driver.findElements(By.xpath(BusinessAdress_CopyInformationSelection)).get(0).click();
                }

                element.clickOnElement(BusinessAddress_CopyInformationOKbtn);

            }

            element.clickOnElement(AddressDetailsRelatedParty_SaveBtn);

            // Thread.sleep(1000);

            Thread.sleep(1000);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    public void addressDetailsRelatedParty_v1(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_onboardingData").toString(), "AddressDetailsRelatedParty", id);


        driver.findElement(By.xpath(AddressDetailsHeader)).click();
        populateData_v2(driver, testData);

    }


    public void contactDetailsRelatedParty(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        driver.findElement(By.xpath(PI_tbContactDetails)).click();

        //populate(driver, "ContactDetailsRelatedParty", id);

        testData = fetchTestData("path_onboardingData","ContactDetailsRelatedParty", id);

        Iterator<Map.Entry<String, String>> iterator = testData.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<String, String> entry = iterator.next();
            String key, value, path;

            if (entry.getValue() != null && !entry.getValue().isEmpty()) {
                key = entry.getKey();
                value = entry.getValue();

                if (key.equalsIgnoreCase("ID") || key.equalsIgnoreCase("Description")) {
                    continue;
                }

                try {
                    key = entry.getKey().substring(0, 90);
                } catch (Exception e) {
                    key = entry.getKey();
                }
                if (key.contains("'")) {
                    key = key.substring(key.indexOf('\'') + 1, key.length() - 1);
                }

                WebElement e = driver.findElement(By.xpath("//*[text()='" + key + "']/following :: div[contains(@id, 'triggerWrap')]"));


                if (e.getAttribute("id").contains("combo")) {
                    path = "//*[text()='" + key + "']/following::div[contains(@class,'x-form-arrow-trigger')]";
                    element.waitForElement(driver, 4, path).click();
                    element.selectFromLi(value, driver);

                } else if (e.getAttribute("id").contains("textareafield")) {
                    path = "//*[text()='" + key + "']/following:: textarea";
                    element.clear("xpath||" + path);
                    element.typeOnElement("xpath||" + path, value);

                } else {
                    path = "//*[text()='" + key + "']/following:: input";
                    element.clear("xpath||" + path);
                    element.typeOnElement("xpath||" + path, value);
                }
            }


        }







    }

    public void addressDetailsPrimary(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData","DetailedClientAddressPrimary", id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Client Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'2. Address Details')]");
        try {
            clickOverride(driver, By.xpath("//*[text()='Kofax OCR']"));
        } catch (Exception e) {
            System.out.println("No override");
        }

        try {
            //Business Address
            element.clear("xpath||" + AddressLine1);
            element.typeOnElement("xpath||" + AddressLine1, testData.get("Address line 1").toString());
            element.clear("xpath||" + AddressLine2);
            element.typeOnElement("xpath||" + AddressLine2, testData.get("Address line 2").toString());
            element.clear("xpath||" + Suburb);
            element.typeOnElement("xpath||" + Suburb, testData.get("Suburb").toString());
            element.clear("xpath||" + Town);
            element.typeOnElement("xpath||" + Town, testData.get("Town").toString());
            element.clear("xpath||" + PostalCode);
            element.typeOnElement("xpath||" + PostalCode, testData.get("Postal code").toString());

            driver.findElements(By.xpath("//*[contains(text(),'Business Address')]/following::span[@class='x-btn-inner x-btn-inner-center']/../..")).get(0).click();
            driver.findElements(By.xpath(BusinessAdress_CopyInformationSelection)).get(0).click();
            Thread.sleep(1000);
            driver.findElements(By.xpath(BusinessAdress_CopyInformationSelection)).get(0).click();
            Thread.sleep(1000);
            driver.findElements(By.xpath(BusinessAdress_CopyInformationSelection)).get(0).click();
            element.clickOnElement("xpath||" + copyInformation_OkBtn);

            //TODO take a screenshot before save
            screenshotNames = screenshotNames + "," + stepNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

            Thread.sleep(1000);
            //TODO take a screenshot after save

            screenshotNames = screenshotNames + "," + stepNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");


        } catch (Exception e) {
            System.out.println(e.getMessage());
            screenshotNames = screenshotNames + ",fail" + failNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/fail" + (failNo++) + ".jpg");
        }


    }

    public void addressDetailsPrimary_v1(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_onboardingData").toString(), "DetailedClientAddressPrimary", id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Client Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'2. Address Details')]");

/*        try {
            clickOverride(driver, By.xpath("//a[text() = 'Override Mandatory Services for Branch STP ( Click To Override)']"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } */
        element.clickOnElement("xpath||//span[contains(text(),'2. Address Details')]");

        populateData(driver, testData);

    }

    public void contactDetailsPrimary_v1(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_onboardingData").toString(), "DetailedClientContactPrimary", id);


        element.clickOnElement(DCI);
        element.clickOnElement("xpath||//span[contains(text(),'3. Contact Details')]");

/*        try {
            clickOverride(driver, By.xpath("//a[text() = 'Override Mandatory Services for Branch STP ( Click To Override)']"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
*/
        Iterator<Map.Entry<String, Map<String, Map<String, String>>>> iterator = testData.entrySet().iterator();
        while (iterator.hasNext()) {

            String key, value, path;
            Map.Entry<String, Map<String, Map<String, String>>> entry1 = iterator.next();

            for (Map.Entry<String, Map<String, String>> entry2 : entry1.getValue().entrySet()) {
                for (Map.Entry<String, String> entry3 : entry2.getValue().entrySet()) {

                    if (entry3.getValue() != null && !entry3.getValue().isEmpty()) {
                        key = entry3.getKey();
                        value = entry3.getValue();

                        switch (key) {
                            case "ID":
                                continue;
                            case "Description":
                                continue;
                            case "Telephone number dialling code":
                                System.out.println("");
                                break;
                        }


                      /* if (key.contains("'")) {
                            key = key.replace("\'", "\''");
                        }
*/
                        WebElement e = driver.findElement(By.xpath("//*[text() = '" + entry2.getKey() + "']/following :: *[text() = \"" + key + "\"]/following :: div[contains(@id, 'triggerWrap')]"));


                        if (e.getAttribute("id").contains("combo")) {
                            path = "//*[text() = '" + entry2.getKey() + "']/following :: *[text() = \"" +key+"\"]/following :: div[contains(@class, 'x-form-arrow-trigger')]";
                            element.waitForElement(driver, 10, path).click();
                            element.selectFromLi(value, driver);

                        } else if (e.getAttribute("id").contains("textareafield")) {
                            path = "//*[text() = '" + entry2.getKey() + "']/following :: *[text() = \"" +key+ "\" ]/following :: textarea";
                            element.clear("xpath||" + path);
                            element.typeOnElement("xpath||" + path, value);

                        } else {
                            path = "//*[text() = '" + entry2.getKey() + "']/following :: *[text() = \"" +key+ "\"]/following :: input";
                            element.clear("xpath||" + path);
                            element.typeOnElement("xpath||" + path, value);
                        }


                        System.out.println(entry2.getKey() + "   >>>>>>>    " + key + "   >>>>>>>    " + value);


                    }


                }
            }

        }






    }



    public void contactDetailsPrimary(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData","DetailedClientContactPrimary", id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Client Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'3. Contact Details')]");
        try {
            clickOverride(driver, By.xpath("//a[text() = 'Override Mandatory Services for Branch STP ( Click To Override)']"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        // try {
        if (!testData.get("Preferred language").toString().isEmpty() && testData.get("Preferred language") != null) {
            element.clear("xpath||" + COB_CD_PreferredLanguage1);
            element.typeOnElement("xpath||" + COB_CD_PreferredLanguage1, testData.get("Preferred language").toString());
        }
        if (!testData.get("Preferred contact method").toString().isEmpty() && testData.get("Preferred contact method") != null) {
            element.clear("xpath||" + COB_CD_PreferredContactMethod1);
            element.typeOnElement("xpath||" + COB_CD_PreferredContactMethod1, testData.get("Preferred contact method").toString());
        }
        if (!testData.get("Marketing Consent").toString().isEmpty() && testData.get("Marketing Consent") != null) {
            element.clear("xpath||" + COB_CD_MarketingConsent);
            element.typeOnElement("xpath||" + COB_CD_MarketingConsent, testData.get("Marketing Consent").toString());
        }

        if (!testData.get("What is Client's preferred method for delivery of Legal Notices?").toString().isEmpty() && testData.get("What is Client's preferred method for delivery of Legal Notices?") != null) {
            element.clear("xpath||" + COB_CD_DeliveryOfLigalNotice1);
            element.typeOnElement("xpath||" + COB_CD_DeliveryOfLigalNotice1, testData.get("What is Client's preferred method for delivery of Legal Notices?").toString());
        }
        if (!testData.get("Does the Client prefer to sign document(s) electronically?").toString().isEmpty() && testData.get("Does the Client prefer to sign document(s) electronically?") != null) {
            element.clear("xpath||" + COB_CD_SignDocsElectronically);
            element.typeOnElement("xpath||" + COB_CD_SignDocsElectronically, testData.get("Does the Client prefer to sign document(s) electronically?").toString());
        }
        if (!testData.get("Credit Worthiness Consent").toString().isEmpty() && testData.get("Credit Worthiness Consent") != null) {
            element.clear("xpath||" + COB_CD_CreditWorthinessConsent1);
            element.typeOnElement("xpath||" + COB_CD_CreditWorthinessConsent1, testData.get("Credit Worthiness Consent").toString());
        }
        if (!testData.get("Telemarketing").toString().isEmpty() && testData.get("Telemarketing") != null) {
            element.clear("xpath||" + COB_CD_Telemarketing);
            element.typeOnElement("xpath||" + COB_CD_Telemarketing, testData.get("Telemarketing").toString());
        }
        if (!testData.get("Mass Distribution").toString().isEmpty() && testData.get("Mass Distribution") != null) {
            element.clear("xpath||" + COB_CD_MassDistribution);
            element.typeOnElement("xpath||" + COB_CD_MassDistribution, testData.get("Mass Distribution").toString());
        }
        if (!testData.get("Email address").toString().isEmpty() && testData.get("Email address") != null) {
            element.clear("xpath||" + COB_CD_EmailConsent);
            element.typeOnElement("xpath||" + COB_CD_EmailConsent, testData.get("Email address").toString());
        }

        if (!testData.get("Telephone consent").toString().isEmpty() && testData.get("Telephone consent") != null) {
            element.clear("xpath||" + COB_CD_TelephoneConsent);
            element.typeOnElement("xpath||" + COB_CD_TelephoneConsent, testData.get("Telephone consent").toString());
        }
        if (!testData.get("SMS consent").toString().isEmpty() && testData.get("SMS consent") != null) {
            element.clear("xpath||" + COB_CD_SMSConsent);
            element.typeOnElement("xpath||" + COB_CD_SMSConsent, testData.get("SMS consent").toString());
        }
        if (!testData.get("Post consent").toString().isEmpty() && testData.get("Post consent") != null) {
            element.clear("xpath||" + COB_CD_PostConsent);
            element.typeOnElement("xpath||" + COB_CD_PostConsent, testData.get("Post consent").toString());
        }

        screenshotNames = screenshotNames + "," + stepNo + ".jpg";
        getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

        if (!testData.get("Full name and surname").toString().isEmpty() && testData.get("Full name and surname") != null) {
            element.clear("xpath||" + COB_CD_FullNameAndSurname);
            element.typeOnElement("xpath||" + COB_CD_FullNameAndSurname, testData.get("Full name and surname").toString());
        }
        if (!testData.get("Designation").toString().isEmpty() && testData.get("Designation") != null) {
            element.clear("xpath||" + COB_CD_Designation);
            element.typeOnElement("xpath||" + COB_CD_Designation, testData.get("Designation").toString());
        }
        if (!testData.get("Which contact details will you be supplying").toString().isEmpty() && testData.get("Which contact details will you be supplying") != null) {
            element.clear("xpath||" + COB_CD_ContactDetailsToSupplying);
            element.typeOnElement("xpath||" + COB_CD_ContactDetailsToSupplying, testData.get("Which contact details will you be supplying").toString());
        }
        if (!testData.get("Fax number dialling code").toString().isEmpty() && testData.get("Fax number dialling code") != null) {
            element.clear("xpath||" + COB_CD_FaxNumberDiallingCode);
            element.typeOnElement("xpath||" + COB_CD_FaxNumberDiallingCode, testData.get("Fax number dialling code").toString());
        }
        if (!testData.get("Fax number").toString().isEmpty() && testData.get("Fax number") != null) {
            element.clear("xpath||" + COB_CD_FaxNumber);
            element.typeOnElement("xpath||" + COB_CD_FaxNumber, testData.get("Fax number").toString());
        }
        if (!testData.get("Email address").toString().isEmpty() && testData.get("Email address") != null) {
            element.clear("xpath||" + COB_CD_EmailAddress);
            element.typeOnElement("xpath||" + COB_CD_EmailAddress, testData.get("Email address").toString());
        }
        if (!testData.get("Website").toString().isEmpty() && testData.get("Website") != null) {
            element.clear("xpath||" + COB_CD_Website);
            element.typeOnElement("xpath||" + COB_CD_Website, testData.get("Website").toString());
        }
        if (!testData.get("Cell phone number").toString().isEmpty() && testData.get("Cell phone number") != null) {
            element.clear("xpath||" + COB_CD_CellPhoneNumber);
            element.typeOnElement("xpath||" + COB_CD_CellPhoneNumber, testData.get("Cell phone number").toString());
        }
        if (!testData.get("Telephone number dialling code").toString().isEmpty() && testData.get("Telephone number dialling code") != null) {
            element.clear("xpath||" + COB_CD_TelephoneNumberDiallingCode);
            element.typeOnElement("xpath||" + COB_CD_TelephoneNumberDiallingCode, testData.get("Telephone number dialling code").toString());
        }
        if (!testData.get("Telephone number").toString().isEmpty() && testData.get("Telephone number") != null) {
            element.clear("xpath||" + COB_CD_TelephoneNumber);
            element.typeOnElement("xpath||" + COB_CD_TelephoneNumber, testData.get("Telephone number").toString());
        }


        screenshotNames = screenshotNames + "," + stepNo + ".jpg";
        getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");

        element.clickOnElement("xpath||" + BCI_btnSave);
        /*} catch (Exception e) {
            System.out.println(e.getMessage());
            screenshotNames = screenshotNames + ",fail" + failNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/fail" + (failNo++) + ".jpg");
        }*/


    }

    public void regulatoryPrimary(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Client Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'4. Regulatory')]");
        try {
            clickOverride(driver, By.xpath("//*[text()='Kofax OCR']"));
        } catch (Exception e) {
            System.out.println("No override");
        }
        testData = new HelperMethods().getTestData(espProperties.getProperty("path_onboardingData").toString(), "DetailedClientRegulatory", id);

        //try {
        //
        String path, key;
        if (!testData.get("Is the entity registered outside RSA, and operating inside RSA").toString().isEmpty() && testData.get("Is the entity registered outside RSA, and operating inside RSA") != null) {
            element.clear("xpath||" + COB_Regulatory_OperatingInOrOutSA);
            element.typeOnElement("xpath||" + COB_Regulatory_OperatingInOrOutSA, testData.get("Is the entity registered outside RSA, and operating inside RSA").toString());
        }
        if (!testData.get("Are 75% or more of the capital, assets or earning used for payment to or for the benefit of a temporary or non-resident").toString().isEmpty() && testData.get("Are 75% or more of the capital, assets or earning used for payment to or for the benefit of a temporary or non-resident") != null) {
            element.clear("xpath||" + COB_Regulatory_BenefitOfTempOrNonRes);
            element.typeOnElement("xpath||" + COB_Regulatory_BenefitOfTempOrNonRes, testData.get("Are 75% or more of the capital, assets or earning used for payment to or for the benefit of a temporary or non-resident").toString());
        }
        if (!testData.get("Are 75% or more of the voting rights or voting power controlled by a temporary or non-resident").toString().isEmpty() && testData.get("Are 75% or more of the voting rights or voting power controlled by a temporary or non-resident") != null) {
            element.clear("xpath||" + COB_Regulatory_75PercentVotingPowerTempOrNonRes);
            element.typeOnElement("xpath||" + COB_Regulatory_75PercentVotingPowerTempOrNonRes, testData.get("Are 75% or more of the voting rights or voting power controlled by a temporary or non-resident").toString());
        }
        if (!testData.get("Are there any temporary resident or non-resident shareholders who combined shareholding is more than 75%").toString().isEmpty() && testData.get("Are there any temporary resident or non-resident shareholders who combined shareholding is more than 75%") != null) {
            element.clear("xpath||" + COB_Regulatory_CombinedShareHolder75Percent);
            element.typeOnElement("xpath||" + COB_Regulatory_CombinedShareHolder75Percent, testData.get("Are there any temporary resident or non-resident shareholders who combined shareholding is more than 75%").toString());
        }

        //Sanctions
        if (!testData.get("Does the client relationship involve a connection to a government agency or government that is sanctioned").toString().isEmpty() && testData.get("Does the client relationship involve a connection to a government agency or government that is sanctioned") != null) {
            element.clear("xpath||" + COB_Regulatory_AgencyOrGovSanctioned);
            element.typeOnElement("xpath||" + COB_Regulatory_AgencyOrGovSanctioned, testData.get("Does the client relationship involve a connection to a government agency or government that is sanctioned").toString());
        }
            /*if (!testData.get("Please provide additional details if you answered YES to the above question").toString().isEmpty() && testData.get("Please provide additional details if you answered YES to the above question") != null)
            {
                element.clear("xpath||"+lstIsClientNonResident);
                element.typeOnElement("xpath||"+lstIsClientNonResident,testData.get("Please provide additional details if you answered YES to the above question").toString());
            }*/
        if (!testData.get("Does the client's business activity involve US - Origin goods, services or technology").toString().isEmpty() && testData.get("Does the client's business activity involve US - Origin goods, services or technology") != null) {
            element.clear("xpath||" + COB_Regulatory_ActivityInvolveUS);
            element.typeOnElement("xpath||" + COB_Regulatory_ActivityInvolveUS, testData.get("Does the client's business activity involve US - Origin goods, services or technology").toString());
        }
        if (!testData.get("Does the Client deal in conflict diamonds").toString().isEmpty() && testData.get("Does the Client deal in conflict diamonds") != null) {
            element.clear("xpath||" + COB_Regulatory_ClientDealInConflictDiamond);
            element.typeOnElement("xpath||" + COB_Regulatory_ClientDealInConflictDiamond, testData.get("Does the Client deal in conflict diamonds").toString());
        }
        if (!testData.get("Is the Client affiliated to any sanctioned persons (Legal or Natural) or sanctioned countries").toString().isEmpty() && testData.get("Is the Client affiliated to any sanctioned persons (Legal or Natural) or sanctioned countries") != null) {
            element.clear("xpath||" + COB_Regulatory_ClientAffiliatedToSacntionPerson);
            element.typeOnElement("xpath||" + COB_Regulatory_ClientAffiliatedToSacntionPerson, testData.get("Is the Client affiliated to any sanctioned persons (Legal or Natural) or sanctioned countries").toString());
        }
        if (!testData.get("Is Revenue Turnover generated from the sanctioned person").toString().isEmpty() && testData.get("Is Revenue Turnover generated from the sanctioned person") != null) {
            element.clear("xpath||" + COB_Regulatory_TurnoverFromSanctionedPerson);
            element.typeOnElement("xpath||" + COB_Regulatory_TurnoverFromSanctionedPerson, testData.get("Is Revenue Turnover generated from the sanctioned person").toString());
        }
        if (!testData.get("Is Revenue Turnover generated from the sanctioned country").toString().isEmpty() && testData.get("Is Revenue Turnover generated from the sanctioned country") != null) {
            element.clear("xpath||" + COB_Regulatory_TurnoverFromSanctionedCountry);
            element.typeOnElement("xpath||" + COB_Regulatory_TurnoverFromSanctionedCountry, testData.get("Is Revenue Turnover generated from the sanctioned country").toString());
        }
        if (!testData.get("Does the Client deal in unlicensed Iraqi cultural property").toString().isEmpty() && testData.get("Does the Client deal in unlicensed Iraqi cultural property") != null) {
            element.clear("xpath||" + COB_Regulatory_DealInUnlicensedIraqiCulture);
            element.typeOnElement("xpath||" + COB_Regulatory_DealInUnlicensedIraqiCulture, testData.get("Does the Client deal in unlicensed Iraqi cultural property").toString());
        }
        if (!testData.get("Is the client or any of its beneficial owners operating in any one of the sanctioned countries").toString().isEmpty() && testData.get("Is the client or any of its beneficial owners operating in any one of the sanctioned countries") != null) {
            element.clear("xpath||" + COB_Regulatory_OwnerOperatingSactionedCountries);
            element.typeOnElement("xpath||" + COB_Regulatory_OwnerOperatingSactionedCountries, testData.get("Is the client or any of its beneficial owners operating in any one of the sanctioned countries").toString());
        }
        if (!testData.get("Does more than 10% of assets, sales, turnover, profit or revenue emanate from a sanctioned person/s or alternatively from a sanctioned country/ies").toString().isEmpty() && testData.get("Does more than 10% of assets, sales, turnover, profit or revenue emanate from a sanctioned person/s or alternatively from a sanctioned country/ies") != null) {
            element.clear("xpath||" + COB_Regulatory_MoreThan10PercentAssets);
            element.typeOnElement("xpath||" + COB_Regulatory_MoreThan10PercentAssets, testData.get("Does more than 10% of assets, sales, turnover, profit or revenue emanate from a sanctioned person/s or alternatively from a sanctioned country/ies").toString());
        }
        if (!testData.get("Does the client relationship involve a connection to the sale of military goods or technology or dual use goods or technology, or any breach of export controls to and from any trade embargoed destinations").toString().isEmpty() && testData.get("Does the client relationship involve a connection to the sale of military goods or technology or dual use goods or technology, or any breach of export controls to and from any trade embargoed destinations") != null) {
            element.clear("xpath||" + COB_Regulatory_MilitaryGoods);
            element.typeOnElement("xpath||" + COB_Regulatory_MilitaryGoods, testData.get("Does the client relationship involve a connection to the sale of military goods or technology or dual use goods or technology, or any breach of export controls to and from any trade embargoed destinations").toString());
            driver.findElement(By.xpath(COB_Regulatory_MilitaryGoods)).sendKeys(Keys.TAB);
        }
            /*if (!testData.get("Please provide additional details if you answered YES to the above question").toString().isEmpty() && testData.get("Please provide additional details if you answered YES to the above question") != null)
            {
                element.clear("xpath||"+lstIsClientNonResident);
                element.typeOnElement("xpath||"+lstIsClientNonResident,testData.get("Please provide additional details if you answered YES to the above question").toString());
            }*/

        //Risk Indicators
        if (!testData.get("Is the client involved in any of these high risk industries").toString().isEmpty() && testData.get("Is the client involved in any of these high risk industries") != null) {
            element.clear("xpath||" + COB_Regulatory_ClientInHighRiskIndustry);
            element.typeOnElement("xpath||" + COB_Regulatory_ClientInHighRiskIndustry, testData.get("Is the client involved in any of these high risk industries").toString());
        }
        if (!testData.get("Is the client a casino or involved in gambling activities").toString().isEmpty() && testData.get("Is the client a casino or involved in gambling activities") != null) {
            element.clear("xpath||" + COB_Regulatory_ClientInvolveInGambling);
            element.typeOnElement("xpath||" + COB_Regulatory_ClientInvolveInGambling, testData.get("Is the client a casino or involved in gambling activities").toString());
        }
        if (!testData.get("During any client engagements did you note any suspicious activities").toString().isEmpty() && testData.get("During any client engagements did you note any suspicious activities") != null) {
            element.clear("xpath||" + COB_Regulatory_ClientEngagementInAnySuspiciousActivity);
            element.typeOnElement("xpath||" + COB_Regulatory_ClientEngagementInAnySuspiciousActivity, testData.get("During any client engagements did you note any suspicious activities").toString());
        }/*if (!testData.get("Comments on suspicious activities noticed").toString().isEmpty() && testData.get("Comments on suspicious activities noticed") != null)
            {
                element.clear("xpath||"+COB_Regulatory_ClientDealInConflictDiamond);
                element.typeOnElement("xpath||"+COB_Regulatory_ClientDealInConflictDiamond,testData.get("Comments on suspicious activities noticed").toString());
            }*/
        if (!testData.get("Does the Client deal in conflict diamonds").toString().isEmpty() && testData.get("Does the Client deal in conflict diamonds") != null) {
            element.clear("xpath||" + COB_Regulatory_ClientDealInConflictDiamond);
            element.typeOnElement("xpath||" + COB_Regulatory_ClientDealInConflictDiamond, testData.get("Does the Client deal in conflict diamonds").toString());
        }
        if (!testData.get("Will the bank take electronic or manual instructions from a 3rd party on behalf of client").toString().isEmpty() && testData.get("Will the bank take electronic or manual instructions from a 3rd party on behalf of client") != null) {
            element.clear("xpath||" + COB_Regulatory_BankTakeElecOrManualInstructFrom3rdParty);
            element.typeOnElement("xpath||" + COB_Regulatory_BankTakeElecOrManualInstructFrom3rdParty, testData.get("Will the bank take electronic or manual instructions from a 3rd party on behalf of client").toString());
        }
        if (!testData.get("Manner in which the client relationship is established").toString().isEmpty() && testData.get("Manner in which the client relationship is established") != null) {
            element.clear("xpath||" + COB_Regulatory_MannerInWhichClientRelationshipEstablished);
            element.typeOnElement("xpath||" + COB_Regulatory_MannerInWhichClientRelationshipEstablished, testData.get("Manner in which the client relationship is established").toString());
            // driver.findElement(By.xpath(COB_Regulatory_MannerInWhichClientRelationshipEstablished)).sendKeys(Keys.TAB);
        }
        if (!testData.get("Does the customer hold a Trade Finance account").toString().isEmpty() && testData.get("Does the customer hold a Trade Finance account") != null) {
            element.clear("xpath||" + COB_Regulatory_DoesTheCustomerHoldATradeFinanceAccount);
            element.typeOnElement("xpath||" + COB_Regulatory_DoesTheCustomerHoldATradeFinanceAccount, testData.get("Does the customer hold a Trade Finance account").toString());
        }
        if (!testData.get("Is this client a shell bank").toString().isEmpty() && testData.get("Is this client a shell bank") != null) {
            element.clear("xpath||" + COB_Regulatory_ClientShellBank);
            element.typeOnElement("xpath||" + COB_Regulatory_ClientShellBank, testData.get("Is this client a shell bank").toString());

        }
        if (!testData.get("Are any related parties to this client a shell bank").toString().isEmpty() && testData.get("Are any related parties to this client a shell bank") != null) {
            element.clear("xpath||" + COB_Regulatory_AnyRelatedPartiesToThisClientAShellBank);
            element.typeOnElement("xpath||" + COB_Regulatory_AnyRelatedPartiesToThisClientAShellBank, testData.get("Are any related parties to this client a shell bank").toString());
        }
        //TODO 'Purpose of account and Expected acc activity
        key = "Purpose of account / relationship";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Expected account activity";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        if (!testData.get("Do the ownership percentages captured on the organogram add up to 100% on each level").toString().isEmpty() && testData.get("Do the ownership percentages captured on the organogram add up to 100% on each level") != null) {
            element.clear("xpath||" + COB_Regulatory_OwnershipCapturedAddUp100Perc);
            element.typeOnElement("xpath||" + COB_Regulatory_OwnershipCapturedAddUp100Perc, testData.get("Do the ownership percentages captured on the organogram add up to 100% on each level").toString());
        }

        //End of Risk Indicator


        //Cash Transmission Or Exchange Services

        key = "Comment on the description of the MSB business model, including products, services and facilities provided by the bank. This information should include a summary of the services provided by the MSB, including details of the countries they deal with";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }

        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Comment on the expected activity of the MSB over the next 2 years at a high level, including any plans for expansion / reduction that the MSB can share";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }

        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "MSB Website";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Legal form of the MSB";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }

        key = "Are agents licensed / regulated in accordance with their legal / regulatory obligation";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//input";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//input";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }

        key = "Has documentary evidence of the MSBs registration with FinCEN been obtained(where the MSB operates within the USA or provides MSB-like services in the USA)";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//input";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//input";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Details of MLRO and any other key AML officials, including contact numbers and email addresses. Also obtain details of regional / national AML compliance teams / officials unless all contact is routed through a central team";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Evidence of training of MSB staff and management";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Does the MSB use agents to source / effect business activity";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//input";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//input";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Are agents licensed / regulated in accordance with their legal / regulatory obligation";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//input";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//input";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Do agents have a compliance program that is independent of the MSB’s own AML program";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Does the MSB review the AML compliance program of its agents or require the agents to obtain an independent review";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//input";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//input";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Is the MSB’s nature of business linked to digital currencies, or is it intending in the future to use digital currencies as a means of making or receiving payments";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//input";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//input";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Does the MSB meet the required standard for acceptance as a client";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//input";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//input";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Introducer risk";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//input";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//input";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }


        key = "What is the MSB’s policy regarding non-compliance by agents with their AML program";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Where the MSB provides training to its agents, describe the type and frequency of training provided";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Describe how the MSB’s reporting and monitoring process covers the financial activities of its agents";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Describe the process for where an agent would notify the MSB of unusual or suspicious activity";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Comments on post-review status";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Comment on details of numbers of suspicious transaction reports raised and/or disclosed";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Comment on Board/Management's oversight of AML programme";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            //path = "//div[table//span[contains(text(),'"+key+"')]]/following-sibling::table//textarea";
            path = "//div[table//span[contains(text(),'s oversight of AML programme')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Comments on the rationale for maintaining the relationship";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Comment on how the MSB records instances where it has exited or declined business for AML reasons (including Sanctions and PEPs), including whether it operates any kind of “watch list” or “banned list”";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Comments on the tools used by the MSB to identify potentially suspicious activity, including how alerts are handled, who signs off alerts, and how they are escalated to the MSB MLRO where relevant";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Source of wealth / capitalisation";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//input";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//input";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }
        key = "Was the clients explanation of source of wealth / capitalisation satisfactory";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//input";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//input";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }


        //End of Cash Transmission Or Exchange Services


        key = "Comments on explanation given for source of wealth / capitalisation";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }

        key = "Reasons as to why the percentages on the organogram do not add up to 100%";
        try {
            path = "//div[table//span[contains(text(),'" + key.substring(0, 90) + "')]]/following-sibling::table//textarea";
        } catch (IndexOutOfBoundsException e) {
            path = "//div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
        }
        if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
            element.clear("xpath||" + path);
            element.typeOnElement("xpath||" + path, testData.get(key).toString());
        }

        element.clickOnElement("//div[table//span[contains(text(),'" + key + "')]]");


        if (!testData.get("Is the client or any related party a PEP").toString().isEmpty() && testData.get("Is the client or any related party a PEP") != null) {
            element.clear("xpath||" + COB_Regulatory_ClientOrAnyRelatedPartyAPEP);
            element.typeOnElement("xpath||" + COB_Regulatory_ClientOrAnyRelatedPartyAPEP, testData.get("Is the client or any related party a PEP").toString());
        }
        if (!testData.get("Adverse media").toString().isEmpty() && testData.get("Adverse media") != null) {
            element.clear("xpath||" + COB_Regulatory_AdverseMedia);
            element.typeOnElement("xpath||" + COB_Regulatory_AdverseMedia, testData.get("Adverse media").toString());
        }
            /*if (!testData.get("Is this client a shell bank").toString().isEmpty() && testData.get("Is this client a shell bank") != null)
            {
                element.clear("xpath||"+COB_Regulatory_ClientShellBank);
                element.typeOnElement("xpath||"+COB_Regulatory_ClientShellBank,testData.get("Is this client a shell bank").toString());
            }*/

        if (!testData.get("Identify the account holder type").toString().isEmpty() && testData.get("Identify the account holder type") != null) {
            element.clear("xpath||" + COB_Regulatory_IdentifyAccountHolderType);
            element.typeOnElement("xpath||" + COB_Regulatory_IdentifyAccountHolderType, testData.get("Identify the account holder type").toString());
            element.clickOnElement("xpath||" + COB_Regulatory_IdentifyAccountHolder);
            element.clickOnElement("xpath||//*[text()='" + testData.get("Identify the account holder type").toString() + "']");

        }
        testData = new HelperMethods().getTestData(espProperties.getProperty("path_onboardingData").toString(), "RegulatoryCalculator1", id);

        element.clickOnElement("xpath||" + COB_Regulatory_CalculatorIcon);
        element.typeOnElement("xpath||" + COB_Regulatory_CalculatorTypeOfAccountDropdown, testData.get("Type of account").toString());
        element.clickOnElement("xpath||" + COB_Regulatory_CalculatorSaveBtn);
//            if (isElementVisible(driver, COB_Screening_ConfirmMsg)) {
//                element.clickOnElement("xpath||" + COB_Screening_ConfirmMsg);
//            }


        Thread.sleep(2000);

        driver.findElements(By.xpath(COB_Regulatory_CalculatorIcon)).get(1).click();

        for (Object keyId : testData.keySet()) {
            if (!keyId.toString().equalsIgnoreCase("Type of account") && !keyId.toString().equalsIgnoreCase("ID") && !keyId.toString().equalsIgnoreCase("Description")) {
                element.clear("xpath||//span[text()='" + keyId.toString() + "']/following::input");
                element.typeOnElement("xpath||//span[text()='" + keyId.toString() + "']/following::input", testData.get(keyId.toString()).toString());
            }
        }
        element.clickOnElement("xpath||" + COB_Regulatory_CalculatorSaveBtn);
//            if (isElementVisible(driver, COB_Screening_ConfirmMsg)) {
//                element.clickOnElement("xpath||" + COB_Screening_ConfirmMsg);
//            }


        /*} catch (Exception e) {
            System.out.println(e.getMessage());
            screenshotNames = screenshotNames + ",fail" + failNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/fail" + (failNo++) + ".jpg");
        }*/

    }

    public void branchAndBankerDetailsPrimary(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData","BranchAndBankerPrimary", id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Client Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Branch And Banker')]");
        try {
            clickOverride(driver, By.xpath("//*[text()='Kofax OCR']"));
        } catch (Exception e) {
            System.out.println("No override");
        }

        //try {
        if (!testData.get("Branch name").toString().isEmpty() && testData.get("Branch name") != null) {
            element.clear("xpath||" + COB_BranchDetails__BranchName);
            element.typeOnElement("xpath||" + COB_BranchDetails__BranchName, testData.get("Branch name").toString());
        }
        if (!testData.get("Site code").toString().isEmpty() && testData.get("Site code") != null) {
            element.clear("xpath||" + COB_BranchDetails__SiteCode);
            element.typeOnElement("xpath||" + COB_BranchDetails__SiteCode, testData.get("Site code").toString());
        }
        if (!testData.get("Address").toString().isEmpty() && testData.get("Address") != null) {
            element.clear("xpath||" + COB_BranchDetails__Address);
            element.typeOnElement("xpath||" + COB_BranchDetails__Address, testData.get("Address").toString());
        }
        if (!testData.get("Telephone number dialling code").toString().isEmpty() && testData.get("Telephone number dialling code") != null) {
            element.clear("xpath||" + COB_BranchDetails__TelephoneNumberDialingCode);
            element.typeOnElement("xpath||" + COB_BranchDetails__TelephoneNumberDialingCode, testData.get("Telephone number dialling code").toString());
        }
        if (!testData.get("Telephone number").toString().isEmpty() && testData.get("Telephone number") != null) {
            element.clear("xpath||" + COB_BranchDetails__TelephoneNumber);
            element.typeOnElement("xpath||" + COB_BranchDetails__TelephoneNumber, testData.get("Telephone number").toString());
        }
        if (!testData.get("First name(s)").toString().isEmpty() && testData.get("First name(s)") != null) {
            List<WebElement> a = driver.findElements(By.xpath(COB_BranchDetails__FirstNames));
            if (a.size() > 1) {
                a.get(a.size() - 1).clear();
                a.get(a.size() - 1).sendKeys(testData.get("First name(s)").toString());
            } else {
                element.clear("xpath||" + COB_BranchDetails__FirstNames);
                element.typeOnElement("xpath||" + COB_BranchDetails__FirstNames, testData.get("First name(s)").toString());

            }
        }
        if (!testData.get("Surname").toString().isEmpty() && testData.get("Surname") != null) {
            List<WebElement> a = driver.findElements(By.xpath(COB_BranchDetails__Surname));
            if (a.size() > 1) {
                a.get(a.size() - 1).clear();
                a.get(a.size() - 1).sendKeys(testData.get("Surname").toString());
            } else {

                element.clear("xpath||" + COB_BranchDetails__Surname);
                element.typeOnElement("xpath||" + COB_BranchDetails__Surname, testData.get("Surname").toString());
            }

        }

        if (!testData.get("Absa user id").toString().isEmpty() && testData.get("Absa user id") != null) {
            element.clear("xpath||" + COB_BranchDetails__AbsaUserId);
            element.typeOnElement("xpath||" + COB_BranchDetails__AbsaUserId, testData.get("Absa user id").toString());
        }
        if (!testData.get("Employee number").toString().isEmpty() && testData.get("Employee number") != null) {
            element.clear("xpath||" + COB_BranchDetails__EmployeeNumber);
            element.typeOnElement("xpath||" + COB_BranchDetails__EmployeeNumber, testData.get("Employee number").toString());
        }
        if (!testData.get("Banker Telephone number dialling code").toString().isEmpty() && testData.get("Banker Telephone number dialling code") != null) {
            element.clear("xpath||" + COB_BranchDetails__BankerTelephoneNumberDialingCode);
            element.typeOnElement("xpath||" + COB_BranchDetails__BankerTelephoneNumberDialingCode, testData.get("Banker Telephone number dialling code").toString());
        }
        if (!testData.get("Banker Telephone number").toString().isEmpty() && testData.get("Banker Telephone number") != null) {
            element.clear("xpath||" + COB_BranchDetails__BankerTelephoneNumber);
            element.typeOnElement("xpath||" + COB_BranchDetails__BankerTelephoneNumber, testData.get("Banker Telephone number").toString());
        }
        if (!testData.get("Cell phone number").toString().isEmpty() && testData.get("Cell phone number") != null) {
            element.clear("xpath||" + COB_BranchDetails__CellPhoneNumber);
            element.typeOnElement("xpath||" + COB_BranchDetails__CellPhoneNumber, testData.get("Cell phone number").toString());
        }
        if (!testData.get("Region").toString().isEmpty() && testData.get("Region") != null) {
            element.clear("xpath||" + COB_BranchDetails__Region);
            element.typeOnElement("xpath||" + COB_BranchDetails__Region, testData.get("Region").toString());
        }
        if (!testData.get("Email").toString().isEmpty() && testData.get("Email") != null) {
            element.clear("xpath||" + COB_BranchDetails__EmailAddress);
            element.typeOnElement("xpath||" + COB_BranchDetails__EmailAddress, testData.get("Email").toString());
        }
        if (!testData.get("CMS number").toString().isEmpty() && testData.get("CMS number") != null) {
            element.clear("xpath||" + COB_BranchDetails__CMSNumber);
            element.typeOnElement("xpath||" + COB_BranchDetails__CMSNumber, testData.get("CMS number").toString());
        }
        screenshotNames = screenshotNames + "," + stepNo + ".jpg";
        getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");
        /*} catch (Exception e) {
            System.out.println(e.getMessage());
            screenshotNames = screenshotNames + ",fail" + failNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/fail" + (failNo++) + ".jpg");
        }*/
    }

    public void branchAndBankerDetailsPrimary_v1(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_onboardingData").toString(), "BranchAndBankerPrimary", id);


        element.clickOnElement("xpath||//span[contains(text(),'Detailed Client Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Branch And Banker')]");

        populateData_v2(driver, testData);

    }

    public void documentSelection(WebDriver driver, int id) throws Exception {
        //element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData","Documents", id);

        element.clickOnElement("xpath||//span[contains(text(),'Documents')]");
        try {
            clickOverride(driver, By.xpath("//*[text()='Kofax OCR']"));
        } catch (Exception e) {
            System.out.println("No override");
        }
        try {
            driver.switchTo().defaultContent();
            Thread.sleep(1000);
            element.clickOnElement("xpath||" + MinimizeWorkHistory);
            driver.switchTo().frame("pEspDefaultContent_IFrame");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        try {
            for (Object key : testData.keySet()) {
                if (!key.toString().equalsIgnoreCase("ID") && !key.toString().equalsIgnoreCase("Description")) {
                    System.out.println(key.toString());

                    String path;
                    if (!testData.get(key).toString().isEmpty() && testData.get(key) != null) {
                        if (key.toString().contains("'")) {
                            path = key.toString().substring(key.toString().indexOf('\'') + 1, key.toString().length() - 1);
                        } else {
                            path = key.toString();
                        }
                        for (WebElement ele : driver.findElements(By.xpath("//div[contains(text(),'" + path + "')]/../../descendant-or-self::table//table//input"))) {
                            if (!ele.isDisplayed())
                                element.clickOnElement("xpath||//span[text()='Document Selection']/../../div[2]");
                            ele.clear();
                            ele.sendKeys(testData.get(key).toString());
                            screenshotNames = screenshotNames + "," + stepNo + ".jpg";
                            getScreenShot(driver, currentFolderName + "/" + (stepNo++) + ".jpg");
                            ele.sendKeys(Keys.TAB);
                        }
                    /*element.clear("xpath|| //div[contains(text(),'"+key+"')]/../../descendant-or-self::table//table//input");

                    element.typeOnElement("xpath|| //div[contains(text(),'"+key+"')]/../../descendant-or-self::table//table//input",testData.get(key).toString());
                    driver.findElement(By.xpath("//div[contains(text(),'"+key+"')]/../../descendant-or-self::table//table//input")).sendKeys(Keys.TAB);*/
                    }
                }

            }

            element.clickOnElement("xpath||//a[@id='ManageDocsControl_ReqDocsSelectControl_btnSave']");

            Thread.sleep(1000);
            try {
                element.clickOnElement("xpath||" + MinimizeIssues);
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
//            if (isElementVisible(driver, COB_Screening_ConfirmMsg)) {
//                element.clickOnElement("xpath||" + COB_Screening_ConfirmMsg);
//            }


            //Document upload
            try {
                if (existsElement(driver, "//span[text()='Document Upload']/parent::*/following-sibling::div/img[contains(@class,'expand-bottom')]")) {
                    driver.findElement(By.xpath("//span[text()='Document Upload']/parent::*/following-sibling::div/img[contains(@class,'expand-bottom')]")).click();
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

            String ScnDocUpload = "//span[text()='Document Upload']/../parent::div/../parent::div/../following-sibling::div";
            //for (Object key : testData.keySet()) {
            //if (!testData.get(key).toString().isEmpty() && testData.get(key).toString() != null) {

            List<WebElement> generateDocs = driver.findElements(By.xpath("//div[@class='row-imagecommand   icon-bookgo ']"));
            while (generateDocs.size() > 0) {
                generateDocs.get(0).click();
                element.clickOnElement(DocumentUploadNOBtn);
                element.clickOnElement(DocumentUploadNPDFBtn);
                generateDocs = driver.findElements(By.xpath("//div[@class='row-imagecommand   icon-bookgo ']"));
            }

            List<WebElement> uploadDocs = driver.findElements(By.xpath("//div[@class='row-imagecommand   icon-bookadd ']"));
            while (uploadDocs.size() > 0) {
                if (!uploadDocs.get(0).isDisplayed())
                    element.clickOnElement("xpath||//span[text()='Document Selection']/../../div[2]");

                ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", uploadDocs.get(0));
                Thread.sleep(200);

                uploadDocs.get(0).click();
                String path = new File("C:\\Automation\\esp-frontend-v2\\src\\test\\resources\\espTestData\\ESPTestDoc.pdf").getAbsolutePath();

                Thread.sleep(1000);
                //driver.findElement(By.id("ManageDocsControl_ReqDocsUploadControl_fuUpload-button")).sendKeys(path);
                //element.clickOnElement("xpath||" + COB_DocumentTab_UploadFile);
                driver.findElement(By.id("ManageDocsControl_ReqDocsUploadControl_fuUpload-button")).click();
                //element.clickOnElement("xpath||" + COB_DocumentTab_UploadFile);

                //UploadDocument(driver,COB_DocumentTab_UploadFile,"","espTestData/ESPTestDoc.pdf");
                robotPasteAndEnter(path);
                Thread.sleep(3000);
                System.out.println("**************************************Following doc");
                uploadDocs = driver.findElements(By.xpath("//div[@class='row-imagecommand   icon-bookadd ']"));
            }


            //}
            //}

        } catch (Exception e) {
            System.out.println(e.getMessage());
            screenshotNames = screenshotNames + ",fail" + failNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/fail" + (failNo++) + ".jpg");
        }
    }

    public void documentSelection_v1(WebDriver driver) throws Exception {

        element = new CommonUtil(driver);
        element.clickOnElement("xpath||//span[contains(text(),'Documents')]");
        try {
            clickOverride(driver, By.xpath("//*[text()='Kofax OCR']"));
        } catch (Exception e) {
            System.out.println("No override");
        }
        try {
            driver.switchTo().defaultContent();
            Thread.sleep(1000);
            element.clickOnElement("xpath||" + MinimizeWorkHistory);
            driver.switchTo().frame("pEspDefaultContent_IFrame");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        String docsString = "//*[text()='Document Selection']/following:: input[@aria-required = 'true'][contains(@id, 'combo')]/../../child :: div[contains(@id, 'trigger-picker')]";

        if(!isElementVisible(driver, docsString))
        {
            element.clickOnElement("xpath||//*[text() = 'Document Selection']/following :: div[contains(@class, 'x-tool-expand-bottom')]");
        }

        List<WebElement> docs = driver.findElements(By.xpath(docsString));
        List<WebElement> docsValues = driver.findElements(By.xpath(docsString+"/../div/input"));

        int counter = 0;
        for (WebElement doc : docs) {
            try {
                if(docsValues.get(counter).getAttribute("value").isEmpty()){
                    doc.click();
                    Actions action = new Actions(driver);
                    action.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();

                }
                System.out.println(" ====== "+docsValues.get(counter++).getAttribute("value"));

            } catch (Exception e) {
            }

        }
        Thread.sleep(500);
        element.clickOnElement("xpath||//*[@id='ManageDocsControl_ReqDocsSelectControl_btnSave-btnEl']");
        Thread.sleep(1000);


        //#####################################################################
        try {
            element.clickOnElement("xpath||" + MinimizeIssues);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
//            if (isElementVisible(driver, COB_Screening_ConfirmMsg)) {
//                element.clickOnElement("xpath||" + COB_Screening_ConfirmMsg);
//            }


        //Document upload
        try {
            if (existsElement(driver, "//span[text()='Document Upload']/parent::*/following-sibling::div/img[contains(@class,'expand-bottom')]")) {
                driver.findElement(By.xpath("//span[text()='Document Upload']/parent::*/following-sibling::div/img[contains(@class,'expand-bottom')]")).click();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        String ScnDocUpload = "//span[text()='Document Upload']/../parent::div/../parent::div/../following-sibling::div";
        //for (Object key : testData.keySet()) {
        //if (!testData.get(key).toString().isEmpty() && testData.get(key).toString() != null) {
//        List<WebElement> generateDocs = driver.findElements(By.xpath("//div[@class='row-imagecommand   icon-bookgo ']"));
//        while (generateDocs.size() > 0) {
//            generateDocs.get(0).click();
//            element.clickOnElement(DocumentUploadNOBtn);
//            element.clickOnElement(DocumentUploadNPDFBtn);
//            element.clickOnElement("xpath||//*[@id='ManageDocsControl_ReqDocsUploadControl_btnGeneratePdf-btnInnerEl']");
//            generateDocs = driver.findElements(By.xpath("//div[@class='row-imagecommand   icon-bookgo ']"));
//        }

        List<WebElement> uploadDocs = driver.findElements(By.xpath("//div[@class='row-imagecommand   icon-bookadd ']"));
        while (uploadDocs.size() > 0) {
            if (!uploadDocs.get(0).isDisplayed())
                element.clickOnElement("xpath||//span[text()='Document Selection']/../../div[2]");
            uploadDocs.get(0).click();
            String path = new File("C:\\Automation\\esp-frontend-v2\\src\\test\\resources\\espTestData\\ESPTestDoc.pdf").getAbsolutePath();

            Thread.sleep(1000);
            //driver.findElement(By.id("ManageDocsControl_ReqDocsUploadControl_fuUpload-button")).sendKeys(path);
            //element.clickOnElement("xpath||" + COB_DocumentTab_UploadFile);
            driver.findElement(By.id("ManageDocsControl_ReqDocsUploadControl_fuUpload-button")).click();
            //element.clickOnElement("xpath||" + COB_DocumentTab_UploadFile);

            //UploadDocument(driver,COB_DocumentTab_UploadFile,"","espTestData/ESPTestDoc.pdf");
            robotPasteAndEnter(path);
            Thread.sleep(3000);
            System.out.println("**************************************Following doc");
            uploadDocs = driver.findElements(By.xpath("//div[@class='row-imagecommand   icon-bookadd ']"));
        }


    }

    public void detailedCIClientDetails(WebDriver driver, int id) throws Exception {

        /*****
         * TODO
         * Handle indentity information (Detailed Client Information, Client Details)
         */
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        testData = new HelperMethods().getTestData(espProperties.getProperty("path_onboardingData").toString(), "DetailedClientInfo_CD", id);

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        element.clickOnElement(DCI);
        element.clickOnElement(PIClientDetailsTab);

        //try {

        try {
            clickOverride(driver, By.xpath("//*[text()='Kofax OCR']"));
        } catch (Exception e) {
            System.out.println("No override");
        }


        if (testData.get("Full name of client").toString() != null && !testData.get("Full name of client").toString().isEmpty()) {
            element.clear("xpath||" + pnlPrimaryFields + II_FullNameOfClient);
            element.typeOnElement("xpath||" + pnlPrimaryFields + II_FullNameOfClient, testData.get("Full name of client").toString());
        }

        if (testData.get("Client type").toString() != null && !testData.get("Client type").toString().isEmpty()) {
            List<WebElement> w = driver.findElements(By.xpath(pnlPrimaryFields + II_ClientType));
            w.get(0).clear();
            w.get(0).sendKeys(testData.get("Client type").toString());
            w.get(0).sendKeys(Keys.ENTER);
        }

        if (testData.get("Trust / pension / provident / other fund number").toString() != null && !testData.get("Trust / pension / provident / other fund number").toString().isEmpty()) {
            element.clear("xpath||" + pnlPrimaryFields + txtBoxTrustDeedNumber);
            element.typeOnElement("xpath||" + pnlPrimaryFields + txtBoxTrustDeedNumber, testData.get("Trust / pension / provident / other fund number").toString());
        }

        if (testData.get("Date established").toString() != null && !testData.get("Date established").toString().isEmpty()) {
            element.clear("xpath||" + pnlPrimaryFields + BCI_DateEstablished);
            element.typeOnElement("xpath||" + pnlPrimaryFields + BCI_DateEstablished, testData.get("Date established").toString());
        }

        if (testData.get("Country of incorporation").toString() != null && !testData.get("Country of incorporation").toString().isEmpty()) {
            element.clear("xpath||" + pnlPrimaryFields + lstSolePropCountryOfIncorporation);
            element.typeOnElement("xpath||" + pnlPrimaryFields + lstSolePropCountryOfIncorporation, testData.get("Country of incorporation").toString());

            driver.findElement(By.xpath(pnlPrimaryFields + lstSolePropCountryOfIncorporation)).sendKeys(Keys.ENTER);
        }

        if (testData.get("Co-operative subtype").toString() != null && !testData.get("Co-operative subtype").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, Co_OperativeSubType).click();
            element.selectFromLi(testData.get("Co-operative subtype").toString(), driver);
        }


        if (testData.get("Target business unit segment").toString() != null && !testData.get("Target business unit segment").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, lstTagertBusinessUnitSegment).click();
            element.selectFromLi(testData.get("Target business unit segment").toString(), driver);
        }

        if (testData.get("Division").toString() != null && !testData.get("Division").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, lstTagertBusinessDevision).click();
            element.selectFromLi(testData.get("Division").toString(), driver);
        }

        if (testData.get("Registered for Tax in South Africa").toString() != null && !testData.get("Registered for Tax in South Africa").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, COB_CD_TaxSouthAfrica).click();
            element.selectFromLi(testData.get("Registered for Tax in South Africa").toString(), driver);
        }

        if (testData.get("Registered for VAT in South Africa").toString() != null && !testData.get("Registered for VAT in South Africa").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, COB_CD_VatSouthAfrica).click();
            element.selectFromLi(testData.get("Registered for VAT in South Africa").toString(), driver);
        }

        if (testData.get("Registered for Foreign Tax").toString() != null && !testData.get("Registered for Foreign Tax").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, COB_CD_ForeignTax).click();
            element.selectFromLi(testData.get("Registered for Foreign Tax").toString(), driver);
        }


        if (testData.get("Financial year end").toString() != null && !testData.get("Financial year end").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, COB_CD_FinancialYearEnd).click();
            element.selectFromLi(testData.get("Financial year end").toString(), driver);
        }


        if (testData.get("SA Tax number available for capture").toString() != null && !testData.get("SA Tax number available for capture").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, COB_CD_SATaxNumberAvailable).click();
            element.selectFromLi(testData.get("SA Tax number available for capture").toString(), driver);
        }

        if (testData.get("Income tax registration number").toString() != null && !testData.get("Income tax registration number").toString().isEmpty()) {
            element.clear("xpath||" + COB_CD_IncomeTaxRegNumber);
            element.typeOnElement("xpath||" + COB_CD_IncomeTaxRegNumber, testData.get("Income tax registration number").toString());

        }
        if (testData.get("Reason SA Tax number not given").toString() != null && !testData.get("Reason SA Tax number not given").toString().isEmpty()) {
            element.clear("xpath||" + COB_CD_ReasonSATaxNumberNotGiven);
            element.typeOnElement("xpath||" + COB_CD_ReasonSATaxNumberNotGiven, testData.get("Reason SA Tax number not given").toString());

        }

        if (testData.get("Standard industry code (SIC)").toString() != null && !testData.get("Standard industry code (SIC)").toString().isEmpty()) {

            SIC(driver, id);
        }

        if (testData.get("Is the client involved in agriculture, hunting, forestry or fishing").toString() != null && !testData.get("Is the client involved in agriculture, hunting, forestry or fishing").toString().isEmpty()) {
            element.waitForElement(driver, 15, COB_CD_ClientInvolveInAgric).click();
            element.selectFromLi(testData.get("Is the client involved in agriculture, hunting, forestry or fishing").toString(), driver);

        }

        element.clickOnElement(COB_CD_NatureClient);

        testData = new HelperMethods().getTestData(espProperties.getProperty("path_onboardingData").toString(), "Field Calculator_CD", id);

        if (testData.get("Industry").toString() != null && !testData.get("Industry").toString().isEmpty()) {
            element.clear("xpath||" + COB_CD_FC_Industry);
            element.typeOnElement("xpath||" + COB_CD_FC_Industry, testData.get("Industry").toString());
        }

        if (testData.get("Products / services offered by the customer").toString() != null && !testData.get("Products / services offered by the customer").toString().isEmpty()) {
            element.clear("xpath||" + COB_CD_FC_ProductOrServices);
            element.typeOnElement("xpath||" + COB_CD_FC_ProductOrServices, testData.get("Products / services offered by the customer").toString());

        }

        if (testData.get("Wholesale / Retail").toString() != null && !testData.get("Wholesale / Retail").toString().isEmpty()) {
            element.clear("xpath||" + COB_CD_FC_WholesaleOrRetail);
            element.typeOnElement("xpath||" + COB_CD_FC_WholesaleOrRetail, testData.get("Wholesale / Retail").toString());
            Thread.sleep(500);
            driver.findElement(By.xpath(COB_CD_FC_WholesaleOrRetail)).sendKeys(Keys.ENTER);

        }

        if (testData.get("Number of operation locations").toString() != null && !testData.get("Number of operation locations").toString().isEmpty()) {
            element.clear("xpath||" + COB_CD_FC_NumberOfOperationLocation);
            element.typeOnElement("xpath||" + COB_CD_FC_NumberOfOperationLocation, testData.get("Number of operation locations").toString());

        }

        if (testData.get("Location of operations (areas / regions not countries)").toString() != null && !testData.get("Location of operations (areas / regions not countries)").toString().isEmpty()) {
            element.clear("xpath||" + COB_CD_FC_LocationOfOperation);
            element.typeOnElement("xpath||" + COB_CD_FC_LocationOfOperation, testData.get("Location of operations (areas / regions not countries)").toString());

        }

        if (testData.get("Number of clients the customer has").toString() != null && !testData.get("Number of clients the customer has").toString().isEmpty()) {
            element.clear("xpath||" + COB_CD_FC_NumberOfClientPerCustomer);
            element.typeOnElement("xpath||" + COB_CD_FC_NumberOfClientPerCustomer, testData.get("Number of clients the customer has").toString());

        }

        if (testData.get("Location of the customers clients").toString() != null && !testData.get("Location of the customers clients").toString().isEmpty()) {
            element.clear("xpath||" + COB_CD_FC_LocationOfCustomersClients);
            element.typeOnElement("xpath||" + COB_CD_FC_LocationOfCustomersClients, testData.get("Location of the customers clients").toString());

        }

        if (testData.get("Does the customer do any exports").toString() != null && !testData.get("Does the customer do any exports").toString().isEmpty()) {
            element.clear("xpath||" + COB_CD_FC_DoesCustomersDoAnyExports);
            element.typeOnElement("xpath||" + COB_CD_FC_DoesCustomersDoAnyExports, testData.get("Does the customer do any exports").toString());
            Thread.sleep(500);
            driver.findElement(By.xpath(COB_CD_FC_DoesCustomersDoAnyExports)).sendKeys(Keys.ENTER);

        }

        if (testData.get("Does the customer do any imports").toString() != null && !testData.get("Does the customer do any imports").toString().isEmpty()) {
            element.clear("xpath||" + COB_CD_FC_DoesCustomersDoAnyImports);
            element.typeOnElement("xpath||" + COB_CD_FC_DoesCustomersDoAnyImports, testData.get("Does the customer do any imports").toString());
            Thread.sleep(500);
            driver.findElement(By.xpath(COB_CD_FC_DoesCustomersDoAnyImports)).sendKeys(Keys.ENTER);

        }

        if (testData.get("Countries exported to").toString() != null && !testData.get("Countries exported to").toString().isEmpty()) {
            element.clear("xpath||" + COB_CD_FC_CountryExpotedTo);
            element.typeOnElement("xpath||" + COB_CD_FC_CountryExpotedTo, testData.get("Countries exported to").toString());
        }

        if (testData.get("Countries imported from").toString() != null && !testData.get("Countries imported from").toString().isEmpty()) {
            element.clear("xpath||" + COB_CD_FC_CountryExpotedFrom);
            element.typeOnElement("xpath||" + COB_CD_FC_CountryExpotedFrom, testData.get("Countries imported from").toString());
        }

        element.clickOnElement(COB_CD_FC_SaveButton);

        //Minimize issues panel
        Thread.sleep(1000);
        try {
            element.clickOnElement("xpath||" + MinimizeIssues);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        //

//            if (isElementVisible(driver, COB_Screening_ConfirmMsg)) {
//                element.clickOnElement("xpath||" + COB_Screening_ConfirmMsg);
//            }

        testData = new HelperMethods().getTestData(espProperties.getProperty("path_onboardingData").toString(), "DetailedClientInfo_CD", id);

        if (testData.get("Is the SIC code being changed as part of this work item").toString() != null && !testData.get("Is the SIC code being changed as part of this work item").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, COB_CD_SICCode).click();
            element.selectFromLi(testData.get("Is the SIC code being changed as part of this work item").toString(), driver);
        }


        if (testData.get("Practice number").toString() != null && !testData.get("Practice number").toString().isEmpty()) {
            element.clear("xpath||" + COB_CD_PracticeNumber);
            element.typeOnElement("xpath||" + COB_CD_PracticeNumber, testData.get("Practice number").toString());
        }

        Thread.sleep(1000);

        if (testData.get("Does the client fall under the CPA").toString() != null && !testData.get("Does the client fall under the CPA").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, COB_CD_ClientUnderCPA).click();
            element.selectFromLi(testData.get("Does the client fall under the CPA").toString(), driver);
        }


        Thread.sleep(1000);
        element.clickOnElement(COB_CD_DoesTheClientFallUnderNCA);
        Thread.sleep(1000);
        element.clickOnElement(COB_CD_ApplyingForCreditNO);

        if (testData.get("Does the client fall under the NCA").toString() != null && !testData.get("Does the client fall under the NCA").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, COB_CD_ClientUnderNCA).click();
            element.selectFromLi(testData.get("Does the client fall under the NCA").toString(), driver);
        }

        if (testData.get("Client category").toString() != null && !testData.get("Client category").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, COB_CD_ClientCategory).click();
            element.selectFromLi(testData.get("Client category").toString(), driver);
        }

        if (testData.get("Is the client a Special Purpose Vehicle (SPV)").toString() != null && !testData.get("Is the client a Special Purpose Vehicle (SPV)").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, COB_CD_SPV).click();
            element.selectFromLi(testData.get("Is the client a Special Purpose Vehicle (SPV)").toString(), driver);
        }

        if (testData.get("Is the client exempt from FICA").toString() != null && !testData.get("Is the client exempt from FICA").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, COB_CD_ClientExemptFICA).click();
            element.selectFromLi(testData.get("Is the client exempt from FICA").toString(), driver);
        }

        if (testData.get("Monthly income").toString() != null && !testData.get("Monthly income").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, COB_CD_MonthlyIcome).click();
            element.selectFromLi(testData.get("Monthly income").toString(), driver);
        }

        if (testData.get("Source of income").toString() != null && !testData.get("Source of income").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, COB_CD_SourceOfIncome).click();
            element.selectFromLi(testData.get("Source of income").toString(), driver);
        }

        if (testData.get("Was the clients explanation of source of income satisfactory").toString() != null && !testData.get("Was the clients explanation of source of income satisfactory").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, COB_CD_SourceOfIncomeSatisfactory).click();
            element.selectFromLi(testData.get("Was the clients explanation of source of income satisfactory").toString(), driver);
        }

        if (testData.get("Is the client rendering financial services as defined in the FAIS act").toString() != null && !testData.get("Is the client rendering financial services as defined in the FAIS act").toString().isEmpty()) {
            Thread.sleep(1000);
            element.waitForElement(driver, 15, COB_CD_FinancialDefineInFAIS).click();
            element.selectFromLi(testData.get("Is the client rendering financial services as defined in the FAIS act").toString(), driver);
        }

        if (testData.get("Trading name").toString() != null && !testData.get("Trading name").toString().isEmpty()) {
            Thread.sleep(1000);
            element.clear("xpath||" + txtBoxTradingName);
            element.typeOnElement("xpath||" + txtBoxTradingName, testData.get("Trading name").toString());
        }

        element.clickOnElement(COB_SaveBtn);

        Thread.sleep(1000);
        try {
            element.clickOnElement("xpath||" + MinimizeIssues);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        /*} catch (Exception e) {
            System.out.println(e.getMessage());
            screenshotNames = screenshotNames + ",fail" + failNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/fail" + (failNo++) + ".jpg");
        }*/

    }

    public void completion(WebDriver driver) throws Exception {
        element.clickOnElement("xpath||//span[contains(text(),'Completion')]");
        List<WebElement> elements = driver.findElements(By.xpath(Issues));

        System.out.println(elements.get(elements.size() - 1).getText());

        String id = driver.findElement(By.xpath("//*[@id='lblInstructionInfo']/span")).getText();
        id = id.substring(id.indexOf(": ") + 2, id.indexOf('|'));

        System.out.println("======" + id + "======");

        Thread.sleep(1000);
        element.clickOnElement("xpath||" + CompletionSaveBtn);


       /* Thread.sleep(3000);
        claimTask(driver, Integer.parseInt(id));
        claimTask(driver, Integer.parseInt(id));
        element.clickOnElement(COB_Screening_ConfirmMsg);*/

        driver.get(driver.getCurrentUrl());
        driver.switchTo().defaultContent();
        element.clickOnElement(OnBoardingInstruction);
        element.clickOnElement(WorkbenchMinimizeBtn);
    }

    public void claimTask(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);

        driver.get(driver.getCurrentUrl());


        driver.switchTo().defaultContent();

        //try {
        element.clickOnElement(UnclaimedSpan);
        element.clickOnElement(WorkbenchMinimizeBtn);

        driver.switchTo().frame("pEspDefaultContent_IFrame");

        Thread.sleep(1000);
        element.typeOnElement(UnclaimedFilterInput, "" + id);
        Thread.sleep(1000);
        WebElement edit = driver.findElement(By.xpath("//td[*[contains(text(),'" + id + "')]]/following-sibling::td//*[@role='img']"));
        Thread.sleep(500);
        edit.click();

        element.clickOnElement(ClaimConfirmYesBtn);

        Thread.sleep(3000);
        try {
            element.clickOnElement("xpath||" + MinimizeWorkHistory);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        try {
            //TODO Check list
            element.clickOnElement(CheckListTab);
            element.typeOnElement(CASAManualLingingInput, "YES");

            element.clickOnElement(ChecklistSaveBtn);

            Thread.sleep(5000);


        } catch (Exception e1) {

        }

        element.clickOnElement(ProgressInstruction);
        Thread.sleep(3000);
        element.typeOnElement(ProgressInstructionCommentTextarea, "Test comment");
        element.clickOnElement(submitProgressInstructionCommentBtn);

        Thread.sleep(2000);
        element.clickOnElement(ProgressConfirmYesBtn);




        /*} catch (Exception e) {
            System.out.println(e.getMessage());
            screenshotNames = screenshotNames + ",fail" + failNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/fail" + (failNo++) + ".jpg");
        }*/

    }

    public void SIC(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_onboardingData").toString(), "DetailedClientInfo_CD", id);

        Actions actions = new Actions(driver);

        String sic = testData.get("Standard Industry Code (SIC)").get("Standard Industry Code (SIC)").get("Standard industry code (SIC)").toString();

        try {
            driver.findElement(By.xpath("//span[text()='Standard industry code (SIC)']/following::div[contains(@class,'x-form-trigger')]")).click();
            Thread.sleep(3000);
//            driver.findElement(By.xpath("//span[text()='Standard industry code (SIC)']/following::div[contains(@class,'x-form-trigger')]")).click();
//            Thread.sleep(3000);
            List<WebElement> e= driver.findElements(By.xpath("//span[text() = 'Standard industry code (SIC)']/following :: span[text() = 'Filter:']/following :: input"));
            for(WebElement el:e){
                System.out.println(el.isEnabled() + "=============================================="+el.isDisplayed());
                if(el.isDisplayed()){
                    el.clear();
                    el.sendKeys(sic);
                    el.sendKeys(Keys.ENTER);
                }
            }

            Thread.sleep(2500);
            while (!driver.findElement(By.xpath("//span[text() = '"+sic+"']")).isDisplayed()){
                System.out.println("============== SIC not displayed");
            }
            driver.findElement(By.xpath("//span[text() = '"+sic+"']")).click();

            Thread.sleep(1000);

        } catch (Exception e) {
            System.out.println(e.getMessage());
            //throw new Exception();

        }
    }


    public void officeUse_dci(WebDriver driver, int id) throws Exception {

        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData", " Office Use", id);

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        /* try {*/
        element.clickOnElement(DCI);
        element.clickOnElement(COB_OfficeUSeTab);

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (testData.get("Does the Client have an NDA with ABSA?").toString() != null && !testData.get("Does the Client have an NDA with ABSA?").toString().isEmpty()) {
            element.clear("xpath||" + COB_OfficeUSe_DoesClientHaveNDAWithAbsa);
            element.typeOnElement("xpath||" + COB_OfficeUSe_DoesClientHaveNDAWithAbsa, testData.get("Does the Client have an NDA with ABSA?").toString());

            driver.findElement(By.xpath(COB_OfficeUSe_DoesClientHaveNDAWithAbsa)).sendKeys(Keys.ENTER);
        }

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (testData.get("Date identified").toString() != null && !testData.get("Date identified").toString().isEmpty()) {
            element.clear("xpath||" + COB_OfficeUSe_DateIdentified);
            element.typeOnElement("xpath||" + COB_OfficeUSe_DateIdentified, testData.get("Date identified").toString());

            driver.findElement(By.xpath(COB_OfficeUSe_DateIdentified)).sendKeys(Keys.ENTER);
        }

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

     /*   if (testData.get("Identified by employee full names").toString() != null && !testData.get("Identified by employee full names").toString().isEmpty()) {
            element.clear("xpath||" + COB_OfficeUSe_IdentifyByEmplyeeFullName);
            element.typeOnElement("xpath||" + COB_OfficeUSe_IdentifyByEmplyeeFullName, testData.get("Identified by employee full names").toString());

            driver.findElement(By.xpath(COB_OfficeUSe_IdentifyByEmplyeeFullName)).sendKeys(Keys.ENTER);
        }*/

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (testData.get("Identified by employee number").toString() != null && !testData.get("Identified by employee number").toString().isEmpty()) {
            element.clear("xpath||" + COB_OfficeUSe_IdentifyByEmplyeeNumber);
            element.typeOnElement("xpath||" + COB_OfficeUSe_IdentifyByEmplyeeNumber, testData.get("Identified by employee number").toString());

            driver.findElement(By.xpath(COB_OfficeUSe_IdentifyByEmplyeeNumber)).sendKeys(Keys.ENTER);
        }

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        /*if (testData.get("Account / reference number").toString() != null && !testData.get("Account / reference number").toString().isEmpty()) {
            element.clear("xpath||" + COB_OfficeUSe_AccOrRefNumber);
            element.typeOnElement("xpath||" + COB_OfficeUSe_AccOrRefNumber, testData.get("Account / reference number").toString());

            driver.findElement(By.xpath(COB_OfficeUSe_AccOrRefNumber)).sendKeys(Keys.ENTER);
        }*/


      /*  driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (testData.get("First name(s)").toString() != null && !testData.get("First name(s)").toString().isEmpty()) {
            element.clear("xpath||" + COB_OfficeUSe_FirstName);
            element.typeOnElement("xpath||" + COB_OfficeUSe_FirstName, testData.get("First name(s)").toString());

            driver.findElement(By.xpath(COB_OfficeUSe_FirstName)).sendKeys(Keys.ENTER);
        }

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (testData.get("Surname").toString() != null && !testData.get("Surname").toString().isEmpty()) {
            element.clear("xpath||" + COB_OfficeUSe_Surname);
            element.typeOnElement("xpath||" + COB_OfficeUSe_Surname, testData.get("Surname").toString());

            driver.findElement(By.xpath(COB_OfficeUSe_Surname)).sendKeys(Keys.ENTER);
        }


        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (testData.get("Employee number").toString() != null && !testData.get("Employee number").toString().isEmpty()) {
            element.clear("xpath||" + COB_OfficeUSe_EmployeeNumber);
            element.typeOnElement("xpath||" + COB_OfficeUSe_EmployeeNumber, testData.get("Employee number").toString());

            driver.findElement(By.xpath(COB_OfficeUSe_EmployeeNumber)).sendKeys(Keys.ENTER);
        }


        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (testData.get("SDS ID").toString() != null && !testData.get("SDS ID").toString().isEmpty()) {
            element.clear("xpath||" + COB_OfficeUSe_SDSID);
            element.typeOnElement("xpath||" + COB_OfficeUSe_SDSID, testData.get("SDS ID").toString());

            driver.findElement(By.xpath(COB_OfficeUSe_SDSID)).sendKeys(Keys.ENTER);
        }

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (testData.get("Midbase ID").toString() != null && !testData.get("Midbase ID").toString().isEmpty()) {
            element.clear("xpath||" + COB_OfficeUSe_MidbaseID);
            element.typeOnElement("xpath||" + COB_OfficeUSe_MidbaseID, testData.get("Midbase ID").toString());

            driver.findElement(By.xpath(COB_OfficeUSe_MidbaseID)).sendKeys(Keys.ENTER);
        }*/

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (testData.get("Work item classification").toString() != null && !testData.get("Work item classification").toString().isEmpty()) {

            List<WebElement> workItem = driver.findElements(By.xpath(COB_OfficeUSe_WorkItemClassification));
            workItem.get(0).clear();
            workItem.get(0).sendKeys(testData.get("Work item classification").toString());
            /*element.clear("xpath||" + COB_OfficeUSe_WorkItemClassification);
            element.typeOnElement("xpath||" + COB_OfficeUSe_WorkItemClassification, testData.get("Work item classification").toString()); */

            driver.findElement(By.xpath(COB_OfficeUSe_WorkItemClassification)).sendKeys(Keys.ENTER);
        }

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        /*if (testData.get("Agricultural sub-type if applicable").toString() != null && !testData.get("Agricultural sub-type if applicable").toString().isEmpty()) {
            element.clear("xpath||" + COB_OfficeUSe_AgricSubType);
            element.typeOnElement("xpath||" + COB_OfficeUSe_AgricSubType, testData.get("Agricultural sub-type if applicable").toString());

            driver.findElement(By.xpath(COB_OfficeUSe_AgricSubType)).sendKeys(Keys.ENTER);
        }*/
        /*} catch (Exception e) {
            System.out.println(e.getMessage());
            screenshotNames = screenshotNames + ",fail" + failNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/fail" + (failNo++) + ".jpg");
        }*/
    }

    public void officeUse_dci_v1(WebDriver driver, int id) throws Exception {
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_onboardingData").toString(), " Office Use", id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Client Information')]");
        tabScroll(driver, "6. Office Use");
        populateData(driver, testData);







    }

    public void documentPrepopulation(WebDriver driver, int id) throws Exception {

        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData","Document Pre-Population", id);

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        try {
            element.clickOnElement(COB_DocumentPrePopulation);

            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

            if (testData.get("Signed at").toString() != null && !testData.get("Signed at").toString().isEmpty()) {
                List<WebElement> signedAt = driver.findElements(By.xpath(COB_DocumentPrePopulation_SignedAt));
                element.clear("xpath||" + signedAt.get(0));
                element.typeOnElement("xpath||" + signedAt.get(0), testData.get("Signed at").toString());

            }

            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

            if (testData.get("Signed on").toString() != null && !testData.get("Signed on").toString().isEmpty()) {
                List<WebElement> signedAt = driver.findElements(By.xpath(COB_DocumentPrePopulation_SignedOn));
                element.clear("xpath||" + signedAt.get(0));
                element.typeOnElement("xpath||" + signedAt.get(0), testData.get("Signed on").toString());

            }

            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

            if (testData.get("Do you want ESP to generate Global Application form").toString() != null && !testData.get("Do you want ESP to generate Global Application form").toString().isEmpty()) {
                element.clear("xpath||" + COB_DocumentPrePopulation_ESPPopulateSTDAbsaResolution);
                element.typeOnElement("xpath||" + COB_DocumentPrePopulation_ESPPopulateSTDAbsaResolution, testData.get("Do you want ESP to generate Global Application form").toString());

            }

            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

            if (testData.get("Do you require ESP to populate the standard Absa resolution for you").toString() != null && !testData.get("Do you require ESP to populate the standard Absa resolution for you").toString().isEmpty()) {
                element.clear("xpath||" + COB_DocumentPrePopulation_ESPPopulateAbsaMandate);
                element.typeOnElement("xpath||" + COB_DocumentPrePopulation_ESPPopulateAbsaMandate, testData.get("Do you require ESP to populate the standard Absa resolution for you").toString());


            }


            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

            if (testData.get("Record of telephonic engagement required").toString() != null && !testData.get("Record of telephonic engagement required").toString().isEmpty()) {
                Thread.sleep(500);
                element.clear("xpath||" + COB_DocumentPrePopulation_RecordTelEngagement);
                element.typeOnElement("xpath||" + COB_DocumentPrePopulation_RecordTelEngagement, testData.get("Record of telephonic engagement required").toString());


            }

            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

            if (testData.get("Are all the related parties (excluding sureties) to the primary client natural persons").toString() != null && !testData.get("Are all the related parties (excluding sureties) to the primary client natural persons").toString().isEmpty()) {
                Thread.sleep(500);
                element.clear("xpath||" + COB_DocumentPrePopulation_PrimaryClientNatural);
                element.typeOnElement("xpath||" + COB_DocumentPrePopulation_PrimaryClientNatural, testData.get("Are all the related parties (excluding sureties) to the primary client natural persons").toString());

            }

            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

            if (testData.get("Is there more than one natural person related party").toString() != null && !testData.get("Is there more than one natural person related party").toString().isEmpty()) {
                element.clear("xpath||" + COB_DocumentPrePopulation_NaturalPersonRelatedParty);
                element.typeOnElement("xpath||" + COB_DocumentPrePopulation_NaturalPersonRelatedParty, testData.get("Is there more than one natural person related party").toString());

            }

            element.clickOnElement(COB_SaveBtn);

            Thread.sleep(1000);
            try {
                element.clickOnElement("xpath||" + MinimizeIssues);
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
            screenshotNames = screenshotNames + ",fail.jpg";
            getScreenShot(driver, currentFolderName + "/fail.jpg");
        }

    }

    public void documentPrepopulation_v1(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        element.clickOnElement(DCI);
        tabScroll(driver, "Document Pre-Population");
        populate(driver, "Document Pre-Population", id);

        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        element.clickOnElement("xpath||//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_btnSave']");

    }

    public void screening(WebDriver driver, int id) throws Exception {

        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData","ScreeningPrimaryParty", id);

        element.waitForElement(driver, 15, COB_ScreeningTab).click();

        Thread.sleep(1000);


        if (testData.get("Site Code").toString() != null && !testData.get("Site Code").toString().isEmpty()) {
            element.clear("xpath||" + COB_Screening_SiteCode);
            element.typeOnElement("xpath||" + COB_Screening_SiteCode, testData.get("Site Code").toString());
            driver.findElement(By.xpath(COB_Screening_SiteCode)).sendKeys(Keys.ENTER);

        }

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (testData.get("Teller / Operator Code").toString() != null && !testData.get("Teller / Operator Code").toString().isEmpty()) {
            element.clear("xpath||" + COB_Screening_TellerCode);
            element.typeOnElement("xpath||" + COB_Screening_TellerCode, testData.get("Teller / Operator Code").toString());
            driver.findElement(By.xpath(COB_Screening_TellerCode)).sendKeys(Keys.ENTER);

        }

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (testData.get("AB Number").toString() != null && !testData.get("AB Number").toString().isEmpty()) {
            element.clear("xpath||" + COB_Screening_ABNumber);
            element.typeOnElement("xpath||" + COB_Screening_ABNumber, testData.get("AB Number").toString());
            driver.findElement(By.xpath(COB_Screening_ABNumber)).sendKeys(Keys.ENTER);

        }

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (testData.get("Business Unit").toString() != null && !testData.get("Business Unit").toString().isEmpty()) {
            element.clear("xpath||" + COB_Screening_BusinessUnit);
            element.typeOnElement("xpath||" + COB_Screening_BusinessUnit, testData.get("Business Unit").toString());
            driver.findElement(By.xpath(COB_Screening_BusinessUnit)).sendKeys(Keys.ENTER);

        }

        element.clickOnElement(COB_Screening_ScreeningbtnUserDetailsUpdate);

        Thread.sleep(1000);

        if (!isElementVisible(driver, COB_Screening_ClienType)) {
            element.waitForElement(driver, 15, COB_Screening_PrimaryPartyTab).click();
            Thread.sleep(500);
        }

        if (testData.get("Client Type").toString() != null && !testData.get("Client Type").toString().isEmpty()) {
            element.clear("xpath||" + COB_Screening_ClienType);
            element.typeOnElement("xpath||" + COB_Screening_ClienType, testData.get("Client Type").toString());
            driver.findElement(By.xpath(COB_Screening_ClienType)).sendKeys(Keys.ENTER);

        }

        if (testData.get("First Name").toString() != null && !testData.get("First Name").toString().isEmpty()) {
            element.clear("xpath||" + COB_ScreeningFirstNamePR);
            element.typeOnElement("xpath||" + COB_ScreeningFirstNamePR, testData.get("First Name").toString());
            driver.findElement(By.xpath(COB_ScreeningFirstNamePR)).sendKeys(Keys.ENTER);

        }

        if (testData.get("Surname").toString() != null && !testData.get("Surname").toString().isEmpty()) {
            element.clear("xpath||" + COB_ScreeningSurnamePR);
            element.typeOnElement("xpath||" + COB_ScreeningSurnamePR, testData.get("Surname").toString());
            driver.findElement(By.xpath(COB_ScreeningSurnamePR)).sendKeys(Keys.ENTER);

        }


        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (testData.get("Client Income Group").toString() != null && !testData.get("Client Income Group").toString().isEmpty()) {
            element.clear("xpath||" + COB_Screening_IncomeGroup);
            element.typeOnElement("xpath||" + COB_Screening_IncomeGroup, testData.get("Client Income Group").toString());

            driver.findElement(By.xpath(COB_Screening_IncomeGroup)).sendKeys(Keys.ENTER);

        }

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (testData.get("Client Industry Group").toString() != null && !testData.get("Client Industry Group").toString().isEmpty()) {
            element.clear("xpath||" + COB_Screening_IndustryGroup);
            element.typeOnElement("xpath||" + COB_Screening_IndustryGroup, testData.get("Client Industry Group").toString());


        }

        if (testData.get("Country Registered").toString() != null && !testData.get("Country Registered").toString().isEmpty()) {
            element.clear("xpath||//*[@id = 'ManageCASAControl_CASAMainPartyControl_cmbCountryRegistered-inputEl']");
            element.typeOnElement("xpath||//*[@id = 'ManageCASAControl_CASAMainPartyControl_cmbCountryRegistered-inputEl']", testData.get("Country Registered").toString());

        }


        if (testData.get("Registered City").toString() != null && !testData.get("Registered City").toString().isEmpty()) {
            element.clear("xpath||//*[@id = 'ManageCASAControl_CASAMainPartyControl_txtCityRegistered-inputEl']");
            element.typeOnElement("xpath||//*[@id = 'ManageCASAControl_CASAMainPartyControl_txtCityRegistered-inputEl']", testData.get("Registered City").toString());

        }

        if (testData.get("Town Registered").toString() != null && !testData.get("Town Registered").toString().isEmpty()) {
            element.clear("xpath||//*[@id = 'ManageCASAControl_CASAMainPartyControl_txtTownRegistered-inputEl']");
            element.typeOnElement("xpath||//*[@id = 'ManageCASAControl_CASAMainPartyControl_txtTownRegistered-inputEl']", testData.get("Town Registered").toString());

        }

        if (testData.get("Business Source").toString() != null && !testData.get("Business Source").toString().isEmpty()) {
            element.clear("xpath||//*[@id = 'ManageCASAControl_CASAMainPartyControl_cmbCountryBusiness-inputEl']");
            element.typeOnElement("xpath||//*[@id = 'ManageCASAControl_CASAMainPartyControl_cmbCountryBusiness-inputEl']", testData.get("Business Source").toString());

        }

        if (testData.get("HeadOffice Country").toString() != null && !testData.get("HeadOffice Country").toString().isEmpty()) {
            element.clear("xpath||//*[@id = 'ManageCASAControl_CASAMainPartyControl_cmbCountryHeadOffice-inputEl']");
            element.typeOnElement("xpath||//*[@id = 'ManageCASAControl_CASAMainPartyControl_cmbCountryHeadOffice-inputEl']", testData.get("HeadOffice Country").toString());

        }

        if (testData.get("Head Office TownPP").toString() != null && !testData.get("Head Office TownPP").toString().isEmpty()) {
            element.clear("xpath||//*[@id = 'ManageCASAControl_CASAMainPartyControl_txtTownHeadOffice-inputEl']");
            element.typeOnElement("xpath||//*[@id = 'ManageCASAControl_CASAMainPartyControl_txtTownHeadOffice-inputEl']", testData.get("Head Office TownPP").toString());

        }


        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (testData.get("Nationality").toString() != null && !testData.get("Nationality").toString().isEmpty()) {
            element.clear("xpath||" + COB_Screening_Nationality);
            element.typeOnElement("xpath||" + COB_Screening_Nationality, testData.get("Nationality").toString());


        }

        //*[@id = 'ManageCASAControl_CASAMainPartyControl_cmbCountryPassport-inputEl']

        if (testData.get("Passport Country").toString() != null && !testData.get("Passport Country").toString().isEmpty()) {
            element.clear("xpath|| //*[@id = 'ManageCASAControl_CASAMainPartyControl_cmbCountryPassport-inputEl']");
            element.typeOnElement("xpath|| //*[@id = 'ManageCASAControl_CASAMainPartyControl_cmbCountryPassport-inputEl']", testData.get("Passport Country").toString());

        }


        if (testData.get("Client Employment Status").toString() != null && !testData.get("Client Employment Status").toString().isEmpty()) {
            element.clear("xpath||" + COB_ScreeningClientEmploymentStatus);
            element.typeOnElement("xpath||" + COB_ScreeningClientEmploymentStatus, testData.get("Client Employment Status").toString());
            driver.findElement(By.xpath(COB_ScreeningClientEmploymentStatus)).sendKeys(Keys.ENTER);

        }

        if (testData.get("Country of Residence").toString() != null && !testData.get("Country of Residence").toString().isEmpty()) {
            element.clear("xpath||" + COB_ScreeningCountryOfResidence);
            element.typeOnElement("xpath||" + COB_ScreeningCountryOfResidence, testData.get("Country of Residence").toString());
            driver.findElement(By.xpath(COB_ScreeningCountryOfResidence)).sendKeys(Keys.ENTER);

        }

        if (testData.get("Town of Residence").toString() != null && !testData.get("Town of Residence").toString().isEmpty()) {
            element.clear("xpath||" + COB_ScreeningTownOfResidence);
            element.typeOnElement("xpath||" + COB_ScreeningTownOfResidence, testData.get("Town of Residence").toString());
            driver.findElement(By.xpath(COB_ScreeningTownOfResidence)).sendKeys(Keys.ENTER);

        }

        element.clickOnElement(COB_Screening_ScreeningbtnPrimaryPartyUpdate);

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        if (!isElementVisible(driver, "//*[text() = 'Reference Number']")) {
            element.clickOnElement("xpath||//*[@id = 'ManageCASAControl_pnlRelated_header']");
        }

        String dataRowsEditEntity[];

        if (driverSheet.get("ScreeningRelatedParty").toString() != null && !driverSheet.get("ScreeningRelatedParty").toString().isEmpty()) {
            dataRowsEditEntity = driverSheet.get("ScreeningRelatedParty").toString().split(",");
        } else
            dataRowsEditEntity = new String[0];


        int editEntityCount = 0;

        for (String row : dataRowsEditEntity) {

            testData = fetchTestData("path_onboardingData", "ScreeningRelatedParty", Integer.parseInt(row));

            int entityID = Integer.parseInt(dataRowsEditEntity[editEntityCount++]);
            editRelatedParty(driver, entityID);
        }


        Thread.sleep(500);
        /**** TODO place screening button in a loop
         *
         */

        element.clickOnElement(COB_Screening_CASARelatedPartyControl_btnSubmit);
        Thread.sleep(500);
        element.clickOnElement(COB_Screening_Confirm_btnYes);

        Thread.sleep(500);
        try {
            element.clickOnElement("//xpath||" + MinimizeIssues);
        } catch (NoSuchElementException e) {
            System.err.println(e.getMessage());
        }

        riskProfilingProductSelection(driver);
        //riskProfilingCIB(driver);
        documentationConfirmation(driver);


    }

    public void editRelatedParty(WebDriver driver, int id) throws Exception {

        element = new CommonUtil(driver);


        if (!isElementVisible(driver, "//div[@cmd='Edit']")) {
            element.waitForElement(driver, 15, COB_Screening_RelatedPartyTab).click();
            Thread.sleep(500);
        }

        try {

            if (testData.get("ID Number").toString() != null && !testData.get("ID Number").toString().isEmpty()) {
                WebElement edit = driver.findElement(By.xpath("//td[*[contains(text(),'" + testData.get("ID Number").toString() + "')]]/following-sibling::td//div[@cmd='Edit']"));
                Thread.sleep(500);
                edit.click();
            } else if (testData.get("Registration Number").toString() != null && !testData.get("Registration Number").toString().isEmpty()) {
                WebElement edit = driver.findElement(By.xpath("//td[*[contains(text(),'" + testData.get("Registration Number").toString() + "')]]/following-sibling::td//div[@cmd='Edit']"));
                Thread.sleep(500);
                edit.click();
            } else if (testData.get("Entity Name").toString() != null && !testData.get("Entity Name").toString().isEmpty()) {
                WebElement edit = driver.findElement(By.xpath("//td[*[contains(text(),'" + testData.get("Entity Name").toString() + "')]]/following-sibling::td//div[@cmd='Edit']"));
                Thread.sleep(500);
                edit.click();

            }


            if (testData.get("Relationship").toString() != null && !testData.get("Relationship").toString().isEmpty()) {
                element.clear("xpath||" + COB_ScreeningRelationshipRR);
                element.typeOnElement("xpath||" + COB_ScreeningRelationshipRR, testData.get("Relationship").toString());
            }


            if (testData.get("Client Group").toString() != null && !testData.get("Client Group").toString().isEmpty()) {
                element.clear("xpath||" + COB_ScreeningClientTypeRP);
                element.typeOnElement("xpath||" + COB_ScreeningClientTypeRP, testData.get("Client Group").toString());
            }

            if (testData.get("Client ID Type").toString() != null && !testData.get("Client ID Type").toString().isEmpty()) {
                element.clear("xpath||" + COB_SCreeningClientIDRP);
                element.typeOnElement("xpath||" + COB_SCreeningClientIDRP, testData.get("Client ID Type").toString());
            }

            if (testData.get("Entity Name").toString() != null && !testData.get("Entity Name").toString().isEmpty()) {
                element.clear("xpath||" + COB_ScreeningEntityNameRR);
                element.typeOnElement("xpath||" + COB_ScreeningEntityNameRR, testData.get("Entity Name").toString());
            }

            if (testData.get("Registration Number").toString() != null && !testData.get("Registration Number").toString().isEmpty()) {
                element.clear("xpath||" + COB_ScreeningIDOrRegNoRR);
                element.typeOnElement("xpath||" + COB_ScreeningIDOrRegNoRR, testData.get("Registration Number").toString());
                driver.findElement(By.xpath(COB_ScreeningIDOrRegNoRR)).sendKeys(Keys.ENTER);

            }
            try {
                String idNumber = driver.findElement(By.xpath("//*[text()='Update Party']/following::span[text()='ID Number:']/following::input")).getAttribute("value");
                if (!idNumber.isEmpty() && !idNumber.equals("")) {
                    Date year = new Date();
                    String dateOfBirth = "";
                    if(Integer.parseInt(idNumber.substring(0,2))<=(year.getYear()-100)){
                        if(Integer.parseInt(idNumber.substring(4,6))<10){
                            dateOfBirth = "20"+idNumber.substring(0,2)+"/"+idNumber.substring(2,4)+"/"+idNumber.substring(5,6);
                        }else {
                            dateOfBirth = "20"+idNumber.substring(0,2)+"/"+idNumber.substring(2,4)+"/"+idNumber.substring(4,6);
                        }

                    }
                    else {
                        if(Integer.parseInt(idNumber.substring(4,6))<10){
                            dateOfBirth = "19"+idNumber.substring(0,2)+"/"+idNumber.substring(2,4)+"/"+idNumber.substring(5,6);
                        }else {
                            dateOfBirth = "19"+idNumber.substring(0,2)+"/"+idNumber.substring(2,4)+"/"+idNumber.substring(4,6);
                        }
                    }
                    System.out.println("Date of birth "+dateOfBirth);


                    element.clear("xpath||"+COB_ScreeningDOB);
                    element.typeOnElement("xpath||"+COB_ScreeningDOB,dateOfBirth);


                }
            }catch (Exception e){
                System.out.println(e.getMessage()+"\nDate of birth is not populated");
            }


            if (testData.get("Country Registered").toString() != null && !testData.get("Country Registered").toString().isEmpty()) {
                element.clear("xpath||" + COB_ScreeningRegCountryRR);
                element.typeOnElement("xpath||" + COB_ScreeningRegCountryRR, testData.get("Country Registered").toString());
            }

            if (testData.get("Registered City").toString() != null && !testData.get("Registered City").toString().isEmpty()) {
                element.clear("xpath||" + COB_ScreeningRegCityRR);
                element.typeOnElement("xpath||" + COB_ScreeningRegCityRR, testData.get("Registered City").toString());
            }

            if (testData.get("Town Registered").toString() != null && !testData.get("Town Registered").toString().isEmpty()) {
                element.clear("xpath||" + COB_ScreeningRegTownRR);
                element.typeOnElement("xpath||" + COB_ScreeningRegTownRR, testData.get("Town Registered").toString());
            }


            if (testData.get("Nationality").toString() != null && !testData.get("Nationality").toString().isEmpty()) {
                element.clear("xpath||" + COB_ScreeningNationalityRR);
                element.typeOnElement("xpath||" + COB_ScreeningNationalityRR, testData.get("Nationality").toString());
            }


            Thread.sleep(1000);


            element.clickOnElement(COB_ScreeningSavebtnRR);

            Thread.sleep(1000);
            try {
                element.clickOnElement("xpath||" + MinimizeIssues);
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
            Thread.sleep(1500);
//            if (isElementVisible(driver, COB_Screening_ConfirmMsg)) {
//                element.clickOnElement("xpath||" + COB_Screening_ConfirmMsg);
//            }


        } catch (Exception e) {
            throw new Exception();
        }
    }

    public void riskProfilingProductSelection(WebDriver driver) throws Exception {

        element = new CommonUtil(driver);
        // testData = fetchTestData("ScreeningProductSelection", id);

        if (!isElementVisible(driver, "//*[text() ='Product Selection']")) {
            element.waitForElement(driver, 15, COB_Screening_RiskProfilingTab).click();
            Thread.sleep(800);
        }

//        List<WebElement> products = driver.findElements(By.xpath("//*[@class='x-grid-cell-inner x-grid-checkcolumn-cell-inner']"));
//        products.get(0).click();

        if (isElementVisible(driver, COB_Screening_ConfirmMsg)) {
            element.clickOnElement("xpath||" + COB_Screening_ConfirmMsg);
        }

        Thread.sleep(1000);
        element.waitForElement(driver, 2, COB_Screening_btnProfile).click();
    }

    public void riskProfilingCIB(WebDriver driver) throws Exception {

        element = new CommonUtil(driver);
        element.waitForElement(driver, 2, COB_Screening_btnProfilingResults).click();
        String profilingResults = element.getText("xpath||//div[@id='window-1912-innerCt']");

        System.out.println("====== " + profilingResults);

        element.clickOnElement("xpath||//*[text()='Risk Category']/following::*[@class='x-tool-tool-el x-tool-img x-tool-close ']");


    }

    public void documentationConfirmation(WebDriver driver) throws Exception {

        element = new CommonUtil(driver);


        Thread.sleep(1000);

        if (!isElementVisible(driver, "//*[text() ='Documentation']")) {
            element.waitForElement(driver, 15, COB_Screening_DocumentConfirmation).click();
            Thread.sleep(500);
        }

        Thread.sleep(2000);

        List<WebElement> documents = driver.findElements(By.xpath("//*[text() = 'Documentation']/following :: td[contains(@class,'-ManageCASAControl_RBBProfileDocsControl_gcInOrder')]"));

        for (int i = 0; i < documents.size(); i++) {
            documents.get(i).click();
        }
        element.waitForElement(driver, 2, COB_Screening_btnConfirm).click();


    }

    private void createScreenShotFolder(String folderName) {
        try {
            new File(folderName).mkdirs();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void getScreenShot(WebDriver driver, String fileName) {
        try {
            File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(scrFile, new File(fileName));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void robotPasteAndEnter(String toPaste) {
        try {
            StringSelection absolutePath = new StringSelection(toPaste);
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(absolutePath, null);
            Robot robot = new Robot();
            Thread.sleep(3000);
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_V);

            robot.keyRelease(KeyEvent.VK_CONTROL);
            Thread.sleep(3000); // Sync
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_CONTROL);
            System.out.println("**************************************Pasted");
        } catch (AWTException AWTEx) {
            AWTEx.printStackTrace();
            System.out.println("===================================" + AWTEx.getMessage());
        } catch (InterruptedException IntEx) {
            IntEx.printStackTrace();
            System.out.println("===================================" + IntEx.getMessage());
        } catch (Exception e) {
            System.out.println("===================================" + e.getMessage());
        }
    }

    public void product(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData","Product", id);

        element.clickOnElement(DCI);
        element.clickOnElement("xpath||" + "//span[text() = '7. Product']");

        if (testData.get("Product being added as part of this on-boarding").toString() != null &&
                !testData.get("Product being added as part of this on-boarding").toString().isEmpty()) {


            element.clickOnElement("xpath||" + ProductBeingAddedOnboarding);
            element.selectFromLi(testData.get("Product being added as part of this on-boarding").toString(), driver);


            switch (testData.get("Product being added as part of this on-boarding").toString()) {
                case "NONE":
                    element.clickOnElement("xpath||" + ProductAutomaticallyCreateProducts);
                    element.selectFromLi(testData.get("Do you want to automatically create the products on completion").toString(), driver);
                    break;
                case "CHEQUE ACCOUNT":
                    chequeAccount(driver, Integer.parseInt(driverSheet.get("Cheque Account")));
                    internetBankingServices(driver, Integer.parseInt(driverSheet.get("Internet Banking Service")));
                    mandatedOfficials(driver, Integer.parseInt(driverSheet.get("Mandated Officials")));
                    needsAnalysis(driver, Integer.parseInt(driverSheet.get("Needs Analysis")));
                    recordOfAdvice(driver, Integer.parseInt(driverSheet.get("Record Of Advice")));
                    signingInstructions(driver, Integer.parseInt(driverSheet.get("Signing Instructions")));
                    break;
                case "INVESTMENT / SAVINGS":
                    debitCards(driver, Integer.parseInt(driverSheet.get("Debit Cards")));
                    internetBankingServices(driver, Integer.parseInt(driverSheet.get("Internet Banking Service")));
                    investmentSpecialist(driver, Integer.parseInt(driverSheet.get("Investment Specialist")));
                    investmentsSavings(driver, Integer.parseInt(driverSheet.get("Investment / Savings")));
                    needsAnalysis(driver, Integer.parseInt(driverSheet.get("Needs Analysis")));
                    recordOfAdvice(driver, Integer.parseInt(driverSheet.get("Record Of Advice")));
                    signingInstructions(driver, Integer.parseInt(driverSheet.get("Signing Instructions")));
                    break;
            }
        }
    }

    public void chequeAccount(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_onboardingData").toString(), "Cheque Account", id);

        element.clickOnElement(DCI);
        tabScroll(driver, "Cheque Account");
        populateData(driver, testData);


    }

    public void debitCards(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_onboardingData").toString(), "Debit Cards", id);

        element.clickOnElement(DCI);
        tabScroll(driver, "Debit Cards");
        populateData(driver, testData);


    }

    public void recordOfAdvice(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_onboardingData").toString(), "Record Of Advise", id);

        element.clickOnElement(DCI);
        tabScroll(driver, "Record Of Advice");
        populateData(driver, testData);


    }

    public void signingInstructions(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_onboardingData").toString(), "Signing of Instructions", id);


        element.clickOnElement(DCI);
        tabScroll(driver, "Signing Instructions");
        populateData(driver, testData);

    }

    public void investmentsSavings(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_onboardingData").toString(), "Investments savings", id);

        element.clickOnElement(DCI);
        tabScroll(driver, "Investment / Savings");
        populateData(driver, testData);

    }

    public void internetBankingServices(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        element.clickOnElement(DCI);
        tabScroll(driver, "Internet Banking Service");
        populate(driver, "Internet Banking Service", id);


    }

    public void mandatedOfficials(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        element.clickOnElement(DCI);
        tabScroll(driver, "Mandated Officials");
        populate(driver,"Mandated Officials", id );
    }

    public void needsAnalysis(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);

        element.clickOnElement(DCI);
        tabScroll(driver, "Needs Analysis");
        populate(driver, "Needs Analysis", id );
    }

    public void investmentSpecialist(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        element.clickOnElement(DCI);
        tabScroll(driver, "Investment Specialist");
        populate(driver,"Investment Specialist", id);
    }

    public void tabScroll(WebDriver driver, String tabName) throws Exception {

        while (!isElementVisible(driver, "//span[text() = '" + tabName + "']")) {
            element.clickOnElement("xpath||//div[@id = 'ManageDetailedControl_ReqFieldsPrimaryControl_tbGroups-after-scroller']");
        }

        element.clickOnElement("xpath||//span[text() = '" + tabName + "']");
    }

    public void clientDetailsPrimary_v1(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData","ClientDetailsPrimaryParty", id);

        element.clickOnElement(BasicClientInformation);

        try {
            clickOverride(driver, By.xpath("//a[text() = 'Override Mandatory Services for Branch STP ( Click To Override)']"));
        } catch (Exception e) {
            e.getMessage();
        }

        try{
            element.clickOnElement("xpath||//*[text()='The entity CIPC status is not available. Would You like to continue with the instruction?']/following::span[text()='Yes']");
        }catch (Exception e){
            System.out.println("No CIPC popup");
        }


        Thread.sleep(500);
        Iterator<Map.Entry<String, String>> iterator = testData.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<String, String> entry = iterator.next();
            String key, path, value;
            if (entry.getValue() != null && !entry.getValue().isEmpty()) {

                key = entry.getKey();
                value = entry.getValue();


                if (key.equalsIgnoreCase("ID") || key.equalsIgnoreCase("Description")) {
                    continue;
                }

                WebElement e = driver.findElement(By.xpath("//div//span[text()='" + key + "']/following :: input"));

                if (e.getAttribute("id").contains("combo")) {
                    path = "//div//span[text() ='" + key + "']/following :: div[@class ='x-form-trigger x-form-trigger-default x-form-arrow-trigger x-form-arrow-trigger-default  ']";
                    element.waitForElement(driver, 4, path).click();
                    element.selectFromLi(value, driver);
                } else {
                    path = "//div//span[text()='" + key + "']/following :: input";
                    element.clear("xpath||" + path);
                    element.typeOnElement("xpath||" + path, value);
                }


            }
        }

        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        element.clickOnElement("xpath||" + BCI_btnSave);

    }

    public void clientDetailsRelated_v1(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData","ClientDetailsRelatedParty", id);


        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        driver.findElement(By.xpath(PIClientDetailsTab)).click();

        try {
            clickOverride(driver, By.xpath("//a[text() = 'Override Mandatory Services for Branch STP ( Click To Override)']"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        Thread.sleep(1000);

        Iterator<Map.Entry<String, String>> iterator = testData.entrySet().iterator();


        //Date of Birth from ID number
        if(testData.get("Client group").equals("INDIVIDUAL CLIENT")){
            try {
                String idNumber = driver.findElement(By.xpath("//span[text()='Identification / passport number']/following::input")).getAttribute("value");
                if (!idNumber.isEmpty() && !idNumber.equals("")) {
                    Date year = new Date();
                    String dateOfBirth = "";
                    if(Integer.parseInt(idNumber.substring(0,2))<=(year.getYear()-100)){
                        if(Integer.parseInt(idNumber.substring(4,6))<10){
                            dateOfBirth = "20"+idNumber.substring(0,2)+"/"+idNumber.substring(2,4)+"/"+idNumber.substring(5,6);
                        }else {
                            dateOfBirth = "20"+idNumber.substring(0,2)+"/"+idNumber.substring(2,4)+"/"+idNumber.substring(4,6);
                        }

                    }
                    else {
                        if(Integer.parseInt(idNumber.substring(4,6))<10) {
                            dateOfBirth = "19" + idNumber.substring(0, 2) + "/" + idNumber.substring(2, 4) + "/" + idNumber.substring(5, 6);
                        }else {
                            dateOfBirth = "19" + idNumber.substring(0, 2) + "/" + idNumber.substring(2, 4) + "/" + idNumber.substring(4, 6);
                        }
                    }
                    System.out.println("Date of birth "+dateOfBirth);


                    element.clear("xpath||//span[text()='Date of birth']/following::input");
                    element.typeOnElement("xpath||//span[text()='Date of birth']/following::input",dateOfBirth);


                }
            }catch (Exception e){
                System.out.println(e.getMessage()+"\nDate of birth is not populated");
            }
        }

        while (iterator.hasNext()) {
            Map.Entry<String, String> entry = iterator.next();
            String key, path, value;

            if (entry.getValue() != null && !entry.getValue().isEmpty()) {

                key = entry.getKey();
                value = entry.getValue();

                if (key.equalsIgnoreCase("ID") || key.equalsIgnoreCase("Description")) {
                    continue;
                }

                key = entry.getKey();

                if (key.contains("'")) {
                    key = key.substring(key.indexOf('\'') + 1, key.length() - 1);
                }
                System.out.println(key + "   >>>>>>>    " + value);

                WebElement e = driver.findElement(By.xpath("//*[text()='"+key+"']/following::input"));

                if (e.getAttribute("id").contains("combobox")) {
                    path = "//*[text()='" + key + "']/following :: //div[contains(@class,' x-form-trigger x-form-arrow-trigger')]";
                    element.waitForElement(driver, 4, pnlRelatedFields + path).click();
                    element.selectFromLi(value, driver);

                } else if (e.getAttribute("id").contains("textarea")) {
                    path = "//*[text()='" + key + "']/following :: textarea";
                    element.clear("xpath||" + pnlRelatedFields + path);
                    element.typeOnElement("xpath||" + pnlRelatedFields + path, value);

                } else {
                    path = "//*[text()='" + key + "']/following :: input";
                    element.clear("xpath||" + pnlRelatedFields + path);
                    element.typeOnElement("xpath||" + pnlRelatedFields + path, value);
                }


            }
        }


    }

    public void detailedCIClientDetails_v1(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_onboardingData").toString(), "DetailedClientInfo_CD", id);


        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        element.clickOnElement(DCI);
        element.clickOnElement(PIClientDetailsTab);

/*        try {
            clickOverride(driver, By.xpath("//a[text() = 'Override Mandatory Services for Branch STP ( Click To Override)']"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
*/
        Iterator<Map.Entry<String, Map<String, Map<String, String>>>> iterator = testData.entrySet().iterator();
        while (iterator.hasNext()) {

            String key, value, path;
            Map.Entry<String, Map<String, Map<String, String>>> entry1 = iterator.next();

            for (Map.Entry<String, Map<String, String>> entry2 : entry1.getValue().entrySet()) {
                for (Map.Entry<String, String> entry3 : entry2.getValue().entrySet()) {

                    if (entry3.getValue() != null && !entry3.getValue().isEmpty()) {

                        key = entry3.getKey();
                        value = entry3.getValue();

                        switch (key) {
                            case "ID":
                                continue;
                            case "Description":
                                continue;
                            case "Standard industry code (SIC)":
                                SIC(driver, id);
                                continue;
                            case "Nature of client":
                                element.clickOnElement(COB_CD_NatureClient);
                                try {
                                    //Re try
                                    element.clickOnElement(COB_CD_NatureClient);
                                }catch (Exception e){

                                }
                                fieldCalculator("Nature of client", driver, 1, "Field Calculator_CD");
                                element.clickOnElement(COB_CD_FC_SaveButton);
                                continue;
                            case "Monthly income":
                                element.clickOnElement(COB_CD_MonthlyIncome);
                                fieldCalculator("Monthly Income", driver, 1, "Monthly_Income");
                                element.clickOnElement(COB_CD_FC_SaveButton);
                                continue;
                            case "Does the client fall under the NCA":
                                element.clickOnElement(COB_CD_DoesTheClientFallUnderNCA);
                                Thread.sleep(500);
                                element.clickOnElement(COB_CD_DoesTheClientFallUnderNCA);
                                Thread.sleep(500);
                                element.clickOnElement(COB_CD_ApplyingForCreditNO);
                                break;
                        }
                        System.out.println(entry2.getKey() + "   >>>>>>>    " + key + "   >>>>>>>    " + value);

                        WebElement e = driver.findElement(By.xpath("//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_pnlFields-outerCt']/child:: */child :: div//*[text() = '" + entry2.getKey() + "']/following :: *[text()='" + key + "']/following :: div[contains(@id, 'triggerWrap')]"));

                        //*[text()='1. Client Details']/following :: div[text() = 'Identity Information']/following :: div[table//span[text()='Initials']]/following-sibling::table//input

                        if (e.getAttribute("id").contains("combo")) {
                            path = "//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_pnlFields-outerCt']/child:: */child :: div//*[text() = '" + entry2.getKey() + "']/following :: *[text()='" + key + "']/following :: div[contains(@class, 'x-form-arrow-trigger')]";
                            element.waitForElement(driver, 10, path).click();
                            element.selectFromLi(value, driver);

                        } else if (e.getAttribute("id").contains("textareafield")) {
                            path = "//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_pnlFields-outerCt']/child:: */child :: div//*[text() = '" + entry2.getKey() + "']/following :: *[text()='" + key + "']/following :: textarea";
                            element.clear("xpath||" + path);
                            element.typeOnElement("xpath||" + path, value);

                        } else {
                            path = "//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_pnlFields-outerCt']/child:: */child :: div//*[text() = '" + entry2.getKey() + "']/following :: *[text()='" + key + "']/following :: input";
                            element.clear("xpath||" + path);
                            element.typeOnElement("xpath||" + path, value);
                        }



                    }
                }

            }

        }
    }

    public void regulatoryPrimary_v1(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData", "DetailedClientRegulatory", id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Client Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'4. Regulatory')]");
/*        try {
            clickOverride(driver, By.xpath("//a[text() = 'Override Mandatory Services for Branch STP ( Click To Override)']"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
*/
        Iterator<Map.Entry<String, String>> iterator = testData.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<String, String> entry = iterator.next();
            String key, path, value;
            if (entry.getValue() != null && !entry.getValue().isEmpty()) {

                key = entry.getKey();
                value = entry.getValue();
                System.out.println(key + "   >>>>>>>    " + value);
                switch (key) {
                    case "ID":
                        continue;
                    case "Description":
                        continue;

                    case "Does the client relationship involve a connection to a government agency or government that is sanctioned":
                        break;
                    case "Purpose of account / relationship":
                        element.clickOnElement("xpath||" + COB_Regulatory_CalculatorIcon);
                        element.clear("xpath||" + COB_Regulatory_CalculatorTypeOfAccountDropdown);
                        element.typeOnElement("xpath||" + COB_Regulatory_CalculatorTypeOfAccountDropdown, testData.get("Type of account").toString());
                        element.clickOnElement("xpath||" + COB_Regulatory_CalculatorSaveBtn);

                        iterator.next();
                        continue;

                    case "Expected account activity":
                        element.clickOnElement("xpath||" + COB_Regulatory_ExpectedAccount);
                        fieldCalculator("Expected account activity", driver, 1, "RegulatoryCalculator1");
                        element.clickOnElement("xpath||" + COB_Regulatory_CalculatorSaveBtn);
                        iterator.next();
                        continue;
                    case "Attestation ID":
                        element.clickOnElement("xpath||//span[text()='Actions']");
                        element.clickOnElement("xpath||//*[text()='Override Attestation']");
                        continue;

                }

                try {
                    key = entry.getKey().substring(0, 90);
                } catch (Exception e) {
                    key = entry.getKey();
                }
                if (key.contains("'")) {
                    key = key.substring(key.indexOf('\'') + 1, key.length() - 1);
                }


                WebElement e = driver.findElement(By.xpath("//div//span[contains(text(), '" + key + "')]/following::div[contains(@id, 'triggerWrap')]"));

                if (e.getAttribute("id").contains("combo")) {
                    path = "//div//span[contains(text(),'" + key + "')]/following:: div[contains(@id, 'trigger-picker')]";
                    try {
                        element.waitForElement(driver, 4, path).click();
                        element.selectFromLi(value, driver);
                    }catch (StaleElementReferenceException e1){
                        System.out.println(e1.getMessage());
                        //***************************************************************Retry
                        element.waitForElement(driver, 4, path).click();
                        element.selectFromLi(value, driver);
                    }

                    if(key.equalsIgnoreCase("Is the Client affiliated to any sanctioned persons (Legal or Natural) or sanctioned countries")){
                        Thread.sleep(500);
                    }

                } else if (e.getAttribute("id").contains("textarea")) {
                    path = "//div//span[contains(text(),'" + key + "')]/following:: textarea";
                    element.clear("xpath||" + path);
                    element.typeOnElement("xpath||" + path, value);

                } else {
                    path = "//div//span[contains(text(),'" + key + "')]/following:: input";
                    element.clear("xpath||" + path);
                    element.typeOnElement("xpath||" + path, value);
                }

            }


        }

    }

    public void fieldCalculator(String description, WebDriver driver, int id, String sheet) throws Exception {

        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData",sheet, id);

        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        Iterator<Map.Entry<String, String>> iterator = testData.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<String, String> entry = iterator.next();
            String key, path, value;
            if (entry.getValue() != null && !entry.getValue().isEmpty()) {

                key = entry.getKey();
                value = entry.getValue();

                switch (key) {
                    case "ID":
                        continue;
                    case "Description":
                        continue;
                }

                path = "//*[text()='" + key + "']/following::input";
                element.clear("xpath||" + path);
                element.typeOnElement("xpath||" + path, value);
            }
        }

    }

    public void controlOfficerLinking(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        element.clickOnElement(DCI);

        if(driver.findElements(By.xpath("//*[text() = 'Control Officer Linking']")).size() > 0){
            tabScroll(driver, "Control Officer Linking");
            populate(driver, "Control Officer Linking", id);
        }

        element.clickOnElement("xpath||" + BCI_btnSave);
        element.clickOnElement("xpath||" + MinimizeIssues);

    }

    public void searchCustomer(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData", "CustomerSearch", id);

        driver.switchTo().defaultContent();

        driver.findElement(By.id("pCustomerSearch_header_hd-textEl")).click();
        Thread.sleep(500);
        driver.findElement(By.id("userSearchFormControl_cmdSearchBy-inputEl")).click();
        Thread.sleep(500);
        element.clickOnElement("xpath||//li[text()='CIF']");

        element.typeOnElement("xpath||//input[@id='userSearchFormControl_txtSearchValue-inputEl']", testData.get("Value").toString());
        //element.clickOnElement("xpath||//*[@id='userSearchFormControl_cmdSearch']");
        Thread.sleep(1000);
        element.clickOnElement("xpath||//tr[contains(@id,'" + testData.get("Value").toString() + "')]");

        Actions action = new Actions(driver);
        WebElement we = driver.findElement(By.xpath("//*[@id='userSearchFormControl_mnuMaintenance-textEl']"));
        action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='userSearchFormControl_mnuMaintenance-textEl']"))).build().perform();
        //driver.findElement(By.xpath("//*[@id='userSearchFormControl_mnuMaintenance-textEl']")).sendKeys(Keys.ARROW_DOWN);
        Thread.sleep(1000);
        element.clickOnElement("xpath||//*[@id='userSearchFormControl_mnuMaintenanceDashboard-itemEl']");

        driver.switchTo().frame("pEspDefaultContent_IFrame");
        element.clickOnElement(CreateInstruction);


    }

    public void basicInfoMaintenance(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        testData = fetchTestData("path_onboardingData","BasicInfoMaintenance", id);

        if (element.isEnabled("xpath||//div[@class=\"x-dataview-item\"]")) {
            element.clickOnElement("xpath||//div[@class=\"x-dataview-item\"]");
            element.clickOnElement("xpath||//*[@id='ManageBasicControl_InitiationControl_ESPSearchControl_btnConfirm']");
        } else {
            try {
                selectObjectFrom_li_List(driver, lsLegalEnetityType, "", testData.get("LegalEntityType").toString(), 1);
                selectObjectFrom_li_List(driver, lsLegalEnetity, "", testData.get("LegalEntity").toString(), 1);

            } catch (Exception e) {

            }
        }


        element.clickOnElement("xpath||//*[@id=\"ManageBasicControl_InitiationControl_ddlInstructionSubType-inputEl\"]");
        element.typeOnElement("xpath||//*[@id=\"ManageBasicControl_InitiationControl_txtTypeFilter-inputEl\"]", testData.get("Instruction Type").toString());
        element.clickOnElement("xpath||//span[contains(text(),\"" + testData.get("Instruction Type").toString() + "\")]");
        element.clickOnElement("xpath||//*[@id=\"ManageBasicControl_InitiationControl_btnCreate-btnWrap\"]");
        System.out.println();
    }

    public void branchAndBankerMaintenance(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2("C:\\esp-frontend-automation\\src\\test\\resources\\espTestData\\espMaintenanceDatasheet.xlsx", "BranchAndBankerPrimary", id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Branch And Banker')]");

        populateData(driver, testData);
    }

    public void limitsMaintenance(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2("C:\\esp-frontend-automation\\src\\test\\resources\\espTestData\\espMaintenanceDatasheet.xlsx", "Limits", id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Limits')]");

        populateData(driver, testData);
    }

    public void officeUseMaintenance(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2("C:\\esp-frontend-automation\\src\\test\\resources\\espTestData\\espMaintenanceDatasheet.xlsx", "OfficeUse", id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Office Use')]");

        populateData(driver, testData);
    }

    public void documentsMaintenance(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);

        element.clickOnElement("xpath||//span[contains(text(),'Documents')]");

        List<WebElement> generateDocs = driver.findElements(By.xpath("//div[@class='row-imagecommand   icon-bookgo ']"));
        while (generateDocs.size() > 0) {
            generateDocs.get(0).click();
            element.clickOnElement(DocumentUploadNOBtn);
            element.clickOnElement(DocumentUploadNPDFBtn);
            generateDocs = driver.findElements(By.xpath("//div[@class='row-imagecommand   icon-bookgo ']"));
        }

        List<WebElement> uploadDocs = driver.findElements(By.xpath("//div[@class='row-imagecommand   icon-bookadd ']"));
        while (uploadDocs.size() > 0) {
            if (!uploadDocs.get(0).isDisplayed())
                element.clickOnElement("xpath||//span[text()='Document Selection']/../../div[2]");
            uploadDocs.get(0).click();
            String path = new File("C:\\esp-frontend-automation\\src\\test\\resources\\espTestData\\espMaintenanceDatasheet.xlsx").getAbsolutePath();

            Thread.sleep(1000);
            driver.findElement(By.id("ManageDocsControl_ReqDocControl_fuUpload-browseButtonWrap")).click();

            robotPasteAndEnter(path);
            Thread.sleep(3000);
            System.out.println("**************************************Following doc");
            uploadDocs = driver.findElements(By.xpath("//div[@class='row-imagecommand   icon-bookadd ']"));
        }


    }

    public void populateData(WebDriver driver, Map<String, Map<String, Map<String, String>>> testData) throws Exception {

        Iterator<Map.Entry<String, Map<String, Map<String, String>>>> iterator = testData.entrySet().iterator();
        while (iterator.hasNext()) {

            String key, value, path;
            Map.Entry<String, Map<String, Map<String, String>>> entry1 = iterator.next();

            for (Map.Entry<String, Map<String, String>> entry2 : entry1.getValue().entrySet()) {
                for (Map.Entry<String, String> entry3 : entry2.getValue().entrySet()) {

                    if (entry3.getValue() != null && !entry3.getValue().isEmpty()) {
                        key = entry3.getKey();
                        value = entry3.getValue();

                        try {
                            key = entry3.getKey().substring(0, 90);
                        } catch (Exception e) {
                            key = entry3.getKey();
                        }
                        if (key.contains("'")) {
                            key = key.substring(key.indexOf('\'') + 1, key.length() - 1);
                        }
                        WebElement e = driver.findElement(By.xpath("//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_pnlFields-outerCt']/child:: */child :: div//*[text() = '" + entry2.getKey() + "']/following :: *[contains(text(),'" + key + "')]/following :: div[contains(@id, 'triggerWrap')]"));


                        if (e.getAttribute("id").contains("combo")) {
                            path = "//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_pnlFields-outerCt']/child:: */child :: div//*[text() = '" + entry2.getKey() + "']/following :: *[contains(text(),'" + key + "')]/following :: div[contains(@class, 'x-form-arrow-trigger')]";
                            element.waitForElement(driver, 10, path).click();
                            element.selectFromLi(value, driver);

                        } else if (e.getAttribute("id").contains("textareafield")) {
                            path = "//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_pnlFields-outerCt']/child:: */child :: div//*[text() = '" + entry2.getKey() + "']/following :: *[contains(text(),'" + key + "')]/following :: textarea";
                            element.clear("xpath||" + path);
                            element.typeOnElement("xpath||" + path, value);

                        } else {
                            path = "//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_pnlFields-outerCt']/child:: */child :: div//*[text() = '" + entry2.getKey() + "']/following :: *[contains(text(),'" + key + "')]/following :: input";
                            element.clear("xpath||" + path);
                            element.typeOnElement("xpath||" + path, value);
                        }


                        System.out.println(entry2.getKey() + "   >>>>>>>    " + key + "   >>>>>>>    " + value);


                    }


                }
            }

        }
    }

    public void populateData_v2(WebDriver driver, Map<String, Map<String, Map<String, String>>> testData) throws Exception {
        element = new CommonUtil(driver);
        Iterator<Map.Entry<String, Map<String, Map<String, String>>>> iterator = testData.entrySet().iterator();
        while (iterator.hasNext()) {

            String key, value, path;
            Map.Entry<String, Map<String, Map<String, String>>> entry1 = iterator.next();

            for (Map.Entry<String, Map<String, String>> entry2 : entry1.getValue().entrySet()) {
                for (Map.Entry<String, String> entry3 : entry2.getValue().entrySet()) {

                    if (entry3.getValue() != null && !entry3.getValue().isEmpty()) {
                        key = entry3.getKey();
                        value = entry3.getValue();
                        System.out.println(entry2.getKey() + "   >>>>>>>    " + key + "   >>>>>>>    " + value);
                        try {
                            key = entry3.getKey().substring(0, 90);
                        } catch (Exception e) {
                            key = entry3.getKey();
                        }
                        if (key.contains("'")) {
                            key = key.substring(key.indexOf('\'') + 1, key.length() - 1);
                        }

                        WebElement e = driver.findElement(By.xpath("//*[text() = '" + entry2.getKey() + "']/following :: *[text()='" + key + "']/following :: div[contains(@id, 'triggerWrap')]"));


                        if (e.getAttribute("id").contains("combo")) {
                            path = "//*[text() = '" + entry2.getKey() + "']/following :: *[text()='" + key + "']/following :: div[contains(@class, 'x-form-arrow-trigger')]";


                            try{
                                element.waitForElement(driver, 10, path).click();
                                element.selectFromLi(value, driver);
                            }catch (Exception e1){
                                System.out.println("<<<<<<< Re-Try>>>>>>>>>");
                                Thread.sleep(500);
                                element.waitForElement(driver, 10, path).click();
                                element.selectFromLi(value, driver);
                            }

                        } else if (e.getAttribute("id").contains("textareafield")) {
                            path = "//*[text() = '" + entry2.getKey() + "']/following :: *[text()='" + key + "']/following :: textarea";
                            element.clear("xpath||" + path);
                            element.typeOnElement("xpath||" + path, value);



                        }else if(e.getAttribute("id").contains("ckeditor")){
                            //path = "//*[contains(text(),'" + key + "')]/following:: textarea";
                            WebElement ele = driver.findElement(By.xpath("//*[*[text()='"+key+"']]/following::iframe"));
                            ele.click();
                            ele.sendKeys(value);//element.clear("xpath||" + path);
                            //element.typeOnElement("xpath||" + path, value);
                            screenshotNames = screenshotNames + ","+ stepNo+".jpg";
                            getScreenShot(driver, currentFolderName + "/"+(stepNo++)+".jpg");
                        }
                        else {
                            path = "//*[text() = '" + entry2.getKey() + "']/following :: *[text()='" + key + "']/following :: input";
                            element.clear("xpath||" + path);
                            element.typeOnElement("xpath||" + path, value);
                        }

                    }

                }
            }

        }
    }

    public void populateData_v3(WebDriver driver, Map<String, Map<String, Map<String, String>>> testData) throws Exception {
        element = new CommonUtil(driver);
        Iterator<Map.Entry<String, Map<String, Map<String, String>>>> iterator = testData.entrySet().iterator();
        while (iterator.hasNext()) {

            String key, value, path;
            Map.Entry<String, Map<String, Map<String, String>>> entry1 = iterator.next();

            for (Map.Entry<String, Map<String, String>> entry2 : entry1.getValue().entrySet()) {
                for (Map.Entry<String, String> entry3 : entry2.getValue().entrySet()) {

                    if (entry3.getValue() != null && !entry3.getValue().isEmpty()) {
                        key = entry3.getKey();
                        value = entry3.getValue();
                        System.out.println(entry2.getKey() + "   >>>>>>>    " + key + "   >>>>>>>    " + value);
                        try {
                            key = entry3.getKey().substring(0, 90);
                        } catch (Exception e) {
                            key = entry3.getKey();
                        }
                        if (key.contains("'")) {
                            key = key.substring(key.indexOf('\'') + 1, key.length() - 1);
                        }

                        WebElement e = driver.findElement(By.xpath("//*[text() = '" + entry2.getKey() + "']/following :: *[text()='" + key + "']/following :: div[contains(@id, 'triggerWrap')]"));


                        if (e.getAttribute("id").contains("combo")) {
                            path = "//*[text() = '" + entry2.getKey() + "']/following :: *[text()='" + key + "']/following :: div[contains(@class, 'x-form-arrow-trigger')]";


                            try{
                                element.waitForElement(driver, 10, path).click();
                                element.selectFromLi(value, driver);
                            }catch (Exception e1){
                                System.out.println("<<<<<<< Re-Try>>>>>>>>>");
                                Thread.sleep(500);
                                element.waitForElement(driver, 10, path).click();
                                element.selectFromLi(value, driver);
                            }

                        } else if (e.getAttribute("id").contains("textareafield")) {
                            path = "//*[text() = '" + entry2.getKey() + "']/following :: *[text()='" + key + "']/following :: textarea";
//                            element.clear("xpath||" + path);
//                            element.typeOnElement("xpath||" + path, value);
                            List<WebElement> elements = driver.findElements(By.xpath(path));
                            for (WebElement el:elements){
                                el.clear();
                                el.sendKeys(value);
                            }



                        }else if(e.getAttribute("id").contains("ckeditor")){
                            //path = "//*[contains(text(),'" + key + "')]/following:: textarea";
                            List<WebElement> elements = driver.findElements(By.xpath("//*[*[text()='"+key+"']]/following::iframe"));
                            for (WebElement el:elements){
                                el.clear();
                                el.sendKeys(value);
                            }
                            screenshotNames = screenshotNames + ","+ stepNo+".jpg";
                            getScreenShot(driver, currentFolderName + "/"+(stepNo++)+".jpg");
                        }
                        else {
                            path = "//*[text() = '" + entry2.getKey() + "']/following :: *[text()='" + key + "']/following :: input";
//                            element.clear("xpath||" + path);
//                            element.typeOnElement("xpath||" + path, value);
                            List<WebElement> elements = driver.findElements(By.xpath(path));
                            for (WebElement el:elements){
                                el.clear();
                                el.sendKeys(value);
                            }
                        }

                    }

                }
            }

        }
    }

    public void populate(WebDriver driver, String dataSheet, int id) throws Exception {
        testData = fetchTestData("path_onboardingData",dataSheet, id);

        Iterator<Map.Entry<String, String>> iterator = testData.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<String, String> entry = iterator.next();
            String key, value, path;

            if (entry.getValue() != null && !entry.getValue().isEmpty()) {
                key = entry.getKey();
                value = entry.getValue();

                if (key.equalsIgnoreCase("ID") || key.equalsIgnoreCase("Description")) {
                    continue;
                }

                try {
                    key = entry.getKey().substring(0, 90);
                } catch (Exception e) {
                    key = entry.getKey();
                }
                if (key.contains("'")) {
                    key = key.substring(key.indexOf('\'') + 1, key.length() - 1);
                }

                WebElement e = driver.findElement(By.xpath("//*[contains(text(),'" + key + "')]/following :: div[contains(@id, 'triggerWrap')]"));

try{
                if (e.getAttribute("id").contains("combo")) {
                    path = "//*[contains(text(),'" + key + "')]/following ::div[contains(@class, 'x-form-arrow-trigger')]";
                    element.waitForElement(driver, 4, path).click();
                    element.selectFromLi(value, driver);

                } else if (e.getAttribute("id").contains("textareafield")) {
                    path = "//*[contains(text(),'" + key + "')]/following:: textarea";
                    element.clear("xpath||" + path);
                    element.typeOnElement("xpath||" + path, value);

                }
                else if(e.getAttribute("id").contains("cke_ckeditor")){
                    //path = "//*[contains(text(),'" + key + "')]/following:: textarea";
                    WebElement ele = driver.findElement(By.xpath("//*[*[text()='"+key+"']]/following::iframe"));
                    ele.click();
                    ele.sendKeys(value);
                    //element.clear("xpath||" + path);
                    //element.typeOnElement("xpath||" + path, value);
                }
                else {
                    path = "//*[contains(text(),'" + key + "')]/following:: input";
                    element.clear("xpath||" + path);
                    element.typeOnElement("xpath||" + path, value);
                }

            }catch (Exception e1){
                WebElement ele = driver.findElement(By.xpath("//div[table//span[text()='"+key+"']]/following::iframe"));
                ele.click();
                //ele.clear();
                ele.sendKeys(value);
                //driver.switchTo().frame("pEspDefaultContent_IFrame");
                screenshotNames = screenshotNames + ","+ stepNo+".jpg";
                getScreenShot(driver, currentFolderName + "/"+(stepNo++)+".jpg");
            }
            }


        }


    }


}


