package esp.formHandlers;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import utilities.CommonUtil;
import utilities.ObjectManager;
import utilities.ReadTestData;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static esp.formHandlers.GeneralFormHandler.populateData;
import static esp.formHandlers.GeneralFormHandler.robotPasteAndEnter;
import static utilities.ReadTestData.fetchTestData;

public class EspMaintenanceFormHandler extends ObjectManager {
    LinkedHashMap testData;
    CommonUtil element;
    String reg_ID_Number;

    public static String getCurrentTimeStamp(String format) {
        SimpleDateFormat sdfDate = new SimpleDateFormat(format);
        Date now = new Date();
        return sdfDate.format(now);
    }

    public void basicInfoMaintenance(WebDriver driver, int id)throws Exception{
        element = new CommonUtil(driver);
        testData = fetchTestData("path_MaintenanceData","BasicInfoMaintenance", id);

        if(element.isEnabled("xpath||//div[@class=\"x-dataview-item\"]")){
            element.clickOnElement("xpath||//div[@class=\"x-dataview-item\"]");
            element.clickOnElement("xpath||//*[@id='ManageBasicControl_InitiationControl_ESPSearchControl_btnConfirm']");
        }else {
            /*try {
                selectObjectFrom_li_List(driver, lsLegalEnetityType, "", testData.get("LegalEntityType").toString(), 1);
                selectObjectFrom_li_List(driver, lsLegalEnetity, "", testData.get("LegalEntity").toString(), 1);

            }catch (Exception e){

            }*/
        }



        element.clickOnElement("xpath||//*[@id=\"ManageBasicControl_InitiationControl_ddlInstructionSubType-inputEl\"]");
        element.typeOnElement("xpath||//*[@id=\"ManageBasicControl_InitiationControl_txtTypeFilter-inputEl\"]",testData.get("Instruction Type").toString());
        element.clickOnElement("xpath||//span[contains(text(),\""+testData.get("Instruction Type").toString()+"\")]");
        element.clickOnElement("xpath||//*[@id=\"ManageBasicControl_InitiationControl_btnCreate-btnWrap\"]");
        System.out.println();
    }

    public void branchAndBankerMaintenance(WebDriver driver,int id)throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","BranchAndBankerPrimary",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Branch And Banker')]");

         new EspFormHandler().populateData_v2(driver,testData);
    }

    public void addressDetailsMaintenance(WebDriver driver,int id) throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","AddressDetails",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Address Details')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }

    public void creditAnalystMaintenance(WebDriver driver, int id) throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","CreditAnalyst",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Credit Analyst')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }


    public void groupLeaderMaintenance(WebDriver driver, int id) throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","GroupLeader",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Group Leader')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }

    public void applicationMaintenance(WebDriver driver, int id)throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","Application",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Application')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }

    public void mainUsersMaintenance(WebDriver driver,int id) throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","MainUsers",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Main Users')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }
    public void internetBankingDetailsMaintenance(WebDriver driver,int id) throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","InternetBankingDetails",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Internet Banking Details')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }

    public void financialInformationMaintenance(WebDriver driver,int id)throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","FinancialInformation",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Financial Information')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }

    public void accountMaintenance(WebDriver driver,int id) throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","3. Account",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'3. Account')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }
    public void productMaintenance(WebDriver driver,int id) throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","4. Product",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'4. Product')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }

    public void pricingMaintenance(WebDriver driver,int id)throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","Pricing",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Pricing')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }

    public void securitiesMaintenance(WebDriver driver,int id)throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","Securities",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Securities')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }

    public void modelSelectionMaintenance(WebDriver driver,int id)throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","ModelSelection",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        new GeneralFormHandler().scrollToATab(driver,"Model Selection");
        element.clickOnElement("xpath||//span[contains(text(),'Model Selection')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }

    public void serviceMaintenance(WebDriver driver, int id) throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","Service",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Service')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }
    public void serviceRequiredMaintenance(WebDriver driver,int id) throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","ServicesRequired",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        new GeneralFormHandler().scrollToATab(driver,"Services Required");
        element.clickOnElement("xpath||//span[contains(text(),'Services Required')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }


    public void limitsMaintenance(WebDriver driver,int id)throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","Limits",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Limits')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }

    public void documentPrePopulationMaintenance(WebDriver driver,int id) throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData
                = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","DocumentPre-Population",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'Document Pre-Population')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }
    public void officeUseMaintenance(WebDriver driver,int id)throws Exception{
        element = new CommonUtil(driver);
        Map<String,Map<String, Map<String,String>>> testData
                = ReadTestData.readCurrentTestData_v2("\\\\wab10pc0q3zx1\\Automation\\sharedData\\espMaintenanceDatasheet.xlsx","OfficeUse",id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        new GeneralFormHandler().scrollToATab(driver,"Office Use");
        element.clickOnElement("xpath||//span[contains(text(),'Office Use')]");

        new EspFormHandler().populateData_v2(driver,testData);
    }

    public void documentsMaintenance(WebDriver driver,int id)throws Exception{
        element = new CommonUtil(driver);

        element.clickOnElement("xpath||//span[contains(text(),'Documents')]");

//        List<WebElement> generateDocs = driver.findElements(By.xpath("//div[@class='row-imagecommand   icon-bookgo ']"));
//        while (generateDocs.size() > 0) {
//            generateDocs.get(0).click();
//            element.clickOnElement(DocumentUploadNOBtn);
//            element.clickOnElement(DocumentUploadNPDFBtn);
//            generateDocs = driver.findElements(By.xpath("//div[@class='row-imagecommand   icon-bookgo ']"));
//        }

        List<WebElement> uploadDocs = driver.findElements(By.xpath("//div[@class='row-imagecommand   icon-bookadd ']"));
        while (uploadDocs.size() > 0) {
            if (!uploadDocs.get(0).isDisplayed())
                element.clickOnElement("xpath||//span[text()='Document Selection']/../../div[2]");
            uploadDocs.get(0).click();
            String path = new File("C:\\Automation\\esp\\src\\test\\resources\\espTestData\\ESPTestDoc.pdf").getAbsolutePath();

            Thread.sleep(1000);
            driver.findElement(By.id("ManageDocsControl_ReqDocControl_fuUpload-button-fileInputEl")).click();

            robotPasteAndEnter(path);
            Thread.sleep(3000);
            System.out.println("**************************************Following doc");
            uploadDocs = driver.findElements(By.xpath("//div[@class='row-imagecommand   icon-bookadd ']"));
        }


    }


}
