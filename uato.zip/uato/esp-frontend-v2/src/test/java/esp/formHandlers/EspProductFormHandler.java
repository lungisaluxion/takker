package esp.formHandlers;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import utilities.*;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

import static esp.formHandlers.GeneralFormHandler.*;
import static esp.regression.EspTestDriver.*;
import static utilities.GenerateSAIDNumber.generateRegistrationID;
import static utilities.HelperMethods.*;
import static utilities.ReadTestData.*;

public class EspProductFormHandler extends ObjectManager {
    LinkedHashMap testData;
    CommonUtil element;


    public void getScreenShot(WebDriver driver, String fileName) {
        try {
            File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(scrFile, new File(fileName));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void createInstruction(WebDriver driver) {
        element = new CommonUtil(driver);
        driver.switchTo().defaultContent();

        try {

            element.clickOnElement(ProductInstruction);
            element.clickOnElement(WorkbenchMinimizeBtn);

            driver.switchTo().frame("pEspDefaultContent_IFrame");
            //element.clickOnElement(CreateInstruction);
            element.clickOnElement("xpath||//*[@id=\"DashboardUserControl_btnInstructions-btnInnerEl\"]");
            element.clickOnElement("xpath||//*[@id=\"DashboardUserControl_mnuCreate-textEl\"]");


        } catch (Exception e) {
            System.out.println(e.getMessage());
            screenshotNames = screenshotNames + ",fail" + failNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/fail" + (failNo++) + ".jpg");
        }

    }

    public void entitySelection(WebDriver driver, int id) throws Exception {

        element = new CommonUtil(driver);
        testData = fetchTestData("path_productData","Instruction Details", id);


        if (testData.get("LegalEntityType").toString() != null && !testData.get("LegalEntityType").toString().isEmpty()) {
            Thread.sleep(100);
            element.waitForElement(driver, 15, lsLegalEnetityType).click();
            element.selectFromLi(testData.get("LegalEntityType").toString(), driver);
        }

        if (testData.get("LegalEntity").toString() != null && !testData.get("LegalEntity").toString().isEmpty()) {
            Thread.sleep(100);
            element.waitForElement(driver, 15, lsLegalEnetity).click();
            element.selectFromLi(testData.get("LegalEntity").toString(), driver);
        }

        element.clickOnElement(searchClientButton);

        Thread.sleep(1000);
        if (existsElement(driver, txtSearchAddPartyResult)) {
            if (isElementVisible(driver, txtSearchAddPartyResult)) {
                element.clickOnElement("xpath||" + txtSearchAddPartyResult);
                element.clickOnElement(btnSearchExistingCustomerConfirm);
            }
        }

        if (testData.get("InstructionSubType").toString() != null && !testData.get("InstructionSubType").toString().isEmpty()) {
            Thread.sleep(100);
            element.waitForElement(driver, 15, lsInstructionSubType).click();
            driver.findElement(By.xpath("//span[text() = '" + testData.get("InstructionSubType") + "']")).click();
        }

        if (testData.get("Simplex").toString() != null && !testData.get("Simplex").toString().isEmpty()) {
            Thread.sleep(100);
            element.waitForElement(driver, 15, simplex).click();
            driver.findElement(By.xpath("//li[text() = '" + testData.get("Simplex") + "']")).click();
        }


        element.clickOnElement(lsInstructionCreateBtn);
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        element.clickOnElement("xpath||" + MinimizeWorkHistory);
        driver.switchTo().frame("pEspDefaultContent_IFrame");

        System.out.println();


    }

    public void editEntity(WebDriver driver, int id) throws Exception {

        element = new utilities.CommonUtil(driver);
        testData = fetchTestData("path_ACSB_productOnboardingData", "Instruction Details", id);

        driver.switchTo().defaultContent();
        try {

            element.clickOnElement(ProductInstruction);
            element.clickOnElement(WorkbenchMinimizeBtn);

            driver.switchTo().frame("pEspDefaultContent_IFrame");
            Thread.sleep(500);
            String icon = "//td[*[contains(text(),'" + testData.get("Instruction ID").toString() + "')]]/following-sibling::td//div[@cmd='Edit']";
            WebElement edit = driver.findElement(By.xpath(icon));

            Thread.sleep(500);

       /* try {
            element.clickOnElement("xpath//*[text() = 'Work History']/following :: div[contains(@class, 'x-tool-tool-el x-tool-img x-tool-collapse-right ')]");
        }catch (NoSuchElementException e)
        {
            e.printStackTrace();
        }*/

            //((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", edit);
            edit.click();

            driver.switchTo().defaultContent();
            Thread.sleep(1000);
            element.clickOnElement("xpath||" + MinimizeWorkHistory);
            driver.switchTo().frame("pEspDefaultContent_IFrame");

        } catch (Exception e) {
            System.out.println(e.getMessage());
            screenshotNames = screenshotNames + ",fail" + failNo + ".jpg";
            getScreenShot(driver, currentFolderName + "/fail" + (failNo++) + ".jpg");
        }
    }


    public void instructionDetails(WebDriver driver, int id) throws Exception {

        element = new CommonUtil(driver);
        testData = fetchTestData("path_ACSB_productOnboardingData", "Instruction Details", id);


        if (testData.get("Legal Entity Type").toString() != null && !testData.get("Legal Entity Type").toString().isEmpty()) {
            Thread.sleep(100);
            element.waitForElement(driver, 15, lsLegalEnetityType).click();
            element.selectFromLi(testData.get("Legal Entity Type").toString(), driver);
        }

        if (testData.get("Legal Entity").toString() != null && !testData.get("Legal Entity").toString().isEmpty()) {
            Thread.sleep(100);
            element.waitForElement(driver, 15, lsLegalEnetity).click();
            element.selectFromLi(testData.get("Legal Entity").toString(), driver);
        }

        if (!testData.get("ID_Reg Number").toString().isEmpty() && testData.get("ID_Reg Number").toString() != null) {
            element.typeOnElement(EntityIDOrRegistrationNumber, testData.get("ID_Reg Number").toString());
        }

        if (!testData.get("Name").toString().isEmpty() && testData.get("Name").toString() != null) {
            element.typeOnElement("xpath||//*[@id = 'ManageBasicControl_InitiationControl_txtName-inputEl']", testData.get("Name").toString());
        }



        element.clickOnElement(searchClientButton);

        Thread.sleep(1000);
        if (existsElement(driver, txtSearchAddPartyResult)) {
            if (isElementVisible(driver, txtSearchAddPartyResult)) {
                element.clickOnElement("xpath||" + txtSearchAddPartyResult);
                element.clickOnElement("xpath||//*[@id=\"ManageBasicControl_InitiationControl_ESPSearchControl_wndResults\"]//*[@id=\"ManageBasicControl_InitiationControl_ESPSearchControl_btnConfirm\"]");
            }

            if (existsElement(driver, "//*[@id=\"ManageBasicControl_InitiationControl_CIFSearchControl_wndResults_header\"]")) {
                if (isElementVisible(driver, "//*[@id=\"ManageBasicControl_InitiationControl_CIFSearchControl_wndResults_header\"]")) {
                    element.clickOnElement("xpath||//*[@id=\"ManageBasicControl_InitiationControl_CIFSearchControl_dvResults\"]");
                    element.clickOnElement("xpath||//*[@id=\"ManageBasicControl_InitiationControl_CIFSearchControl_tbrResults\"]//*[@id=\"ManageBasicControl_InitiationControl_CIFSearchControl_btnConfirm-btnInnerEl\"]");
                }
            }
        }

        if (testData.get("Instruction Type").toString() != null && !testData.get("Instruction Type").toString().isEmpty()) {
            Thread.sleep(100);
            element.waitForElement(driver, 15, lsInstructionSubType).click();
            //System.out.println(1/0);
            if (testData.get("Instruction Type").toString().equalsIgnoreCase("Cheque Account")) {
                driver.findElements(By.xpath("//span[text() = '" + testData.get("Instruction Type").toString() + "']")).get(1).click();

            } else {
                    //element.typeOnElement("xpath||//input[@id='ManageBasicControl_InitiationControl_txtTypeFilter-inputEl']",testData.get("Instruction Type").toString());
                    driver.findElement(By.xpath("//span[text() = '" + testData.get("Instruction Type").toString() + "']")).click();

            }
        }

        /*** Client Review ****/
  //      attestationDeclined(driver, testData, element);

        element.clickOnElement(lsInstructionCreateBtn);

        /*** Client Review ****/
    //    attestationDeclined(driver, testData, element);

        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        element.clickOnElement("xpath||" + MinimizeWorkHistory);
        driver.switchTo().frame("pEspDefaultContent_IFrame");

        System.out.println();


    }

    public void basicInfoSecurityDisclaimer(WebDriver driver) throws Exception{
        element = new CommonUtil(driver);

        try{
            element.clickOnElement("xpath||//*[text()='Security Disclaimer']/following::span[text()='Accept']/../../..");
        }catch (Exception e1){
            System.out.println("No Security Disclaimer pop up");
        }

        element.clickOnElement("xpath||//*[text()='A - Security Disclaimer']");


        //element.waitForElement(driver, 10, "//*[contains(text() , 'Access to this system has been granted to you in line with your responsibility and competencies.')]/following :: div[contains(@class, 'x-form-arrow-trigger')]").click();
        //element.selectFromLi("YES", driver);

        element.clickOnElement("xpath||//*[@id='ManageBasicControl_ReqFieldsPrimaryControl_btnSave-btnEl']");
        element.clickOnElement("xpath||//span[@id='ManageBasicControl_InstructionPartiesControl_RelatedPartiesControl_btnSubmit-btnEl']");
//        Robot robot;
//
//        try
//        {
//            robot = new Robot();
//            robot.keyPress(KeyEvent.VK_CONTROL);
//            robot.keyPress(KeyEvent.VK_MINUS);
//            robot.keyRelease(KeyEvent.VK_CONTROL);
//            robot.keyRelease(KeyEvent.VK_MINUS);
//
//            robot.keyPress(KeyEvent.VK_CONTROL);
//            robot.keyPress(KeyEvent.VK_MINUS);
//            robot.keyRelease(KeyEvent.VK_CONTROL);
//            robot.keyRelease(KeyEvent.VK_MINUS);
//
//        } catch (AWTException e) {
//            e.printStackTrace();
//        }

        List<WebElement> elements = driver.findElements(By.xpath("//*[text()='3. Strawman Requirements (Related)']/following::div[@class=' x-tree-elbow-img x-tree-elbow-end-plus x-tree-expander']"));

        for (WebElement ele:elements){
            if(ele.isEnabled()){
                ele.click();
                break;
            }
        }
        Thread.sleep(1000);

        element.clickOnElement("xpath||//*[@id='ManageBasicControl_InstructionPartiesControl_btnContinue']");

        element.clickOnElement("xpath||//a[@id='ManageBasicControl_InstructionPartiesControl_btnContinue']");
    }

    public void detailedClientDetails(WebDriver driver, int id) throws Exception{
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_ACSB_productOnboardingData").toString(), "Detailed Client Details", id);


        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'1. Client Details')]");

        new EspFormHandler().populateData_v2(driver, testData);

        element.clickOnElement("xpath||//*[@class='x-btn-icon-el x-btn-icon-el-default-small icon-arrowright ']");
    }

    public void clientDetails(WebDriver driver, int id) throws Exception{

        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_ACSB_productOnboardingData").toString(), "Detailed Client Details", id);


        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'1. Client Details')]");

        new EspFormHandler().populateData_v2(driver, testData);

        element.clickOnElement("xpath||//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_btnSave']");
        element.clickOnElement("xpath||//*[@class='x-btn-icon-el x-btn-icon-el-default-small icon-arrowright ']");
    }

    public void principalAdditionalDetails(WebDriver driver, int id) throws Exception{
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_ACSB_productOnboardingData").toString(), "B1-Principal-Additional-Details", id);


        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'B1 - Principal Additional Details')]");

        new EspFormHandler().populateData_v3(driver, testData);

        element.clickOnElement("xpath||//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_btnSave']");
        element.clickOnElement("xpath||//*[@class='x-btn-icon-el x-btn-icon-el-default-small icon-arrowright ']");
    }

    public void securityDisclaimer(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_ACSB_productOnboardingData").toString(), "A - Security Disclaimer", id);


        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'A - Security Disclaimer')]");

        new EspFormHandler().populateData_v2(driver, testData);

    }

    public void facilitySelection(WebDriver driver, int id)throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_ACSB_productOnboardingData").toString(), "C - Facility Selection", id);


        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'C - Facility Selection')]");

        new EspFormHandler().populateData_v2(driver, testData);
    }


    public void chequeOverdraft(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_ACSB_productOnboardingData").toString(), "D1 - Cheque Overdraft", id);


        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'D1 - Cheque / Overdraft')]");

        element.clickOnElement("xpath||//span[text()='Click on the icon(calculator) to manage or view the existing cheque accounts']/following::a/span/span");
        new EspFormHandler().populateData_v2(driver, testData);
        try{
            element.clickOnElement("xpath||//*[text()='Main Account']/following::a");
            element.clickOnElement("xpath||//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_Population_SelectChequeAccount_cmbAccounts-trigger-picker']");
            driver.findElement(By.xpath("//li[contains(text(), '-000')]")).click();
            //element.selectFromLi("BUSIESS-00000004048046165",driver);
        }catch (Exception e1){
            
        }
        element.clickOnElement("xpath||//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_Population_SelectChequeAccount_btnAccept']");

        element.clickOnElement("xpath||//*[@class='x-btn-icon-el x-btn-icon-el-default-small icon-arrowright ']");
    }

    public void termLoan(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_ACSB_productOnboardingData").toString(), "D4 - Term loan", id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        element.clickOnElement("xpath||//span[contains(text(),'D4 - Term Loan')]");

        new EspFormHandler().populateData_v2(driver, testData);

        element.clickOnElement("xpath||//*[text()='Total settlement amount']/following::a");
        element.clickOnElement("xpath||//*[@class='x-btn-icon-el x-btn-icon-el-default-small icon-arrowright ']");
    }

    public void application(WebDriver driver, int id)throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_ACSB_productOnboardingData").toString(), "Z - Application", id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        new GeneralFormHandler().scrollToATab(driver,"Z - Application");
        element.clickOnElement("xpath||//span[contains(text(),'Z - Application')]");

        try {
            //new EspFormHandler().populateData_v2(driver, testData);
            Iterator<Map.Entry<String, Map<String, Map<String, String>>>> iterator = testData.entrySet().iterator();
            while (iterator.hasNext()) {

                String key, value, path;
                Map.Entry<String, Map<String, Map<String, String>>> entry1 = iterator.next();

                for (Map.Entry<String, Map<String, String>> entry2 : entry1.getValue().entrySet()) {
                    for (Map.Entry<String, String> entry3 : entry2.getValue().entrySet()) {

                        if (entry3.getValue() != null && !entry3.getValue().isEmpty()) {
                            key = entry3.getKey();
                            value = entry3.getValue();

                            try {
                                key = entry3.getKey().substring(0, 90);
                            } catch (Exception e) {
                                key = entry3.getKey();
                            }
                            if (key.contains("'")) {
                                key = key.substring(key.indexOf('\'') + 1, key.length() - 1);
                            }


                            System.out.println(entry2.getKey() + "   >>>>>>>    " + key + "   >>>>>>>    " + value);



                            if(entry2.getKey().equalsIgnoreCase("Additional Information 6")){
                                if(testData.get("Z - Application").get("Additional Information 6").get("Proceed").equals("YES")){
                                    element.waitForElement(driver, 10, "//*[text() = 'Additional Information 6']/following :: *[text()='Proceed']/following :: div[contains(@class, 'x-form-arrow-trigger')]").click();
                                    element.selectFromLi("YES", driver);

                                    System.out.println("===== Additional Information 6 =====");
                                }
                                Thread.sleep(1000);
                                if(testData.get("Z - Application").get("Additional Information 7").get("Proceed").equals("YES")){
                                    element.waitForElement(driver, 10, "//*[text() = 'Additional Information 7']/following :: *[text()='Proceed']/following :: div[contains(@class, 'x-form-arrow-trigger')]").click();
                                    element.selectFromLi("YES", driver);
                                    System.out.println("===== Additional Information 7 =====");
                                }
                                decision(driver,1);
                                return;
                            }
                            WebElement e = driver.findElement(By.xpath("//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_pnlFields-outerCt']"));
                            try {
                                e = driver.findElement(By.xpath("//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_pnlFields-outerCt']/child:: */child :: div//*[text() = '" + entry2.getKey() + "']/following :: *[contains(text(),'" + key + "')]/following :: div[contains(@id, 'triggerWrap')]"));
                            }catch (Exception e1){
                                continue;
                            }
                            if(entry3.getKey().equalsIgnoreCase("Process new application")){
                                path = "//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_pnlFields-outerCt']/child:: */child :: div//*[text() = '" + entry2.getKey() + "']/following :: *[contains(text(),'" + key + "')]/following :: div[contains(@class, 'x-form-arrow-trigger')]";

                                try{
                                    element.waitForElement(driver, 10, path).click();
                                    element.selectFromLi(value, driver);
                                }catch (Exception e2){
                                    System.out.println("==================Call one already processed.....");
                                }

                                //System.out.println();
                            }
                            else if (e.getAttribute("id").contains("combo")) {
                                path = "//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_pnlFields-outerCt']/child:: */child :: div//*[text() = '" + entry2.getKey() + "']/following :: *[contains(text(),'" + key + "')]/following :: div[contains(@class, 'x-form-arrow-trigger')]";
                                element.waitForElement(driver, 10, path).click();
                                element.selectFromLi(value, driver);

                            } else if (e.getAttribute("id").contains("textareafield")) {
                                path = "//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_pnlFields-outerCt']/child:: */child :: div//*[text() = '" + entry2.getKey() + "']/following :: *[contains(text(),'" + key + "')]/following :: textarea";
                                element.clear("xpath||" + path);
                                element.typeOnElement("xpath||" + path, value);

                            } else {
                                path = "//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_pnlFields-outerCt']/child:: */child :: div//*[text() = '" + entry2.getKey() + "']/following :: *[contains(text(),'" + key + "')]/following :: input";
                                element.clear("xpath||" + path);
                                element.typeOnElement("xpath||" + path, value);
                            }


                        }


                    }
                }

            }
        }catch (Exception ex2){
            System.out.println("Additional Information 6 or 7 is executed\n"+ex2.getCause());
        }

        element.clickOnElement("xpath||//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_btnSave-btnInnerEl']");
        //decision(driver,1);
    }
    public void application_v2(WebDriver driver, int id)throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_ACSB_productOnboardingData").toString(), "Z - Application", id);


        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        new GeneralFormHandler().scrollToATab(driver,"Z - Application");
        element.clickOnElement("xpath||//span[contains(text(),'Z - Application')]");

        //==================================================================================================

        Iterator<Map.Entry<String, Map<String, Map<String, String>>>> iterator = testData.entrySet().iterator();
        while (iterator.hasNext()) {

            String key, value, path;
            Map.Entry<String, Map<String, Map<String, String>>> entry1 = iterator.next();

            for (Map.Entry<String, Map<String, String>> entry2 : entry1.getValue().entrySet()) {
                for (Map.Entry<String, String> entry3 : entry2.getValue().entrySet()) {

                    if (entry3.getValue() != null && !entry3.getValue().isEmpty()) {
                        key = entry3.getKey();
                        value = entry3.getValue();
                        System.out.println(entry2.getKey() + "   >>>>>>>    " + key + "   >>>>>>>    " + value);
                        try {
                            key = entry3.getKey().substring(0, 90);
                        } catch (Exception e) {
                            key = entry3.getKey();
                        }
                        if (key.contains("'")) {
                            key = key.substring(key.indexOf('\'') + 1, key.length() - 1);
                        }
                        if(entry2.getKey().equals("Additional Information 1")){
                            element.waitForElement(driver, 10, "//*[text() = 'Additional Information 6']/following :: *[text()='Proceed']/following :: div[contains(@class, 'x-form-arrow-trigger')]").click();
                            element.selectFromLi("YES", driver);

                            spouseORCo_habitor(driver,1);
//                            isInfo1Checked = true;
//                            if(!isInfo1Checked)
//                                application(driver,id);
                            element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
                            new GeneralFormHandler().scrollToATab(driver,"Z - Application");
                            element.clickOnElement("xpath||//span[contains(text(),'Z - Application')]");

                            element.waitForElement(driver, 10, "//*[text() = 'Additional Information 6']/following :: *[text()='Proceed']/following :: div[contains(@class, 'x-form-arrow-trigger')]").click();
                            element.selectFromLi("YES", driver);
                            System.out.println("===== Additional Information 1 =====");
                        }
                        if(entry2.getKey().equals("Additional Information 6")){
                            element.waitForElement(driver, 10, "//*[text() = 'Additional Information 6']/following :: *[text()='Proceed']/following :: div[contains(@class, 'x-form-arrow-trigger')]").click();
                            element.selectFromLi("YES", driver);
                            System.out.println("===== Additional Information 6 =====");
                        }
                        if(entry2.getKey().equals("Additional Information 7")){
                            element.waitForElement(driver, 10, "//*[text() = 'Additional Information 7']/following :: *[text()='Proceed']/following :: div[contains(@class, 'x-form-arrow-trigger')]").click();
                            element.selectFromLi("YES", driver);
                            System.out.println("===== Additional Information 7 =====");
                        }

                        WebElement e = driver.findElement(By.xpath("//*[text() = '" + entry2.getKey() + "']/following :: *[text()='" + key + "']/following :: div[contains(@id, 'triggerWrap')]"));


                        if (e.getAttribute("id").contains("combo")) {
                            path = "//*[text() = '" + entry2.getKey() + "']/following :: *[text()='" + key + "']/following :: div[contains(@class, 'x-form-arrow-trigger')]";


                            try{
                                element.waitForElement(driver, 10, path).click();
                                element.selectFromLi(value, driver);
                            }catch (Exception e1){
                                System.out.println("<<<<<<< Re-Try>>>>>>>>>");
                                Thread.sleep(500);
                                element.waitForElement(driver, 10, path).click();
                                element.selectFromLi(value, driver);
                            }

                        } else if (e.getAttribute("id").contains("textareafield")) {
                            path = "//*[text() = '" + entry2.getKey() + "']/following :: *[text()='" + key + "']/following :: textarea";
                            element.clear("xpath||" + path);
                            element.typeOnElement("xpath||" + path, value);



                        }else if(e.getAttribute("id").contains("ckeditor")){
                            //path = "//*[contains(text(),'" + key + "')]/following:: textarea";
                            WebElement ele = driver.findElement(By.xpath("//*[*[text()='"+key+"']]/following::iframe"));
                            ele.click();
                            ele.sendKeys(value);//element.clear("xpath||" + path);
                            //element.typeOnElement("xpath||" + path, value);
                            screenshotNames = screenshotNames + ","+ stepNo+".jpg";
                            getScreenShot(driver, currentFolderName + "/"+(stepNo++)+".jpg");
                        }
                        else {
                            path = "//*[text() = '" + entry2.getKey() + "']/following :: *[text()='" + key + "']/following :: input";
                            element.clear("xpath||" + path);
                            element.typeOnElement("xpath||" + path, value);
                        }

                    }

                }
            }

        }
        //==================================================================================================


        element.clickOnElement("xpath||//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_btnSave-btnInnerEl']");
    }



    public void decision(WebDriver driver, int id)throws Exception{
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_ACSB_productOnboardingData").toString(), "R2 - Decision", id);

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        new GeneralFormHandler().scrollToATab(driver,"R2 - Decision");
        element.clickOnElement("xpath||//span[contains(text(),'R2 - Decision')]");
        System.out.println("System decision result : \n\n"
                +element.getText("xpath||//*[@class='x-panel-body x-grid-with-col-lines x-grid-with-row-lines x-grid-body x-panel-body-default x-panel-body-default x-noborder-rbl']"));

        new EspFormHandler().populateData_v2(driver, testData);
    }

    public void smsSecuritiesOffered(WebDriver driver, int id)throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_ACSB_productOnboardingData").toString(), "K - SMS - Securities Offered", id);

        //Call one and two
        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        new GeneralFormHandler().scrollToATab(driver,"Z - Application");
        element.clickOnElement("xpath||//span[contains(text(),'Z - Application')]");
        element.waitForElement(driver, 10, "//*[text() = 'Process Application']/following :: *[text()='Process new application']/following :: div[contains(@class, 'x-form-arrow-trigger')]").click();
        element.selectFromLi("YES", driver);
        System.out.println("===== Call One =====");

        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        new GeneralFormHandler().scrollToATab(driver,"K - SMS - Securities Offered");
        element.clickOnElement("xpath||//span[contains(text(),'K - SMS - Securities Offered')]");

        new EspFormHandler().populateData_v2(driver, testData);

        element.clickOnElement("xpath||//*[text()='Specific Security']/following::a");
        element.clickOnElement("xpath||//*[text()='Other Entity Offering Security']/following::*[text()='Specific Security']/following::a");

        element.clickOnElement("xpath||//*[text()='Unique identifier']/following::a");
        element.waitForElement(driver, 10, "//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_Population_SOUniqueID_cmbUnique-trigger-picker']").click();
        element.clickOnElement("xpath||//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_Population_SOUniqueID_cmbUnique-picker-listEl']/li");

        element.clickOnElement("xpath||//a[@id='ManageDetailedControl_ReqFieldsPrimaryControl_Population_SOUniqueID_btnAccept']");


        element.clickOnElement("xpath||//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_btnSave-btnInnerEl']");
    }

    public void spouseORCo_habitor(WebDriver driver, int id) throws Exception{
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_ACSB_productOnboardingData").toString(), "P4 - spouce co-habitor", id);

        //Call one and two
        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        new GeneralFormHandler().scrollToATab(driver,"Z - Application");
        element.clickOnElement("xpath||//span[contains(text(),'Z - Application')]");
        try {
            element.waitForElement(driver, 10, "//*[text() = 'Process Application']/following :: *[text()='Process new application']/following :: div[contains(@class, 'x-form-arrow-trigger')]").click();
            element.selectFromLi("YES", driver);
        }catch (Exception e){
            System.out.println("==================Call one already processed.....");
        }
        System.out.println("===== Call One =====");
        element.waitForElement(driver, 10, "//*[text() = 'Additional Information 1']/following :: *[text()='Proceed']/following :: div[contains(@class, 'x-form-arrow-trigger')]").click();
        element.selectFromLi("YES", driver);
        System.out.println("===== Additional Information 1 =====");



        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        new GeneralFormHandler().scrollToATab(driver,"P4 - Spouse ");
        element.clickOnElement("xpath||//span[contains(text(),'P4 - Spouse ')]");

        new EspFormHandler().populateData_v2(driver, testData);



        element.clickOnElement("xpath||//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_btnSave-btnInnerEl']");
        //application(driver,1);
    }

    public void generalQualitativeInformation(WebDriver driver, int id) throws Exception {
        element = new CommonUtil(driver);
        GetPropertyFileValues properties = new GetPropertyFileValues();
        Properties espProperties = properties.getPropValues("espTestData/esp.properties");
        Map<String, Map<String, Map<String, String>>> testData = ReadTestData.readCurrentTestData_v2(espProperties.getProperty("path_ACSB_productOnboardingData").toString(), "General Qualitative Information", id);


        element.clickOnElement("xpath||//span[contains(text(),'Detailed Information')]");
        new GeneralFormHandler().scrollToATab(driver,"R - General Qualitative Information");
        element.clickOnElement("xpath||//span[contains(text(),'General Qualitative Information')]");

        new EspFormHandler().populateData_v2(driver, testData);



        element.clickOnElement("xpath||//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_btnSave-btnInnerEl']");
        application(driver,1);
    }

    public void completion(WebDriver driver) throws InterruptedException {
        element.clickOnElement("xpath||//span[contains(text(),'Completion')]");
        Thread.sleep(800);

        element.clickOnElement("xpath||//*[@id=\"ManageCompletionControl_CompletionControl_btnSubmit-btnInnerEl\"]");
    }



}
