package esp.formHandlers;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import utilities.CommonUtil;
import utilities.ObjectManager;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import static esp.regression.EspTestDriver.currentFolderName;
import static esp.regression.EspTestDriver.screenshotNames;
import static esp.regression.EspTestDriver.stepNo;
import static utilities.HelperMethods.getScreenShot;
import static utilities.HelperMethods.isElementVisible;
import static utilities.ReadTestData.fetchTestData;

public class GeneralFormHandler extends ObjectManager {
    LinkedHashMap testData;
    static CommonUtil element;
    String reg_ID_Number;

    public static String getCurrentTimeStamp(String format) {
        SimpleDateFormat sdfDate = new SimpleDateFormat(format);
        Date now = new Date();
        return sdfDate.format(now);
    }

    public void searchCustomer(String path, WebDriver driver, int id) throws Exception{
        element = new CommonUtil(driver);
        testData = fetchTestData(path,"CustomerSearch", id);

        driver.switchTo().defaultContent();

        driver.findElement(By.id("pCustomerSearch_header-title-textEl")).click();
        Thread.sleep(500);
        driver.findElement(By.id("userSearchFormControl_cmdSearchBy-inputEl")).click();
        Thread.sleep(500);
        element.clickOnElement("xpath||//li[text()='CIF']");

        element.typeOnElement("xpath||//input[@id='userSearchFormControl_txtSearchValue-inputEl']",testData.get("Value").toString());
        element.clickOnElement("xpath||//*[@id='userSearchFormControl_cmdSearch']");
        Thread.sleep(1000);
        element.clickOnElement("xpath||//div[contains(text(),'"+testData.get("Value").toString()+"')]");

        Actions action = new Actions(driver);
        WebElement we = driver.findElement(By.xpath("//*[@id='userSearchFormControl_mnuMaintenance-textEl']"));
        action.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='userSearchFormControl_mnuMaintenance-textEl']"))).build().perform();
        //driver.findElement(By.xpath("//*[@id='userSearchFormControl_mnuMaintenance-textEl']")).sendKeys(Keys.ARROW_DOWN);
        Thread.sleep(1000);
        element.clickOnElement("xpath||//*[@id='userSearchFormControl_mnuMaintenanceDashboard-itemEl']");

        driver.switchTo().frame("pEspDefaultContent_IFrame");
        element.clickOnElement(CreateInstruction);



    }

    public static void robotPasteAndEnter(String toPaste) {
        try {
            StringSelection absolutePath = new StringSelection(toPaste);
            Toolkit.getDefaultToolkit().getSystemClipboard().setContents(absolutePath, null);
            Robot robot = new Robot();
            Thread.sleep(3000);
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_V);

            robot.keyRelease(KeyEvent.VK_CONTROL);
            Thread.sleep(3000); // Sync
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_CONTROL);
            System.out.println("**************************************Pasted");
        } catch (AWTException AWTEx) {
            AWTEx.printStackTrace();
            System.out.println("===================================" + AWTEx.getMessage());
        } catch (InterruptedException IntEx) {
            IntEx.printStackTrace();
            System.out.println("===================================" + IntEx.getMessage());
        } catch (Exception e) {
            System.out.println("===================================" + e.getMessage());
        }
    }

    public static void populateData(WebDriver driver, Map<String, Map<String, Map<String, String>>> testData) throws Exception{
        element = new CommonUtil(driver);
        for (String header1:testData.keySet()){
            for (String header2:testData.get(header1).keySet()){
                for (String key:testData.get(header1).get(header2).keySet()){
                    String path;// = "xpath||//*[text()='"+header2+"']/following::div[table//span[text()='"+key+"']]/following-sibling::table//tbody/tr/td/input";
                    String value = testData.get(header1).get(header2).get(key);
//                    if(!value.equals("")&&!value.equals(null)){
//                        System.out.println(key +" - > "+testData.get(header1).get(header2).get(key));
//                        element.clear(path);
//                        element.typeOnElement(path,value);
//                    }

                    System.out.println(key +" - > "+testData.get(header1).get(header2).get(key));
                    WebElement e = null;
                    try{
                        e = driver.findElement(By.xpath("//*[text()='"+header2+"']/following::div[table//span[text()='"+key+"']]/following-sibling::table"));
                        if (e.getAttribute("id").contains("combobox")) {
                            path = "//*[text()='"+header2+"']/following::div[table//span[contains(text(),'" + key + "')]]/following-sibling :: table//table//td//div[contains(@class,' x-form-trigger x-form-arrow-trigger')]";
                            element.waitForElement(driver, 4, path).click();
                            element.selectFromLi(value, driver);

                        } else if (e.getAttribute("id").contains("textarea")) {
                            path = "//*[text()='"+header2+"']/following::div[table//span[contains(text(),'" + key + "')]]/following-sibling::table//textarea";
                            element.clear("xpath||" + path);
                            element.typeOnElement("xpath||" + path, value);

                        } else {

                            path = "//*[text()='"+header2+"']/following::div[table//span[text()='" + key + "']]/following-sibling::table//input";
                            element.clear("xpath||" + path);
                            element.typeOnElement("xpath||" + path, value);


                        }

                    }catch (Exception e1){
                        WebElement ele = driver.findElement(By.xpath("//*[text()='"+header2+"']/following::div[table//span[text()='"+key+"']]/following::iframe"));
                        ele.click();
                        //ele.clear();
                        ele.sendKeys(value);
                        //driver.switchTo().frame("pEspDefaultContent_IFrame");
                        screenshotNames = screenshotNames + ","+ stepNo+".jpg";
                        getScreenShot(driver, currentFolderName + "/"+(stepNo++)+".jpg");
                    }


                }

            }
        }
    }

    public void scrollToATab(WebDriver driver,String tabName) throws InterruptedException {
        element = new CommonUtil(driver);
        while (!isElementVisible(driver,"//span[contains(text(),'"+tabName+"')]")){
            element.clickOnElement("xpath||//*[@id='ManageDetailedControl_ReqFieldsPrimaryControl_tbGroups-after-scroller']");
            System.out.print("=");
        }
    }

}
